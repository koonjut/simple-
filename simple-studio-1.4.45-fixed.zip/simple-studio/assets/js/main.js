
(function () {
	'use strict';

	var motionPreference = window.matchMedia('(prefers-reduced-motion: reduce)');
	var lenis = null;
	if (window.Lenis && !motionPreference.matches) {
		lenis = new window.Lenis({
			duration: 1.15,
			easing: function (t) { return Math.min(1, 1.001 - Math.pow(2, -10 * t)); },
			smoothWheel: true,
			wheelMultiplier: 0.9
		});
		var rafL = function (time) { lenis.raf(time); requestAnimationFrame(rafL); };
		requestAnimationFrame(rafL);
		document.querySelectorAll('[data-lenis-prevent], #mobile-menu, #lead-modal').forEach(function (n) { n.setAttribute('data-lenis-prevent', ''); });
		document.addEventListener('click', function (e) {
			var a = e.target.closest && e.target.closest('a[href*="#"]');
			if (!a) return;
			var url;
			try { url = new URL(a.href, location.href); } catch (err) { return; }
			if (url.origin !== location.origin || url.pathname !== location.pathname || !url.hash || url.hash === '#') return;
			var t;
			try { t = document.getElementById(decodeURIComponent(url.hash.slice(1))); } catch (err) { return; }
			if (!t) { if (url.hash === '#top') { e.preventDefault(); lenis.scrollTo(0); } return; }
			e.preventDefault();
			lenis.scrollTo(t, { offset: -90 });
		});
	}
	function lenisHold(on) { if (lenis) { if (on) lenis.stop(); else lenis.start(); } }

	var menu = document.getElementById('mobile-menu');
	var openBtn = document.querySelector('[data-menu-open]');
	var activeOverlay = null;
	var returnFocus = null;
	var inertNodes = [];
	function focusable(overlay) {
		return Array.prototype.filter.call(overlay.querySelectorAll('a[href], button, input:not([type=hidden]), textarea, select, [tabindex]'), function (el) {
			return !el.disabled && el.tabIndex >= 0 && el.getClientRects().length && !el.closest('[inert]');
		});
	}
	function focusOverlay() {
		if (!activeOverlay) return;
		var items = focusable(activeOverlay);
		(items[0] || activeOverlay).focus();
	}
	function setOverlay(overlay, open, trigger) {
		if (!overlay || (open && activeOverlay === overlay) || (!open && activeOverlay !== overlay)) return;
		var previousFocus = returnFocus;
		if (activeOverlay) activeOverlay.hidden = true;
		inertNodes.forEach(function (el) { el.removeAttribute('inert'); });
		inertNodes = [];
		activeOverlay = open ? overlay : null;
		if (open) {
			returnFocus = trigger && trigger.getClientRects().length ? trigger : document.activeElement;
			overlay.hidden = false;
			if (!overlay.hasAttribute('tabindex')) overlay.setAttribute('tabindex', '-1');
			// Inert siblings at every level, without disabling an ancestor of the dialog.
			var branch = overlay;
			while (branch.parentElement) {
				Array.prototype.forEach.call(branch.parentElement.children, function (el) {
					if (el !== branch && !el.hasAttribute('inert')) { el.setAttribute('inert', ''); inertNodes.push(el); }
				});
				branch = branch.parentElement;
				if (branch === document.body) break;
			}
		}
		document.body.classList.toggle('menu-open', !!activeOverlay && activeOverlay === menu);
		document.body.classList.toggle('modal-open', !!activeOverlay && activeOverlay !== menu);
		lenisHold(!!activeOverlay);
		if (openBtn) openBtn.setAttribute('aria-expanded', activeOverlay === menu ? 'true' : 'false');
		if (open) focusOverlay();
		else {
			returnFocus = null;
			if (previousFocus && previousFocus.isConnected && previousFocus.getClientRects().length) previousFocus.focus();
		}
	}
	document.addEventListener('keydown', function (e) {
		if (!activeOverlay || e.key !== 'Tab') return;
		var items = focusable(activeOverlay);
		var first = items[0], last = items[items.length - 1];
		if (!first) { e.preventDefault(); activeOverlay.focus(); }
		else if (e.shiftKey && (document.activeElement === first || document.activeElement === activeOverlay)) { e.preventDefault(); last.focus(); }
		else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
	});
	document.addEventListener('focusin', function (e) {
		if (activeOverlay && !activeOverlay.contains(e.target)) focusOverlay();
	});
	function setMenu(open) { setOverlay(menu, open); }
	if (openBtn) openBtn.addEventListener('click', function () { setMenu(true); });
	document.querySelectorAll('[data-menu-close]').forEach(function (b) {
		b.addEventListener('click', function () { setMenu(false); });
	});
	if (menu) {
		menu.querySelectorAll('a').forEach(function (a) {
			a.addEventListener('click', function () { setMenu(false); });
		});
	}
	document.addEventListener('keydown', function (e) {
		if (e.key === 'Escape') setMenu(false);
	});
	window.addEventListener('resize', function () {
		if (window.innerWidth > 1023) setMenu(false);
	});

	document.querySelectorAll('[data-lang]').forEach(function (box) {
		var btn = box.querySelector('.lang__btn');
		var list = box.querySelector('.lang__list');
		function set(open) { list.hidden = !open; btn.setAttribute('aria-expanded', open ? 'true' : 'false'); }
		btn.addEventListener('click', function (e) { e.stopPropagation(); set(list.hidden); });
		document.addEventListener('click', function (e) { if (!box.contains(e.target)) set(false); });
		document.addEventListener('keydown', function (e) { if (e.key === 'Escape') set(false); });
	});

	document.querySelectorAll('[data-acc]').forEach(function (acc) {
		acc.querySelectorAll('.acc__head').forEach(function (head) {
			head.addEventListener('click', function () {
				var item = head.closest('.acc__item');
				var body = item.querySelector('.acc__body');
				var open = head.getAttribute('aria-expanded') === 'true';
				head.setAttribute('aria-expanded', open ? 'false' : 'true');
				item.classList.toggle('is-open', !open);
				if (!body) return;
				body.style.overflow = 'hidden';
				if (body._accEnd) body.removeEventListener('transitionend', body._accEnd);
				clearTimeout(body._accTimer);
				if (motionPreference.matches) {
					body.hidden = open;
					body.style.height = '';
					body.style.overflow = '';
					return;
				}
				var done = function (e) {
					if (e && (e.target !== body || e.propertyName !== 'height')) return;
					body.removeEventListener('transitionend', done);
					clearTimeout(body._accTimer);
					body.style.height = '';
					body.style.overflow = '';
					if (open) body.hidden = true;
				};
				body._accEnd = done;
				if (open) {
					body.style.height = body.scrollHeight + 'px';
					body.offsetHeight;
					body.style.height = '0px';
				} else {
					body.hidden = false;
					body.style.height = '0px';
					body.offsetHeight;
					body.style.height = body.scrollHeight + 'px';
				}
				body.addEventListener('transitionend', done);
				body._accTimer = setTimeout(done, 600);
			});
		});
	});

	var modal = document.getElementById('lead-modal');
	function setModal(open, trigger) { setOverlay(modal, open, trigger); }
	document.querySelectorAll('[data-modal-open]').forEach(function (b) {
		b.addEventListener('click', function (e) {
			if (!modal) return;
			e.preventDefault();
			setMenu(false);
			setModal(true, b);
		});
	});
	document.querySelectorAll('[data-modal-close]').forEach(function (b) {
		b.addEventListener('click', function () { setModal(false); });
	});
	if (modal) {
		modal.addEventListener('mousedown', function (e) { if (e.target === modal) setModal(false); });
	}

	var sheet = document.getElementById('filters-sheet');
	function setSheet(open) { setOverlay(sheet, open); }
	document.querySelectorAll('[data-sheet-open]').forEach(function (b) { b.addEventListener('click', function () { setSheet(true); }); });
	document.querySelectorAll('[data-sheet-close]').forEach(function (b) { b.addEventListener('click', function () { setSheet(false); }); });
	if (sheet) {
		var show = sheet.querySelector('[data-sheet-show]');
		sheet.querySelectorAll('.sheet__opt').forEach(function (o) {
			o.addEventListener('click', function () {
				sheet.querySelectorAll('.sheet__opt').forEach(function (x) { x.classList.toggle('is-active', x === o); });
				if (show) show.setAttribute('href', o.getAttribute('data-href'));
			});
		});
		sheet.addEventListener('mousedown', function (e) { if (e.target === sheet) setSheet(false); });
	}
	document.addEventListener('keydown', function (e) {
		if (e.key === 'Escape') { setModal(false); setSheet(false); }
	});

	function normalizePhone(value) {
		value = value.trim();
		if (!/^\+?[0-9\s().-]+$/.test(value)) return '';
		var digits = value.replace(/\D/g, '');
		if (value.charAt(0) === '+') {
			if (!/^[1-9][0-9]{6,14}$/.test(digits) || (digits.charAt(0) === '7' && digits.length !== 11)) return '';
			return '+' + digits;
		}
		if (digits.length === 10) return '+7' + digits;
		if (digits.length === 11 && /^[78]/.test(digits)) return '+7' + digits.slice(1);
		return '';
	}
	function maskPhone(value) {
		var phone = normalizePhone(value);
		if (!phone || phone.slice(0, 2) !== '+7') return value;
		var d = phone.slice(2);
		return '+7 (' + d.slice(0, 3) + ') ' + d.slice(3, 6) + '-' + d.slice(6, 8) + '-' + d.slice(8, 10);
	}
	function livePhone(value) {
		var digits = value.replace(/\D/g, '');
		var hasPlus = /^\s*\+/.test(value);
		if (!digits) return hasPlus ? '+' : '';
		if (hasPlus && digits.charAt(0) !== '7') return '+' + digits;
		if (hasPlus || (digits.length >= 11 && /^[78]/.test(digits))) digits = digits.slice(1);
		else if (digits.length > 10) return digits;
		var out = '+7 (' + digits.slice(0, 3);
		if (digits.length >= 3) out += ')';
		if (digits.length > 3) out += ' ' + digits.slice(3, 6);
		if (digits.length > 6) out += '-' + digits.slice(6, 8);
		if (digits.length > 8) out += '-' + digits.slice(8);
		return out;
	}
	function updatePhone(inp) {
		var value = inp.value;
		var caret = inp.selectionStart;
		var atEnd = caret === null || caret === value.length;
		var before = (value.slice(0, caret === null ? value.length : caret).match(/\d/g) || []).length;
		var formatted = livePhone(value);
		var addedDigits = (formatted.match(/\d/g) || []).length - (value.match(/\d/g) || []).length;
		before += Math.max(0, addedDigits);
		var position = formatted.length;
		if (!atEnd) {
			position = 0;
			while (position < formatted.length && before > 0) {
				if (/\d/.test(formatted.charAt(position))) before--;
				position++;
			}
		}
		inp.value = formatted;
		inp.setSelectionRange(position, position);
	}
	// The phone-only field has a live mask; mixed contact fields must accept email.
	document.querySelectorAll('input[data-mask=phone]').forEach(function (inp) {
		inp.addEventListener('focus', function () {
			if (!inp.value) inp.value = '+7 (';
		});
		inp.addEventListener('input', function (e) {
			if (!e.isComposing) updatePhone(inp);
		});
		inp.addEventListener('compositionend', function () { updatePhone(inp); });
		inp.addEventListener('paste', function (e) {
			if (!e.clipboardData || (!/^\+7[\s(]*$/.test(inp.value) && !(inp.selectionStart === 0 && inp.selectionEnd === inp.value.length))) return;
			e.preventDefault();
			inp.value = e.clipboardData.getData('text/plain');
			inp.dispatchEvent(new Event('input', { bubbles: true }));
		});
		inp.addEventListener('beforeinput', function (e) {
			if (e.cancelable && e.data && e.data.length > 1 && /^\+7[\s(]*$/.test(inp.value)) {
				e.preventDefault();
				inp.value = e.data;
				inp.dispatchEvent(new Event('input', { bubbles: true }));
				return;
			}
			var backward = e.inputType === 'deleteContentBackward';
			var forward = e.inputType === 'deleteContentForward';
			if ((!backward && !forward) || !e.cancelable || inp.selectionStart !== inp.selectionEnd || inp.value.slice(0, 2) !== '+7') return;
			// Delete the neighbouring digit, rather than reinsert a deleted mask separator.
			var caret = inp.selectionStart;
			var index = backward ? caret - 1 : caret;
			while (index >= 0 && index < inp.value.length && !/\d/.test(inp.value.charAt(index))) index += backward ? -1 : 1;
			e.preventDefault();
			if (index === 1 && inp.value.replace(/\D/g, '').length === 1) {
				inp.value = '';
			} else if (index > 1 && index < inp.value.length) {
				inp.value = inp.value.slice(0, index) + inp.value.slice(index + 1);
				var next = backward ? index : caret;
				inp.setSelectionRange(next, next);
			} else {
				return;
			}
			inp.dispatchEvent(new Event('input', { bubbles: true }));
		});
		inp.addEventListener('blur', function () {
			if (inp.value.replace(/\D/g, '') === '7' || inp.value === '+') inp.value = '';
		});
	});
	document.querySelectorAll('input[data-mask=auto]').forEach(function (inp) {
		inp.addEventListener('blur', function () { inp.value = maskPhone(inp.value); });
	});

	document.querySelectorAll('input[data-name]').forEach(function (inp) {
		inp.addEventListener('input', function () {
			var clean = inp.value.replace(/[^\p{L}\s'.\-]/gu, '').replace(/^\s+/, '').replace(/\s{2,}/g, ' ');
			if (clean !== inp.value) inp.value = clean;
		});
	});

	document.querySelectorAll('.lead-form').forEach(function (form) {
		var body = form.querySelector('.lead-form__body');
		var done = form.querySelector('.lead-form__done');
		var fail = form.querySelector('.lead-form__fail');
		var btn = form.querySelector('.lead-form__actions .btn');
		var label = btn ? btn.querySelector('.btn__label') : null;
		var defLabel = btn ? btn.getAttribute('data-label') : '';
		var cfg = window.SimpleCfg || {};
		var retryLabel = cfg.retry || '';
		var submitting = false;

		function fieldErr(input, bad) {
			var hint = input.parentNode.querySelector('.lead-form__hint');
			input.classList.toggle('is-invalid', bad);
			input.setAttribute('aria-invalid', bad ? 'true' : 'false');
			if (hint) hint.textContent = bad ? (input.getAttribute('data-err') || hint.getAttribute('data-hint')) : hint.getAttribute('data-hint');
		}
		function setSending(on) {
			submitting = on;
			form.classList.toggle('is-sending', on);
			form.setAttribute('aria-busy', on ? 'true' : 'false');
			form.querySelectorAll('input, textarea').forEach(function (el) { el.disabled = on; });
			if (btn) btn.disabled = on;
			if (label) label.textContent = on ? (cfg.sending || defLabel) : (form.classList.contains('has-fail') ? (retryLabel || defLabel) : defLabel);
		}
		form.querySelectorAll('input, textarea').forEach(function (el) {
			el.addEventListener('input', function () { if (el.classList.contains('is-invalid')) fieldErr(el, false); });
		});
		var again = form.querySelector('[data-form-again]');
		if (again) again.addEventListener('click', function () {
			done.hidden = true; body.hidden = false;
			var first = form.querySelector('input[type=text]'); if (first) first.focus();
		});

		form.addEventListener('submit', function (e) {
			e.preventDefault();
			if (submitting) return;
			var name = form.elements.lead_name;
			var contact = form.elements.lead_phone || form.elements.lead_contact;
			var val = contact.value.trim();
			var isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val);
			var badName = Array.from(name.value.trim()).length < 2 || Array.from(name.value.trim()).length > 120;
			var badContact = !normalizePhone(val) && (contact.getAttribute('data-mask') === 'phone' || !isEmail);
			fieldErr(name, badName);
			fieldErr(contact, badContact);
			if (badName || badContact) { (badName ? name : contact).focus(); return; }

			var data = new FormData(form);
			data.append('page', window.location.href);
			if (fail) fail.hidden = true;
			setSending(true);
			var controller = new AbortController();
			var timeout = setTimeout(function () { controller.abort(); }, 20000);
			var endpoint = cfg.ajax || form.action;
			var nonceData = new FormData();
			nonceData.append('action', 'simple_lead_nonce');
			// A fresh, uncached nonce also works when the page HTML came from a cache.
			fetch(endpoint, { method: 'POST', body: nonceData, credentials: 'same-origin', cache: 'no-store', signal: controller.signal })
				.then(function (r) { if (!r.ok) throw new Error('nonce'); return r.json(); })
				.then(function (res) {
					if (!res || !res.success || !res.data || !res.data.nonce) throw new Error('nonce');
					data.set('_nonce', res.data.nonce);
					return fetch(endpoint, { method: 'POST', body: data, credentials: 'same-origin', cache: 'no-store', signal: controller.signal });
				})
				.then(function (r) { if (!r.ok) throw new Error('submit'); return r.json(); })
				.then(function (res) {
					if (!res || !res.success) throw new Error('submit');
					clearTimeout(timeout);
					setSending(false);
					form.classList.remove('has-fail');
					form.reset();
					body.hidden = true;
					if (done) {
						done.hidden = false;
						var againBtn = done.querySelector('[data-form-again]');
						if (againBtn) againBtn.focus();
					}
				})
				.catch(function () {
					clearTimeout(timeout);
					setSending(false);
					form.classList.add('has-fail');
					if (fail) fail.hidden = false;
					if (label) label.textContent = retryLabel || defLabel;
				});
		});
	});

	document.addEventListener('error', function (e) {
		var img = e.target;
		if (!img || img.tagName !== 'IMG') return;
		var box = img.closest('.ph, .bcard__bg');
		if (!box) return;
		img.remove();
		box.classList.add('is-broken');
		box.setAttribute('data-broken', (window.SimpleCfg && SimpleCfg.broken) || '');
	}, true);

	document.querySelectorAll('[data-gallery]').forEach(function (el) {
		var track = el.querySelector('.gallery__track');
		var base = Array.prototype.slice.call(el.querySelectorAll('.gallery__item'));
		var n = base.length;
		if (n < 2) { el.classList.add('is-static'); return; }

		var items = base.slice();
		[0, 1].forEach(function () {
			base.forEach(function (it) {
				var c = it.cloneNode(true);
				c.setAttribute('aria-hidden', 'true');
				track.appendChild(c);
				items.push(c);
			});
		});
		var total = items.length;
		var wideFlag = items.map(function (it) { return it.hasAttribute('data-wide'); });
		var pos = n, target = n, raf = null, dragging = false, startX = 0, startPos = 0, lastX = 0, lastT = 0, vel = 0, moved = 0;
		var wide, narrow, gap = 12, step;
		var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

		function measure() {
			var W = el.clientWidth;
			if (W > 1023) { wide = W * 888 / 1344; narrow = W * 432 / 1344; }
			else if (W > 600) { wide = W * 0.66; narrow = W * 0.32; }
			else { wide = W * 0.82; narrow = W * 0.42; }
			gap = W > 600 ? 12 : 8;
			step = narrow + gap;
			track.style.gap = gap + 'px';
			render();
		}
		function wrap() {

			while (pos < n) { pos += n; target += n; startPos += n; }
			while (pos >= 2 * n) { pos -= n; target -= n; startPos -= n; }
		}
		function render() {
			wrap();
			var left = 0, k = Math.floor(pos), frac = pos - k;
			for (var i = 0; i < total; i++) {
				var f = Math.max(0, 1 - Math.abs(i - pos));
				var w = wideFlag[i] ? narrow + (wide - narrow) * f : narrow;
				items[i].style.width = w + 'px';
				if (i < k) left += w + gap;
				else if (i === k) left += (w + gap) * frac;
			}
			track.style.transform = 'translate3d(' + (-left) + 'px,0,0)';
		}
		function tick() {
			var d = target - pos;
			if (Math.abs(d) < 0.001) { pos = target; render(); raf = null; return; }
			pos += d * (reduce ? 1 : 0.16);
			render();
			raf = requestAnimationFrame(tick);
		}
		function go(t) {
			target = Math.round(t);
			if (!raf) raf = requestAnimationFrame(tick);
		}

		el.addEventListener('pointerdown', function (e) {
			if (e.pointerType === 'mouse' && e.button !== 0) return;
			dragging = true; moved = 0; startX = lastX = e.clientX; lastT = e.timeStamp; vel = 0; startPos = pos; target = pos;
			if (raf) { cancelAnimationFrame(raf); raf = null; }
			el.classList.add('is-drag');
			if (el.setPointerCapture) el.setPointerCapture(e.pointerId);
		});
		el.addEventListener('pointermove', function (e) {
			if (!dragging) return;
			var dx = e.clientX - startX;
			moved = Math.max(moved, Math.abs(dx));
			var dt = Math.max(1, e.timeStamp - lastT);
			vel = (e.clientX - lastX) / dt; lastX = e.clientX; lastT = e.timeStamp;
			pos = startPos - dx / step;
			render();
		});
		function end() {
			if (!dragging) return;
			dragging = false; el.classList.remove('is-drag');
			var fling = -vel * 220 / step;
			go(pos + Math.max(-0.5, Math.min(0.5, fling)));
		}
		el.addEventListener('pointerup', end);
		el.addEventListener('pointercancel', end);
		el.addEventListener('lostpointercapture', end);

		items.forEach(function (it, i) {
			it.addEventListener('click', function () { if (moved < 6 && Math.abs(i - pos) > 0.5) go(i); });
		});

		var wheelAcc = 0, wheelT = null;
		el.addEventListener('wheel', function (e) {
			if (Math.abs(e.deltaX) <= Math.abs(e.deltaY)) return;
			e.preventDefault();
			wheelAcc += e.deltaX;
			if (raf) { cancelAnimationFrame(raf); raf = null; }
			pos += e.deltaX / step; target = pos; render();
			clearTimeout(wheelT);
			wheelT = setTimeout(function () { go(pos + (wheelAcc > 0 ? 0.3 : -0.3)); wheelAcc = 0; }, 120);
		}, { passive: false });
		el.addEventListener('keydown', function (e) {
			if (e.key === 'ArrowRight') { e.preventDefault(); go(Math.round(target) + 1); }
			if (e.key === 'ArrowLeft') { e.preventDefault(); go(Math.round(target) - 1); }
		});
		window.addEventListener('resize', measure);
		measure();
	});

	document.querySelectorAll('[data-slider]').forEach(function (el) {
		var slides = el.querySelectorAll('[data-slide]');
		var dots = el.querySelectorAll('[data-dot]');
		if (slides.length < 2) return;
		var cur = 0, timer = null, paused = false;
		var pauseBtn = el.querySelector('[data-slider-pause]');
		var delay = parseInt(el.getAttribute('data-autoplay'), 10) || 3000;
		function go(n) {
			cur = (n + slides.length) % slides.length;
			slides.forEach(function (s, i) {
				s.classList.toggle('is-active', i === cur);
				if (i === cur) s.removeAttribute('aria-hidden'); else s.setAttribute('aria-hidden', 'true');
			});
			dots.forEach(function (d, i) { d.classList.toggle('is-active', i === cur); d.setAttribute('aria-pressed', i === cur ? 'true' : 'false'); });
		}
		function play() {
			stop();
			if (paused || motionPreference.matches || document.hidden || el.contains(document.activeElement)) return;
			timer = setInterval(function () { go(cur + 1); }, delay);
		}
		function stop() { if (timer) { clearInterval(timer); timer = null; } }
		dots.forEach(function (d) {
			d.addEventListener('click', function () { go(parseInt(d.getAttribute('data-dot'), 10)); play(); });
		});
		el.addEventListener('focusin', stop);
		el.addEventListener('focusout', function () { setTimeout(play, 0); });
		document.addEventListener('visibilitychange', play);
		if (motionPreference.addEventListener) motionPreference.addEventListener('change', play);
		if (pauseBtn) pauseBtn.addEventListener('click', function () {
			paused = !paused;
			pauseBtn.setAttribute('aria-pressed', paused ? 'true' : 'false');
			play();
		});
		var x0 = null;
		el.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; }, { passive: true });
		el.addEventListener('touchend', function (e) {
			if (x0 === null) return;
			var dx = e.changedTouches[0].clientX - x0;
			if (Math.abs(dx) > 40) { go(cur + (dx < 0 ? 1 : -1)); play(); }
			x0 = null;
		});
		play();
	});

	if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
		var targets = document.querySelectorAll('.section, .manifesto, .pcard, .bcard, .member, .art-row');
		var io = new IntersectionObserver(function (entries) {
			entries.forEach(function (en) {
				if (en.isIntersecting) { en.target.classList.add('is-in'); io.unobserve(en.target); }
			});
		}, { rootMargin: '0px 0px -8% 0px' });
		targets.forEach(function (t) {
			var r = t.getBoundingClientRect();
			if (r.top < window.innerHeight) return;
			t.classList.add('reveal');
			io.observe(t);
		});
	}
})();

(function () {
	document.querySelectorAll('[data-thumbs]').forEach(function (box) {
		var strip = box.querySelector('.svc-card__strip'), track = box.querySelector('.svc-card__track');
		var prev = box.querySelector('.svc-card__nav--prev'), next = box.querySelector('.svc-card__nav--next');
		if (!strip || !track || !prev || !next) { return; }
		var step = 76, pos = 0;
		function max() { return Math.max(0, track.scrollWidth - strip.clientWidth); }
		function apply() {
			pos = Math.max(0, Math.min(max(), pos));
			track.style.transform = 'translateX(' + (-pos) + 'px)';
			prev.disabled = pos <= 0;
			next.disabled = pos >= max() - 1;
		}
		prev.addEventListener('click', function () { pos -= step; apply(); });
		next.addEventListener('click', function () { pos += step; apply(); });
		window.addEventListener('resize', apply);
		apply();
	});
})();
