<?php
get_header();
the_post();
$id     = get_the_ID();
$lp     = function ( $k ) {
	return sfp( $k, 'projects' );
};
$sub    = sf_raw( 'case_subtitle', $id );
$client = sf_raw( 'case_client', $id );
$serv   = sf_raw( 'case_services', $id );
$place  = sf_raw( 'case_place', $id );
$team   = simple_case_team( sf_raw( 'case_team', $id ) );
$thumb  = get_post_thumbnail_id( $id );
$others = get_posts( array( 'post_type' => 'project', 'posts_per_page' => 2, 'post__not_in' => array( $id ), 'orderby' => 'menu_order date', 'order' => 'ASC', 'no_found_rows' => true ) );
$body   = simple_case_blocks( $id );
if ( '' === $body ) {
	$body = simple_case_render( apply_filters( 'the_content', get_the_content() ) );
}
?>

<article class="case">
	<section class="case-head">
		<div class="case-head__title">
			<h1 class="h1"><?php the_title(); ?></h1>
			<?php if ( $sub ) : ?><p class="case-head__sub"><?php echo esc_html( $sub ); ?></p><?php endif; ?>
		</div>
		<dl class="case-head__meta">
			<?php if ( $client ) : ?><div><dt class="eyebrow"><?php echo esc_html( $lp( 'prjs_case_client' ) ); ?></dt><dd><?php echo esc_html( $client ); ?></dd></div><?php endif; ?>
			<?php if ( $serv ) : ?><div><dt class="eyebrow"><?php echo esc_html( $lp( 'prjs_case_services' ) ); ?></dt><dd><?php echo esc_html( $serv ); ?></dd></div><?php endif; ?>
			<?php if ( $place ) : ?><div><dt class="eyebrow"><?php echo esc_html( $lp( 'prjs_case_place' ) ); ?></dt><dd><?php echo esc_html( $place ); ?></dd></div><?php endif; ?>
		</dl>
	</section>

	<div class="case-image case-image--cover ph"><?php echo $thumb ? simple_img( $thumb, 'simple-wide', '', array( 'loading' => 'eager' ) ) : ''; ?></div>

	<div class="case-body"><?php echo $body; ?></div>

	<?php if ( $team ) : ?>
		<section class="case-team">
			<p class="eyebrow"><?php echo esc_html( $lp( 'prjs_case_team' ) ); ?></p>
			<div class="case-team__grid">
				<?php foreach ( $team as $m ) : ?>
					<div><p class="case-team__role"><?php echo esc_html( $m[0] ); ?></p><?php foreach ( $m[1] as $nm ) : ?><p class="case-team__name"><?php echo esc_html( $nm ); ?></p><?php endforeach; ?></div>
				<?php endforeach; ?>
			</div>
		</section>
	<?php endif; ?>
</article>

<?php if ( $others ) : ?>
	<section class="section case-more">
		<div class="section__head">
			<h2 class="h3"><?php echo esc_html( $lp( 'prjs_case_more' ) ); ?></h2>
			<a class="link-arrow" href="<?php echo esc_url( simple_section_url( 'projects' ) ); ?>"><span><?php echo esc_html( $lp( 'prjs_case_more_all' ) ); ?></span><?php echo simple_arrow( 20 ); ?></a>
		</div>
		<div class="case-more__grid">
			<?php foreach ( $others as $p ) {
				get_template_part( 'template-parts/project-card', null, array( 'post' => $p, 'label' => sfp( 'svc_more_link', 'services' ) ) );
			} ?>
		</div>
	</section>
<?php endif; ?>

<?php get_footer();
