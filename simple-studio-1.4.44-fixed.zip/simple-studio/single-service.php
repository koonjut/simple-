<?php
get_header();
the_post();
$id  = get_the_ID();
$lbl = function ( $k ) {
	return sfp( $k, 'services' );
};

$lead = sf_raw( 'svc_lead', $id );
$lead = $lead ? $lead : wp_strip_all_tags( get_the_excerpt() );
$img1 = sf_raw( 'svc_img_1', $id );
$case = sf_raw( 'svc_case_title', $id );
$tags = sf_raw( 'svc_case_tags', $id );
$link = (int) sf_raw( 'svc_case_link', $id );

$stages = array();
foreach ( simple_rep_rows( $id, 'svc_stages' ) as $r ) {
	if ( ! empty( $r['title'] ) ) {
		$stages[] = array( $r['title'], isset( $r['text'] ) ? $r['text'] : '' );
	}
}
$gets = array();
foreach ( simple_rep_rows( $id, 'svc_gets' ) as $r ) {
	if ( ! empty( $r['title'] ) ) {
		$gets[] = array( $r['title'], isset( $r['text'] ) ? $r['text'] : '' );
	}
}
$faq = array();
foreach ( simple_rep_rows( $id, 'svc_faq' ) as $r ) {
	if ( ! empty( $r['title'] ) ) {
		$faq[] = array( $r['title'], isset( $r['text'] ) ? $r['text'] : '' );
	}
}
$thumbs = array();
foreach ( simple_rep_rows( $id, 'svc_projects' ) as $r ) {
	if ( ! empty( $r['img'] ) ) {
		$thumbs[] = $r;
	}
}
$more = sf_raw( 'svc_more_projects', $id );
$more = is_array( $more ) ? array_filter( array_map( 'absint', $more ) ) : array();
$more = $more ? get_posts( array( 'post_type' => 'project', 'post__in' => $more, 'orderby' => 'post__in', 'posts_per_page' => 2, 'no_found_rows' => true ) )
	: get_posts( array( 'post_type' => 'project', 'posts_per_page' => 2, 'orderby' => 'menu_order date', 'order' => 'ASC', 'no_found_rows' => true ) );

$why_title = simple_lines( sf_raw( 'svc_why_title', $id ) );
?>

<section class="svc-hero">
	<div class="svc-hero__top">
		<h1 class="h1"><?php the_title(); ?></h1>
		<p class="svc-hero__lead"><?php echo esc_html( $lead ); ?></p>
	</div>
	<div class="svc-card">
		<div class="svc-card__bg ph"><?php echo $img1 ? simple_img( $img1, 'simple-wide', '', array( 'loading' => 'eager' ) ) : ''; ?></div>
		<div class="svc-card__top">
			<?php if ( $case ) : ?><p class="svc-card__title"><?php echo esc_html( $case ); ?></p><?php endif; ?>
			<?php if ( $tags ) : ?><p class="svc-card__tags"><?php echo esc_html( $tags ); ?></p><?php endif; ?>
		</div>
		<?php if ( $thumbs || $link ) : ?>
			<div class="svc-card__bottom">
				<?php if ( $link || $thumbs ) : ?><p class="svc-card__label"><?php echo esc_html( $lbl( 'svc_case_label' ) ); ?></p><?php endif; ?>
				<div class="svc-card__thumbs" data-thumbs>
					<?php if ( count( $thumbs ) > 4 ) : ?><button class="svc-card__nav svc-card__nav--prev" type="button" aria-label="Назад" data-dir="-1"><?php echo simple_arrow( 16 ); ?></button><?php endif; ?>
					<div class="svc-card__strip">
						<div class="svc-card__track">
							<?php if ( $thumbs ) : foreach ( $thumbs as $t ) :
								$href = ! empty( $t['project'] ) ? get_permalink( (int) $t['project'] ) : '';
								$tag  = $href ? 'a' : 'span';
								?>
								<<?php echo $tag; ?> class="svc-card__thumb"<?php echo $href ? ' href="' . esc_url( $href ) . '"' : ''; ?>><?php echo simple_img( (int) $t['img'], 'thumbnail', '', array( 'alt' => '' ) ); ?></<?php echo $tag; ?>>
							<?php endforeach; else : ?>
								<a class="svc-card__go" href="<?php echo esc_url( get_permalink( $link ) ); ?>" aria-label="<?php echo esc_attr( get_the_title( $link ) ); ?>"><?php echo simple_arrow( 24 ); ?></a>
							<?php endif; ?>
						</div>
					</div>
					<?php if ( count( $thumbs ) > 4 ) : ?><button class="svc-card__nav svc-card__nav--next" type="button" aria-label="Вперёд" data-dir="1"><?php echo simple_arrow( 16 ); ?></button><?php endif; ?>
				</div>
			</div>
		<?php endif; ?>
	</div>
</section>

<?php if ( trim( get_the_content() ) ) : ?>
	<section class="section prose svc-content"><?php the_content(); ?></section>
<?php endif; ?>

<?php if ( $stages ) : ?>
	<section class="section svc-stages">
		<div class="svc-two">
			<div>
				<h2 class="h3"><?php echo esc_html( $lbl( 'svc_stages_title' ) ); ?></h2>
				<p class="lead-s"><?php echo esc_html( $lbl( 'svc_stages_text' ) ); ?></p>
			</div>
			<div class="acc" data-acc>
				<?php foreach ( $stages as $i => $s ) :
					$open = ( 0 === $i );
					?>
					<div class="acc__item<?php echo $open ? ' is-open' : ''; ?>">
						<button class="acc__head" type="button" aria-expanded="<?php echo $open ? 'true' : 'false'; ?>">
							<span class="acc__num"><?php echo (int) ( $i + 1 ); ?>.</span>
							<span class="acc__title"><?php echo esc_html( $s[0] ); ?></span>
							<span class="acc__sign" aria-hidden="true"></span>
						</button>
						<div class="acc__body"<?php echo $open ? '' : ' hidden'; ?>><div class="acc__inner"><p class="acc__text"><?php echo esc_html( $s[1] ); ?></p></div></div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>
<?php endif; ?>

<?php if ( sf_raw( 'svc_why_text', $id ) || $why_title ) : ?>
	<section class="section svc-why">
	<div class="svc-two">
		<p class="svc-why__label"><?php echo esc_html( sf_raw( 'svc_why_label', $id ) ); ?></p>
		<div class="svc-why__body">
			<h2 class="svc-why__title"><?php foreach ( $why_title as $l ) { echo '<span>' . esc_html( $l ) . '</span>'; } ?></h2>
			<p class="svc-why__text"><?php echo esc_html( sf_raw( 'svc_why_text', $id ) ); ?></p>
		</div>
	</div>
</section>
<?php endif; ?>

<?php if ( $gets ) : ?>
	<section class="section svc-get">
		<div class="svc-two">
			<div>
				<h2 class="h3"><?php echo esc_html( $lbl( 'svc_get_title' ) ); ?></h2>
				<p class="lead-s"><?php echo esc_html( sf_raw( 'svc_get_sub', $id ) ); ?></p>
			</div>
			<ul class="get-list">
				<?php foreach ( $gets as $g ) : ?>
					<li><h3 class="h4"><?php echo esc_html( $g[0] ); ?></h3><p><?php echo esc_html( $g[1] ); ?></p></li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>
<?php endif; ?>

<?php if ( $more ) : ?>
	<section class="section svc-more">
		<div class="section__head">
			<h2 class="h3"><?php echo esc_html( $lbl( 'svc_more_title' ) ); ?></h2>
		</div>
		<div class="svc-more__grid">
			<?php foreach ( $more as $p ) {
				get_template_part( 'template-parts/project-card', null, array( 'post' => $p, 'label' => $lbl( 'svc_more_link' ) ) );
			} ?>
		</div>
		<div class="svc-more__foot">
			<p class="eyebrow"><?php echo esc_html( $lbl( 'svc_more_label' ) ); ?></p>
			<a class="link-arrow" href="<?php echo esc_url( simple_section_url( 'projects' ) ); ?>"><span><?php echo esc_html( $lbl( 'svc_more_btn' ) ); ?></span><?php echo simple_arrow( 20 ); ?></a>
		</div>
	</section>
<?php endif; ?>

<?php if ( $faq ) : ?>
	<section class="section svc-faq">
		<div class="svc-two">
			<h2 class="h3"><?php echo esc_html( $lbl( 'svc_faq_title' ) ); ?></h2>
			<div class="acc" data-acc>
				<?php foreach ( $faq as $i => $f ) :
					$open = ( 0 === $i );
					?>
					<div class="acc__item<?php echo $open ? ' is-open' : ''; ?>">
						<button class="acc__head" type="button" aria-expanded="<?php echo $open ? 'true' : 'false'; ?>">
							<span class="acc__num"><?php echo (int) ( $i + 1 ); ?>.</span>
							<span class="acc__title"><?php echo esc_html( $f[0] ); ?></span>
							<span class="acc__sign" aria-hidden="true"></span>
						</button>
						<div class="acc__body"<?php echo $open ? '' : ' hidden'; ?>><div class="acc__inner"><p class="acc__text"><?php echo esc_html( $f[1] ); ?></p></div></div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>
<?php endif; ?>

<?php get_footer();
