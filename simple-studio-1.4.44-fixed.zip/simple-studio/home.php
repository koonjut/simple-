<?php
get_header();
$pid = simple_blog_page_id();
?>

<section class="page-head">
	<p class="eyebrow"><?php echo esc_html( sf( 'blog_label', $pid ) ); ?></p>
	<h1 class="h1"><?php echo simple_br( sf( 'blog_title', $pid ) ); ?></h1>
	<p class="page-head__text"><?php echo esc_html( sf( 'blog_text', $pid ) ); ?></p>
</section>

<section class="section blog-grid">
	<?php
	$i = 0;
	if ( have_posts() ) :
		while ( have_posts() ) :
			the_post();
			get_template_part( 'template-parts/post-card', null, array( 'post' => get_post(), 'index' => $i + ( ( max( 1, get_query_var( 'paged' ) ) - 1 ) * (int) get_option( 'posts_per_page', 10 ) ) ) );
			$i++;
		endwhile;
	else :
		echo '<p class="empty">Пока нет статей.</p>';
	endif;
	?>
</section>

<?php
the_posts_pagination(
	array(
		'mid_size'  => 1,
		'prev_text' => '←',
		'next_text' => '→',
		'class'     => 'pagination',
	)
);
get_footer();
