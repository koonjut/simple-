<?php
get_header();
?>
<section class="section state state--page">
	<p class="state__code">404</p>
	<h1 class="state__title"><?php echo esc_html( simple_opt( 'e404_title' ) ); ?></h1>
	<p class="state__text"><?php echo esc_html( simple_opt( 'e404_text' ) ); ?></p>
	<?php echo simple_button( simple_opt( 'e404_btn' ), home_url( '/' ), 'primary' ); ?>
</section>
<?php get_footer();
