<?php
get_header();
the_post();
?>
<section class="page-head">
	<h1 class="h1"><?php the_title(); ?></h1>
</section>
<section class="section prose page-content"><?php the_content(); ?></section>
<?php get_footer();
