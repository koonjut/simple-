<?php
$p     = $args['post'];
$class = isset( $args['class'] ) ? $args['class'] : '';
$tags  = sf_raw( 'project_tags', $p->ID );
$cat   = get_the_terms( $p->ID, 'project_cat' );
$cat   = ( $cat && ! is_wp_error( $cat ) ) ? $cat[0]->name : '';
$desc  = $tags ? $tags : get_the_excerpt( $p );
?>
<a class="pcard <?php echo esc_attr( $class ); ?>" href="<?php echo esc_url( get_permalink( $p ) ); ?>">
	<span class="pcard__media ph"><?php echo simple_thumb( $p->ID, 'simple-card' ); ?></span>
	<?php $badge = (int) sf_raw( 'project_badge', $p->ID ); if ( $badge ) : ?><span class="pcard__badge"><?php echo simple_img( $badge, 'thumbnail', '', array( 'alt' => '' ) ); ?></span><?php endif; ?>
	<span class="pcard__body">
		<?php if ( $cat ) : ?><span class="pcard__cat eyebrow"><?php echo esc_html( $cat ); ?></span><?php endif; ?>
		<span class="pcard__title"><span><?php echo esc_html( get_the_title( $p ) ); ?></span><?php echo simple_arrow( 24, 'pcard__arrow' ); ?></span>
		<span class="pcard__desc"><?php echo esc_html( $desc ); ?></span>
	</span>
	<?php if ( ! empty( $args['label'] ) ) : ?>
		<span class="pcard__more"><span><?php echo esc_html( $args['label'] ); ?></span><?php echo simple_arrow( 20 ); ?></span>
	<?php endif; ?>
</a>
