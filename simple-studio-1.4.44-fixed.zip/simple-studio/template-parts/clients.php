<?php
$own     = ! empty( $args['items'] );
$clients = $own ? $args['items'] : simple_clients_list();
if ( ! $clients ) {
	return;
}
$marquee = ! empty( $args['marquee'] ) && count( $clients ) > (int) ( isset( $args['min'] ) ? $args['min'] : 0 );
$render  = function ( $hidden ) use ( $clients ) {
	echo '<ul class="clients__list"' . ( $hidden ? ' aria-hidden="true"' : '' ) . '>';
	foreach ( $clients as $c ) {
		$img = $c['img'] ? simple_img( $c['img'], 'medium' ) : '';
		echo '<li class="clients__item" title="' . esc_attr( $c['title'] ) . '">';
		echo $img ? $img : '<span class="clients__name">' . esc_html( $c['title'] ) . '</span>';
		echo '</li>';
	}
	echo '</ul>';
};
?>
<div class="clients<?php echo $marquee ? ' clients--marquee' : ''; ?><?php echo $own ? ' clients--own' : ''; ?>">
	<div class="clients__track">
		<?php
		if ( $marquee ) {

			for ( $g = 0; $g < 2; $g++ ) {
				echo '<div class="clients__group"' . ( $g ? ' aria-hidden="true"' : '' ) . '>';
				for ( $r = 0; $r < 3; $r++ ) {
					$render( true );
				}
				echo '</div>';
			}
		} else {
			$render( false );
		}
		?>
	</div>
</div>
