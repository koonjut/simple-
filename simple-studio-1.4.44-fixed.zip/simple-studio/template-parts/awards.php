<?php
$items = isset( $args['items'] ) ? $args['items'] : array();
if ( ! $items ) {
	$items = simple_home_slots( 'award' );
}
if ( ! $items ) {
	foreach ( get_posts( array( 'post_type' => 'award', 'posts_per_page' => -1, 'orderby' => 'menu_order date', 'order' => 'ASC', 'no_found_rows' => true ) ) as $a ) {
		$items[] = array(
			'title'   => get_the_title( $a ),
			'text'    => wp_strip_all_tags( $a->post_content ),
			'project' => sf_raw( 'award_project', $a->ID ),
			'img'     => (int) get_post_thumbnail_id( $a->ID ),
		);
	}
}
if ( ! $items ) {
	return;
}
$title = isset( $args['title'] ) ? $args['title'] : '';
?>
<section class="section awards">
	<?php if ( $title ) : ?><h2 class="h2-xl"><?php echo esc_html( $title ); ?></h2><?php endif; ?>
	<ul class="award-list">
		<?php foreach ( $items as $a ) : ?>
			<li class="award">
				<div class="award__head">
					<span class="award__icon ph"><?php echo $a['img'] ? simple_img( $a['img'], 'thumbnail' ) : ''; ?></span>
					<div>
						<h3 class="award__title"><?php echo esc_html( $a['title'] ); ?></h3>
						<p class="award__project"><?php echo esc_html( $a['project'] ); ?></p>
					</div>
				</div>
				<p class="award__text"><?php echo esc_html( $a['text'] ); ?></p>
			</li>
		<?php endforeach; ?>
	</ul>
</section>
