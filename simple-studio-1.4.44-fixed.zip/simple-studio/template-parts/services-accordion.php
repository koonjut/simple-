<?php
$items = isset( $args['items'] ) ? $args['items'] : array();
if ( ! $items ) {
	foreach ( get_posts( array( 'post_type' => 'service', 'posts_per_page' => -1, 'orderby' => 'menu_order date', 'order' => 'ASC', 'no_found_rows' => true ) ) as $s ) {
		$items[] = array( 'title' => get_the_title( $s ), 'text' => $s->post_excerpt, 'img' => (int) get_post_thumbnail_id( $s->ID ), 'page' => (int) $s->ID );
	}
}
if ( ! $items ) {
	return;
}
?>
<section class="section services-acc">
	<div class="section__head">
		<h2 class="h3"><?php echo esc_html( $args['title'] ); ?></h2>
		<a class="link-arrow" href="<?php echo esc_url( simple_section_url( 'services' ) ); ?>"><span><?php echo esc_html( $args['all_label'] ); ?></span><?php echo simple_arrow( 20 ); ?></a>
	</div>
	<div class="acc" data-acc>
		<?php foreach ( $items as $i => $s ) :
			$open = ( 0 === $i );
			?>
			<div class="acc__item<?php echo $open ? ' is-open' : ''; ?>">
				<button class="acc__head" type="button" aria-expanded="<?php echo $open ? 'true' : 'false'; ?>" aria-controls="svc-acc-<?php echo (int) $i; ?>">
					<span class="acc__title"><?php echo esc_html( $s['title'] ); ?></span>
					<span class="acc__sign" aria-hidden="true"></span>
				</button>
				<div class="acc__body" id="svc-acc-<?php echo (int) $i; ?>"<?php echo $open ? '' : ' hidden'; ?>>
					<div class="acc__inner">
						<p class="acc__text"><?php echo esc_html( $s['text'] ); ?></p>
						<?php echo ( $s['img'] ? simple_img( $s['img'], 'medium', 'acc__img' ) : '' ); ?>
						<a class="link-arrow link-arrow--small" href="<?php echo esc_url( ( $s['page'] ? get_permalink( $s['page'] ) : simple_section_url( 'services' ) ) ); ?>"><span><?php echo esc_html( $args['more_label'] ); ?></span><?php echo simple_arrow( 16 ); ?></a>
					</div>
				</div>
			</div>
		<?php endforeach; ?>
	</div>
</section>
