<?php
$team = get_posts( array( 'post_type' => 'team', 'posts_per_page' => -1, 'orderby' => 'menu_order date', 'order' => 'ASC', 'no_found_rows' => true ) );
if ( ! $team ) {
	return;
}
$bio = ! empty( $args['bio'] );
?>
<ul class="team-grid<?php echo $bio ? ' team-grid--bio' : ''; ?>">
	<?php foreach ( $team as $m ) : $link = esc_url( sf_raw( 'team_link', $m->ID ) ); ?>
		<li class="member">
			<div class="member__photo ph"><?php echo simple_thumb( $m->ID, 'simple-card' ); ?></div>
			<div class="member__info">
				<h3 class="member__name"><?php if ( $link ) : ?><a class="member__link" href="<?php echo $link; ?>" target="_blank" rel="noopener"><?php echo esc_html( get_the_title( $m ) ); ?><span aria-hidden="true"> ↗</span></a><?php else : echo esc_html( get_the_title( $m ) ); endif; ?></h3>
				<p class="member__role"><?php echo esc_html( sf_raw( 'team_role', $m->ID ) ); ?></p>
				<?php if ( $bio && sf_raw( 'team_bio', $m->ID ) ) : ?>
					<p class="member__bio"><?php echo esc_html( sf_raw( 'team_bio', $m->ID ) ); ?></p>
				<?php endif; ?>
			</div>
		</li>
	<?php endforeach; ?>
</ul>
