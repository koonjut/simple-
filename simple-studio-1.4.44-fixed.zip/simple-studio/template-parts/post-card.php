<?php
$p     = $args['post'];
$idx   = isset( $args['index'] ) ? (int) $args['index'] : 0;
$tone  = isset( $args['tone'] ) ? $args['tone'] : simple_card_tone( $idx );
$slot  = isset( $args['slot'] ) ? $args['slot'] : simple_card_slot( $idx );
$label = isset( $args['label'] ) ? $args['label'] : sfp( 'blog_card_label', 'blog' );
$thumb = get_post_thumbnail_id( $p );
$stk   = array( 'subtle' => 'sticker-eye.png', 'black' => 'sticker-star.png', 'accent' => 'sticker-brain-bike.png' );
$cls   = 'bcard bcard--' . $tone . ' bcard--' . $slot . ( $thumb ? ' has-thumb' : '' );
?>
<a class="<?php echo esc_attr( $cls ); ?>" href="<?php echo esc_url( get_permalink( $p ) ); ?>">
	<?php if ( $thumb ) : ?><span class="bcard__bg"><?php echo simple_img( $thumb, 'simple-card' ); ?></span><?php endif; ?>
	<span class="bcard__in">
		<span class="bcard__top">
			<span class="bcard__label"><?php echo esc_html( $label ); ?></span>
			<?php echo simple_post_sticker( $p->ID, $stk[ $tone ] ?? 'sticker-star.png', 'bcard__sticker' ); ?>
		</span>
		<span class="bcard__bottom">
			<span class="bcard__title"><?php echo esc_html( get_the_title( $p ) ); ?></span>
			<span class="bcard__text"><?php echo esc_html( wp_strip_all_tags( get_the_excerpt( $p ) ) ); ?></span>
		</span>
	</span>
</a>
