<?php
get_header();
$pid = get_queried_object_id();

$hero_img  = (int) sf_raw( 'home_hero_img', $pid );
$hero_link = sf_raw( 'home_hero_link', $pid );
$tags      = simple_lines( sf( 'home_tags', $pid ) );
?>

<?php

$slides = array();
$flagged = get_posts(
	array(
		'post_type'      => 'project',
		'posts_per_page' => 8,
		'orderby'        => 'menu_order date',
		'order'          => 'ASC',
		'meta_key'       => 'project_slide',
		'meta_value'     => '1',
		'no_found_rows'  => true,
	)
);
foreach ( $flagged as $p ) {
	$tag = sf_raw( 'project_tags', $p->ID );
	$cat = get_the_terms( $p->ID, 'project_cat' );
	$slides[] = array(
		'img'   => (int) get_post_thumbnail_id( $p->ID ),
		'tag'   => $tag ? $tag : ( ( $cat && ! is_wp_error( $cat ) ) ? implode( ', ', wp_list_pluck( $cat, 'name' ) ) : '' ),
		'title' => get_the_title( $p ),
		'sub'   => wp_strip_all_tags( get_the_excerpt( $p ) ),
		'url'   => get_permalink( $p ),
	);
}
if ( ! $slides ) {
	$slides[] = array(
		'img'   => $hero_img,
		'tag'   => sf( 'home_hero_tag', $pid ),
		'title' => sf( 'home_hero_title', $pid ),
		'sub'   => sf( 'home_hero_sub', $pid ),
		'url'   => $hero_link,
	);
}
?>
<section class="home-hero" data-slider<?php echo count( $slides ) > 1 ? ' data-autoplay="3000"' : ''; ?> aria-roledescription="carousel" aria-label="Проекты">
	<?php foreach ( $slides as $i => $sl ) : ?>
		<div class="home-hero__slide<?php echo 0 === $i ? ' is-active' : ''; ?>" data-slide<?php echo 0 === $i ? '' : ' aria-hidden="true"'; ?>>
			<div class="home-hero__bg ph"><?php echo $sl['img'] ? simple_img( $sl['img'], 'simple-wide', '', array( 'loading' => 0 === $i ? 'eager' : 'lazy' ) ) : ''; ?></div>
			<div class="home-hero__text">
				<div class="home-hero__col">
					<p class="home-hero__tag"><?php echo esc_html( $sl['tag'] ); ?></p>
					<<?php echo 0 === $i ? 'h1' : 'h2'; ?> class="home-hero__title">
						<?php if ( $sl['url'] ) : ?>
							<a href="<?php echo esc_url( $sl['url'] ); ?>"><?php echo esc_html( $sl['title'] ); ?><?php echo simple_arrow( 56, 'home-hero__arrow' ); ?></a>
						<?php else : ?>
							<span class="home-hero__title-in"><?php echo esc_html( $sl['title'] ); ?><?php echo simple_arrow( 56, 'home-hero__arrow' ); ?></span>
						<?php endif; ?>
					</<?php echo 0 === $i ? 'h1' : 'h2'; ?>>
					<p class="home-hero__sub"><?php echo esc_html( $sl['sub'] ); ?></p>
				</div>
			</div>
		</div>
	<?php endforeach; ?>
	<?php if ( count( $slides ) > 1 ) : ?>
		<button type="button" class="home-hero__pause" data-slider-pause aria-pressed="false">Пауза автопоказа</button>
		<div class="home-hero__dots" role="group" aria-label="Выбор слайда">
			<?php foreach ( $slides as $i => $sl ) : ?>
				<button type="button" class="home-hero__dot<?php echo 0 === $i ? ' is-active' : ''; ?>" data-dot="<?php echo (int) $i; ?>" aria-pressed="<?php echo 0 === $i ? 'true' : 'false'; ?>" aria-label="Слайд <?php echo (int) ( $i + 1 ); ?>"></button>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</section>

<section class="section home-intro">
	<p class="eyebrow eyebrow--mono"><?php echo simple_br( sf( 'home_intro_label', $pid ) ); ?></p>
	<h2 class="h1"><?php echo esc_html( sf( 'home_intro_title', $pid ) ); ?> <?php echo simple_sticker_img( 'field:home_sticker_eye', $pid, 'sticker-eye.png', 73, 64, 'home-intro__eye' ); ?></h2>
	<p class="home-intro__text"><?php echo esc_html( sf( 'home_intro_text', $pid ) ); ?></p>
	<?php if ( $tags ) : ?>
		<ul class="home-intro__tags">
			<?php foreach ( $tags as $t ) : ?><li><?php echo esc_html( $t ); ?></li><?php endforeach; ?>
		</ul>
	<?php endif; ?>
	<a class="home-intro__pill" href="<?php echo esc_url( simple_section_url( 'projects' ) ); ?>">
		<?php echo simple_bike( '', false, (int) sf_raw( 'home_sticker_bike', $pid ) ); ?>
		<span class="tag-pink"><?php echo esc_html( sf( 'home_pill', $pid ) ); ?></span>
	</a>
</section>

<section class="manifesto">
	<div class="manifesto__inner">
		<h2 class="manifesto__title"><?php echo esc_html( sf( 'home_manifesto_title', $pid ) ); ?></h2>
		<p class="manifesto__text"><?php echo esc_html( sf( 'home_manifesto_text', $pid ) ); ?></p>
	</div>
	<?php get_template_part( 'template-parts/clients', null, array( 'marquee' => true ) ); ?>
</section>

<section class="section approach">
	<div class="approach__text">
		<p><?php echo esc_html( sf( 'home_approach_1', $pid ) ); ?></p>
		<p><?php echo simple_br( sf( 'home_approach_2', $pid ) ); ?></p>
	</div>
	<?php echo simple_sticker_img( 'field:home_sticker_brain', $pid, 'sticker-brain-bike.png', 88, 74, 'approach__sticker' ); ?>
</section>

<?php
get_template_part( 'template-parts/awards', null, array( 'title' => sf( 'home_awards_title', $pid ), 'items' => simple_home_slots( 'award', 50, $pid ) ) );
get_template_part(
	'template-parts/services-accordion',
	null,
	array(
		'items'      => simple_home_slots( 'service', 50, $pid ),
		'title'      => sf( 'home_services_title', $pid ),
		'all_label'  => sf( 'home_services_all', $pid ),
		'more_label' => sf( 'home_service_more', $pid ),
	)
);

get_footer();
