jQuery(function ($) {
	function renumber($box) {
		$box.find('.srep__row').each(function (i) {
			$(this).find('.srep__num').text(($box.data('label') || '№') + ' ' + (i + 1));
		});
	}
	$('.srep').each(function () {
		var $box = $(this), $list = $box.find('.srep__list'), tpl = $box.find('.srep__tpl').html();
		var n = Date.now();
		renumber($box);
		$box.on('click', '.srep__add', function () {
			n++;
			$list.append(tpl.replace(/__i__/g, n));
			renumber($box);
		});
		$box.on('click', '.srep__del', function () {
			if (window.confirm('Удалить эту строку?')) { $(this).closest('.srep__row').remove(); renumber($box); }
		});
		$box.on('click', '.srep__up', function () {
			var r = $(this).closest('.srep__row'); r.prev().before(r); renumber($box);
		});
		$box.on('click', '.srep__down', function () {
			var r = $(this).closest('.srep__row'); r.next().after(r); renumber($box);
		});
		$box.on('click', '.srep__clear', function () {
			var w = $(this).closest('[data-img]'); w.find('input').val(''); w.find('.srep__prev').empty();
		});
		$box.on('click', '.srep__pick', function (e) {
			e.preventDefault();
			var w = $(this).closest('[data-img]');
			var frame = wp.media({ title: 'Выберите изображение', multiple: false, library: { type: 'image' } });
			frame.on('select', function () {
				var a = frame.state().get('selection').first().toJSON();
				w.find('input').val(a.id);
				var u = (a.sizes && a.sizes.thumbnail) ? a.sizes.thumbnail.url : a.url;
				w.find('.srep__prev').html('<img src="' + u + '" alt="">');
			});
			frame.open();
		});
	});
});

jQuery(function ($) {
	function sync(box) {
		var $l = $(box).closest('label');
		$l.find('.srep__rich-src').val($(box).html());
	}
	try { document.execCommand('defaultParagraphSeparator', false, 'p'); } catch (e) {}
	$(document).on('mousedown', '.srep__fmt [data-cmd]', function (e) { e.preventDefault(); });
	$(document).on('click', '.srep__fmt [data-cmd]', function () {
		var $l = $(this).closest('label'), box = $l.find('.srep__rich')[0], c = $(this).data('cmd');
		box.focus();
		if (c === 'link') {
			var url = window.prompt('Адрес ссылки (https://…)', 'https://');
			if (!url) { return; }
			document.execCommand('createLink', false, url);
		} else {
			document.execCommand(c, false, null);
		}
		sync(box);
	});
	$(document).on('input blur', '.srep__rich', function () { sync(this); });
	$(document).on('paste', '.srep__rich', function (e) {
		e.preventDefault();
		var t = (e.originalEvent.clipboardData || window.clipboardData).getData('text/plain');
		document.execCommand('insertText', false, t);
	});
	$(document).on('submit', 'form#post', function () {
		$('.srep__rich').each(function () { sync(this); });
	});
});

jQuery(function ($) {
	function applyType($row) {
		var t = $row.find('.srep__type').val() || 'media';
		$row.find('[data-show]').each(function () {
			$(this).toggle((' ' + $(this).attr('data-show') + ' ').indexOf(' ' + t + ' ') !== -1);
		});
	}
	function all() { $('.srep[data-kind="case_blocks"] .srep__row').each(function () { applyType($(this)); }); }
	all();
	$(document).on('change', '.srep__type', function () { applyType($(this).closest('.srep__row')); });
	$(document).on('click', '.srep[data-kind="case_blocks"] .srep__add', function () { setTimeout(all, 30); });
	$(document).on('click', '.srep__pickvideo', function (e) {
		e.preventDefault();
		var $in = $(this).siblings('input');
		var frame = wp.media({ title: 'Выберите видео', multiple: false, library: { type: 'video' } });
		frame.on('select', function () { $in.val(frame.state().get('selection').first().toJSON().url); });
		frame.open();
	});
});
