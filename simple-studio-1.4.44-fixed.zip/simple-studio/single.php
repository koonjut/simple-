<?php
get_header();
the_post();
$bid   = simple_blog_page_id();
$parts = simple_article_parts( apply_filters( 'the_content', get_the_content() ) );
$parts = simple_article_sections( get_the_ID(), $parts );
$thumb = get_post_thumbnail_id();
$label = sf( 'blog_card_label', $bid );

$related = get_posts(
	array(
		'post_type'      => 'post',
		'posts_per_page' => 2,
		'post__not_in'   => array( get_the_ID() ),
		'no_found_rows'  => true,
	)
);
?>

<article>
	<div class="art-nav">
		<a class="btn btn--ghost" href="<?php echo esc_url( simple_section_url( 'blog' ) ); ?>"><span><?php echo esc_html( sf( 'art_back', $bid ) ); ?></span></a>
		<p class="art-nav__label"><?php echo esc_html( $label ); ?></p>
	</div>

	<header class="art-hero">
		<div class="art-hero__card">
			<div>
				<h1 class="art-hero__title"><?php the_title(); ?></h1>
				<p class="art-hero__lead"><?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); ?></p>
			</div>
			<p class="art-hero__foot"><span class="eyebrow--mono"><?php echo esc_html( $label ); ?></span><?php echo simple_post_sticker( get_the_ID(), 'sticker-star.png', 'art-hero__sticker' ); ?></p>
		</div>
		<div class="art-hero__img ph"><?php echo $thumb ? simple_img( $thumb, 'simple-wide', '', array( 'loading' => 'eager' ) ) : ''; ?></div>
	</header>

	<div class="art-intro">
		<?php if ( $parts['toc'] ) : ?>
			<aside class="toc" aria-label="<?php echo esc_attr( sf( 'art_toc_label', $bid ) ); ?>">
				<p class="eyebrow"><?php echo esc_html( sf( 'art_toc_label', $bid ) ); ?></p>
				<ol>
					<?php foreach ( $parts['toc'] as $t ) : ?>
						<li><a href="#<?php echo esc_attr( $t['id'] ); ?>"><?php echo esc_html( $t['title'] ); ?></a></li>
					<?php endforeach; ?>
				</ol>
			</aside>
		<?php else : ?>
			<div></div>
		<?php endif; ?>
		<div class="art-intro__text prose"><?php echo $parts['intro']; ?></div>
	</div>

	<div class="art-body prose"><?php echo $parts['body']; ?></div>

	<div class="art-end">
		<a class="btn btn--ghost" href="<?php echo esc_url( simple_section_url( 'blog' ) ); ?>"><span><?php echo esc_html( sf( 'art_back', $bid ) ); ?></span></a>
		<a class="btn btn--ghost" href="#top"><span><?php echo esc_html( sf( 'art_up', $bid ) ); ?></span></a>
	</div>
</article>

<?php if ( $related ) : ?>
	<section class="section related">
		<h2 class="h3"><?php echo esc_html( sf( 'art_more_title', $bid ) ); ?></h2>
		<div class="blog-grid">
			<?php foreach ( $related as $i => $r ) {
				get_template_part( 'template-parts/post-card', null, array( 'post' => $r, 'index' => $i, 'label' => $label, 'tone' => $i ? 'black' : 'accent', 'slot' => 'half' ) );
			} ?>
		</div>
	</section>
<?php endif; ?>

<?php get_footer();
