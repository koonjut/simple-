<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main">Перейти к содержимому</a>

<header class="site-header" id="top">
	<div class="site-header__brand"><?php simple_logo(); ?></div>

	<nav class="site-header__nav" aria-label="Главное меню">
		<?php simple_menu( 'primary', 'nav-list' ); ?>
	</nav>

	<div class="site-header__actions">
		<?php simple_lang_switcher(); ?>
		<?php echo simple_button( simple_opt( 'cta_label' ), simple_opt( 'cta_url' ), 'primary', true, ' data-modal-open' ); ?>
	</div>

	<button class="menu-toggle" type="button" aria-expanded="false" aria-controls="mobile-menu" data-menu-open>
		<span><?php echo esc_html( simple_opt( 'menu_open' ) ); ?></span>
		<span class="menu-toggle__icon" aria-hidden="true"><i></i><i></i></span>
	</button>
</header>

<div class="mobile-menu" id="mobile-menu" hidden>
	<div class="mobile-menu__top">
		<?php simple_logo(); ?>
		<button class="menu-toggle menu-toggle--close" type="button" data-menu-close>
			<span><?php echo esc_html( simple_opt( 'menu_close' ) ); ?></span>
			<span class="menu-toggle__icon is-open" aria-hidden="true"><i></i><i></i></span>
		</button>
	</div>
	<p class="mobile-menu__caption eyebrow eyebrow--mono"><?php echo esc_html( simple_opt( 'menu_caption' ) ); ?></p>
	<nav aria-label="Мобильное меню">
		<?php simple_menu( 'mobile', 'mobile-menu__list' ); ?>
	</nav>
	<div class="mobile-menu__bottom">
		<a class="mobile-menu__contact" href="mailto:<?php echo esc_attr( simple_opt( 'email' ) ); ?>"><?php echo esc_html( simple_opt( 'email' ) ); ?></a>
		<a class="mobile-menu__contact" href="tel:<?php echo esc_attr( preg_replace( '/[^\d+]/', '', simple_opt( 'phone' ) ) ); ?>"><?php echo esc_html( simple_opt( 'phone' ) ); ?></a>
		<?php simple_lang_switcher( true ); ?>
	</div>
</div>

<main id="main" class="site-main">
