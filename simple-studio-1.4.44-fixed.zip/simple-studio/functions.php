<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SIMPLE_VERSION', '1.4.44' );
define( 'SIMPLE_DIR', get_template_directory() );
define( 'SIMPLE_URI', get_template_directory_uri() );

require_once SIMPLE_DIR . '/inc/defaults.php';
require_once SIMPLE_DIR . '/inc/helpers.php';
require_once SIMPLE_DIR . '/inc/setup.php';
require_once SIMPLE_DIR . '/inc/post-types.php';
require_once SIMPLE_DIR . '/inc/settings.php';
require_once SIMPLE_DIR . '/inc/acf-fields.php';
require_once SIMPLE_DIR . '/inc/form.php';
require_once SIMPLE_DIR . '/inc/repeater.php';
require_once SIMPLE_DIR . '/inc/article.php';
require_once SIMPLE_DIR . '/inc/seo.php';
require_once SIMPLE_DIR . '/inc/seed.php';
