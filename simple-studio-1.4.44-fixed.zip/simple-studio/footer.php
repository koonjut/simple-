<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$exclude = is_singular( 'project' ) ? array( get_the_ID() ) : array();
$fp_args = array(
	'post_type'      => 'project',
	'posts_per_page' => 1,
	'orderby'        => 'menu_order date',
	'order'          => 'ASC',
	'post__not_in'   => $exclude,
	'no_found_rows'  => true,
);

$fp = get_posts( array_merge( $fp_args, array( 'meta_key' => 'project_footer', 'meta_value' => '1' ) ) );
if ( ! $fp ) {
	$fp = get_posts( $fp_args );
}
$fp      = $fp ? $fp[0] : null;
$email   = simple_opt( 'email' );
$phone   = simple_opt( 'phone' );
?>
</main>

<footer class="site-footer">
	<?php if ( $fp && apply_filters( 'simple_footer_show_contact', true ) ) :
		$alt   = (int) sf_raw( 'project_cover_alt', $fp->ID );
		$img   = $alt ? $alt : (int) get_post_thumbnail_id( $fp->ID );
		$extra = simple_opt_image_id( 'footer_project' );
		if ( $extra ) {
			$img = $extra;
		}
		?>
		<section class="footer-more">
			<div class="footer-more__head">
				<div class="footer-more__title">
					<h2><?php echo esc_html( simple_opt( 'footer_more' ) ); ?></h2>
					<?php echo simple_sticker_img( 'opt:star', 0, 'sticker-star.png', 48, 48, 'footer-more__star' ); ?>
				</div>
				<?php echo simple_button( simple_opt( 'footer_more_all' ), simple_section_url( 'projects' ), 'dark' ); ?>
			</div>
			<a class="footer-more__card" href="<?php echo esc_url( get_permalink( $fp ) ); ?>">
				<span class="footer-more__text">
					<strong><?php echo esc_html( get_the_title( $fp ) ); ?></strong>
					<span><?php echo esc_html( get_the_excerpt( $fp ) ); ?></span>
				</span>
				<span class="footer-more__media ph"><?php echo $img ? simple_img( $img, 'simple-card' ) : ''; ?></span>
			</a>
		</section>
	<?php endif; ?>

	<?php if ( apply_filters( 'simple_footer_show_contact', true ) ) : ?>
	<section class="footer-contact" id="contact">
		<div class="footer-contact__form">
			<div class="footer-contact__invite">
				<p><?php echo esc_html( simple_opt( 'footer_invite' ) ); ?></p>
			</div>
			<?php simple_lead_form( 'footer' ); ?>
		</div>
		<div class="footer-contact__info">
			<p class="footer-contact__text"><?php echo esc_html( simple_opt( 'footer_text' ) ); ?></p>
			<dl class="contact-list">
				<div>
					<dt><?php echo esc_html( simple_opt( 'label_email' ) ); ?></dt>
					<dd><a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a></dd>
				</div>
				<div>
					<dt><?php echo esc_html( simple_opt( 'label_phone' ) ); ?></dt>
					<dd><a href="tel:<?php echo esc_attr( preg_replace( '/[^\d+]/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a></dd>
				</div>
			</dl>
		</div>
	</section>
	<?php endif; ?>

	<section class="footer-nav">
		<div class="footer-nav__logo"><?php simple_logo( 'logo logo--light', true ); ?></div>
		<nav class="footer-nav__col" aria-label="Подвал 1"><?php simple_menu( 'footer_1', 'footer-list' ); ?></nav>
		<nav class="footer-nav__col" aria-label="Подвал 2"><?php simple_menu( 'footer_2', 'footer-list' ); ?></nav>
		<nav class="footer-nav__col" aria-label="Соцсети"><?php simple_menu( 'footer_social', 'footer-list' ); ?></nav>
	</section>

	<div class="footer-copy">
		<span><?php echo esc_html( simple_opt( 'copy_left' ) ); ?></span>
		<span><?php echo esc_html( simple_opt( 'copy_right' ) ); ?></span>
	</div>
</footer>

<div class="modal" id="lead-modal" hidden role="dialog" aria-modal="true" aria-labelledby="lead-modal-title">
	<div class="modal__panel">
		<button type="button" class="modal__close" data-modal-close><?php echo esc_html( simple_opt( 'modal_close' ) ); ?> <span aria-hidden="true">×</span></button>
		<h2 class="modal__title" id="lead-modal-title"><?php echo esc_html( simple_opt( 'modal_title' ) ); ?></h2>
		<?php simple_modal_form(); ?>
	</div>
</div>

<?php wp_footer(); ?>
</body>
</html>
