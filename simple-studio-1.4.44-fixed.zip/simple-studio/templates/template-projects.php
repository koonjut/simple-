<?php
/**
 * Template Name: Кейсы (список)
 */
get_header();
$pid    = get_queried_object_id();
$cats   = get_terms( array( 'taxonomy' => 'project_cat', 'hide_empty' => true ) );
$active = isset( $_GET['cat'] ) ? sanitize_title( wp_unslash( $_GET['cat'] ) ) : '';
$args   = array( 'post_type' => 'project', 'posts_per_page' => -1, 'orderby' => 'menu_order date', 'order' => 'ASC', 'no_found_rows' => true );
if ( $active ) {
	$args['tax_query'] = array( array( 'taxonomy' => 'project_cat', 'field' => 'slug', 'terms' => $active ) );
}
$projects = get_posts( $args );
$base     = get_permalink( $pid );
$total    = (int) wp_count_posts( 'project' )->publish;
$shown    = count( $projects );
$cur      = $active ? get_term_by( 'slug', $active, 'project_cat' ) : false;
$cur_name = $cur ? $cur->name : sf( 'prjs_all', $pid );
?>

<section class="page-head projects-head">
	<p class="eyebrow"><?php echo esc_html( sf( 'prjs_label', $pid ) ); ?></p>
	<div class="projects-head__row">
		<h1 class="h1"><?php echo simple_br( sf( 'prjs_title', $pid ) ); ?></h1>
		<?php echo simple_sticker_img( 'field:prjs_sticker', $pid, 'sticker-eye-lg.png', 88, 77, 'projects-head__eye' ); ?>
	</div>
</section>

<?php if ( $cats && ! is_wp_error( $cats ) ) : ?>
	<div class="projects-bar">
		<button type="button" class="filters-btn" data-sheet-open aria-haspopup="dialog"><span><?php echo esc_html( simple_opt( 'filters_btn' ) ); ?> +</span><?php echo $active ? '<i class="filters-btn__dot" aria-hidden="true"></i>' : ''; ?></button>
		<span class="projects-bar__count"><?php echo esc_html( ( $active ? $cur_name : 'Все' ) . ' · ' . ( $active ? $shown : $total ) ); ?></span>
	</div>
	<nav class="filter" aria-label="Фильтр кейсов">
		<a class="filter__item<?php echo $active ? '' : ' is-active'; ?>" href="<?php echo esc_url( $base ); ?>"><?php echo esc_html( sf( 'prjs_all', $pid ) . ' · ' . $total ); ?></a>
		<?php foreach ( $cats as $c ) : ?>
			<a class="filter__item<?php echo $active === $c->slug ? ' is-active' : ''; ?>" href="<?php echo esc_url( add_query_arg( 'cat', $c->slug, $base ) ); ?>"><?php echo esc_html( $c->name ); ?></a>
		<?php endforeach; ?>
	</nav>
	<div class="sheet" id="filters-sheet" hidden role="dialog" aria-modal="true" aria-labelledby="filters-title">
		<div class="sheet__panel">
			<div class="sheet__head">
				<h2 id="filters-title"><?php echo esc_html( simple_opt( 'filters_title' ) ); ?></h2>
				<button type="button" class="sheet__close" data-sheet-close aria-label="<?php echo esc_attr( simple_opt( 'modal_close' ) ); ?>">×</button>
			</div>
			<div class="sheet__list" data-sheet-list>
				<button type="button" class="sheet__opt<?php echo $active ? '' : ' is-active'; ?>" data-href="<?php echo esc_url( $base ); ?>"><?php echo esc_html( sf( 'prjs_all', $pid ) ); ?></button>
				<?php foreach ( $cats as $c ) : ?>
					<button type="button" class="sheet__opt<?php echo $active === $c->slug ? ' is-active' : ''; ?>" data-href="<?php echo esc_url( add_query_arg( 'cat', $c->slug, $base ) ); ?>"><?php echo esc_html( $c->name ); ?></button>
				<?php endforeach; ?>
			</div>
			<a class="btn btn--primary sheet__show" href="<?php echo esc_url( $active ? add_query_arg( 'cat', $active, $base ) : $base ); ?>" data-sheet-show><span><?php echo esc_html( simple_opt( 'filters_show' ) ); ?></span><?php echo simple_arrow( 20 ); ?></a>
			<a class="sheet__reset" href="<?php echo esc_url( $base ); ?>"><?php echo esc_html( simple_opt( 'filters_reset' ) ); ?></a>
		</div>
	</div>
<?php endif; ?>

<section class="section projects-grid">
	<?php

	foreach ( $projects as $i => $p ) {
		$pos  = $i % 6;
		$wide = ( 0 === $pos || 5 === $pos );
		get_template_part( 'template-parts/project-card', null, array( 'post' => $p, 'class' => $wide ? 'pcard--wide' : '' ) );
	}
	if ( ! $projects ) {
		?>
		<div class="state">
			<h2 class="state__title"><?php echo esc_html( simple_opt( 'empty_title' ) ); ?></h2>
			<p class="state__text"><?php echo esc_html( simple_opt( 'empty_text' ) ); ?></p>
			<?php echo simple_button( simple_opt( 'filters_reset' ), $base, 'primary' ); ?>
		</div>
		<?php
	}
	?>
</section>

<?php get_footer();
