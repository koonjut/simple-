<?php
/**
 * Template Name: О нас
 */
get_header();
$pid = get_queried_object_id();
?>

<section class="page-head">
	<p class="eyebrow eyebrow--spaced"><?php echo esc_html( sf( 'about_label', $pid ) ); ?></p>
	<h1 class="h1 about-title"><?php echo esc_html( sf( 'about_title', $pid ) ); ?> <?php echo simple_sticker_img( 'field:about_sticker', $pid, 'sticker-dream-team.png', 75, 74, 'about-title__sticker' ); ?></h1>
	<p class="page-head__text"><?php echo simple_br( sf( 'about_text', $pid ) ); ?></p>
</section>

<section class="section about-photos">
	<h2 class="h2-xl"><?php echo esc_html( sf( 'about_photos_title', $pid ) ); ?></h2>
	<?php $photos = simple_about_photos( $pid ); ?>
	<div class="gallery" data-gallery tabindex="0" aria-roledescription="carousel" aria-label="<?php echo esc_attr( sf( 'about_photos_title', $pid ) ); ?>">
		<div class="gallery__track">
			<?php foreach ( $photos as $ph ) : ?>
				<figure class="gallery__item<?php echo $ph['wide'] ? ' is-wide' : ''; ?>"<?php echo $ph['wide'] ? ' data-wide="1"' : ''; ?>>
					<div class="ph"><?php echo simple_img( $ph['img'], 'simple-wide' ); ?></div>
					<figcaption class="eyebrow"><?php echo esc_html( $ph['caption'] ); ?></figcaption>
				</figure>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section class="section about-approach">
	<p class="eyebrow"><?php echo esc_html( sf( 'about_appr_label', $pid ) ); ?></p>
	<h2 class="h2-xl"><?php echo simple_br( sf( 'about_appr_title', $pid ) ); ?></h2>
	<div class="cols-3">
		<?php for ( $i = 1; $i <= 3; $i++ ) : ?>
			<div class="principle">
				<h3 class="h4"><?php echo esc_html( sf( "about_prin_{$i}_title", $pid ) ); ?></h3>
				<p><?php echo esc_html( sf( "about_prin_{$i}_text", $pid ) ); ?></p>
			</div>
		<?php endfor; ?>
	</div>
</section>

<section class="section about-facts">
	<p class="eyebrow"><?php echo esc_html( sf( 'about_facts_label', $pid ) ); ?></p>
	<div class="cols-4">
		<?php for ( $i = 1; $i <= 4; $i++ ) : ?>
			<div class="fact">
				<p class="fact__num"><?php echo esc_html( sf( "about_fact_{$i}_num", $pid ) ); ?></p>
				<p class="fact__title"><?php echo esc_html( sf( "about_fact_{$i}_title", $pid ) ); ?></p>
				<p class="fact__text"><?php echo esc_html( sf( "about_fact_{$i}_text", $pid ) ); ?></p>
			</div>
		<?php endfor; ?>
	</div>
</section>

<section class="section about-team">
	<p class="eyebrow"><?php echo esc_html( sf( 'about_team_label', $pid ) ); ?></p>
	<div class="about-team__head">
		<h2 class="h2-xl"><?php echo simple_br( sf( 'about_team_title', $pid ) ); ?></h2>
		<p class="about-team__text"><?php echo esc_html( sf( 'about_team_text', $pid ) ); ?></p>
	</div>
	<?php get_template_part( 'template-parts/team-grid' ); ?>
</section>

<section class="section about-clients">
	<p class="eyebrow"><?php echo esc_html( sf( 'about_clients_label', $pid ) ); ?></p>
	<?php get_template_part( 'template-parts/clients', null, array( 'marquee' => true, 'min' => 4, 'items' => simple_clients_about_list( $pid ) ) ); ?>
</section>

<?php
get_template_part( 'template-parts/awards', null, array( 'title' => sf( 'about_awards_title', $pid ) ) );
get_footer();
