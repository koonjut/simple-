<?php
/**
 * Template Name: Услуги (список)
 */
get_header();
$pid      = get_queried_object_id();
$services = get_posts( array( 'post_type' => 'service', 'posts_per_page' => -1, 'orderby' => 'menu_order date', 'order' => 'ASC', 'no_found_rows' => true ) );
?>

<section class="page-head svcs-head">
	<p class="eyebrow"><?php echo esc_html( sf( 'svcs_label', $pid ) ); ?></p>
	<h1 class="h1 svcs-head__title"><?php echo esc_html( sf( 'svcs_title', $pid ) ); ?> <?php echo simple_sticker_img( 'field:svcs_sticker', $pid, 'sticker-bike-blue.png', 83, 39, 'svcs-head__sticker' ); ?></h1>
	<p class="page-head__text"><?php echo esc_html( sf( 'svcs_text', $pid ) ); ?></p>
</section>

<section class="section svc-list">
	<?php foreach ( $services as $i => $s ) : ?>
		<a class="svc-row" href="<?php echo esc_url( get_permalink( $s ) ); ?>">
			<span class="svc-row__title"><?php echo esc_html( get_the_title( $s ) ); ?></span>
			<span class="svc-row__text"><?php echo esc_html( $s->post_excerpt ); ?></span>
			<span class="svc-row__go"><?php echo simple_arrow( 18 ); ?></span>
		</a>
	<?php endforeach; ?>
</section>

<?php get_footer();
