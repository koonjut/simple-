<?php
/**
 * Template Name: Команда
 */
get_header();
$pid   = get_queried_object_id();
$lines = simple_lines( sf( 'team_title', $pid ) );
$first = $lines ? array_shift( $lines ) : '';
?>

<section class="page-head team-head">
	<p class="eyebrow"><?php echo esc_html( sf( 'team_label', $pid ) ); ?></p>
	<h1 class="h1 team-head__title">
		<span class="team-head__l1"><?php echo esc_html( $first ); ?><?php echo simple_sticker_img( 'field:team_sticker', $pid, 'sticker-eye.png', 74, 65, 'team-head__sticker' ); ?></span>
		<?php foreach ( $lines as $l ) : ?><span class="team-head__l"><?php echo esc_html( $l ); ?></span><?php endforeach; ?>
	</h1>
	<p class="page-head__text"><?php echo esc_html( sf( 'team_text', $pid ) ); ?></p>
</section>

<section class="section team-people">
	<?php get_template_part( 'template-parts/team-grid', null, array( 'bio' => true ) ); ?>

	<div class="team-join">
		<?php echo simple_sticker_img( 'field:team_join_sticker', $pid, 'sticker-dream-team.png', 143, 141, 'team-join__sticker' ); ?>
		<p class="team-join__label"><?php echo esc_html( sf( 'team_join_label', $pid ) ); ?></p>
		<h2 class="team-join__title"><?php echo simple_br( sf( 'team_join_title', $pid ) ); ?></h2>
		<div class="team-join__side">
			<p><?php echo esc_html( sf( 'team_join_text', $pid ) ); ?></p>
			<?php echo simple_button( sf( 'team_join_btn', $pid ), sf( 'team_join_link', $pid ), 'pink' ); ?>
		</div>
	</div>
</section>

<?php get_footer();
