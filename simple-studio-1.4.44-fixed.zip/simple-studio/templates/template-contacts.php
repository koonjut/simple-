<?php
/**
 * Template Name: Контакты
 */
get_header();
$pid   = get_queried_object_id();
$email = simple_opt( 'email' );
$phone = simple_opt( 'phone' );
?>

<section class="page-head contacts-head">
	<p class="eyebrow eyebrow--muted"><?php echo esc_html( sf( 'cont_label', $pid ) ); ?></p>
	<h1 class="h1 h1--xl"><?php echo simple_br( sf( 'cont_title', $pid ) ); ?></h1>
	<p class="page-head__text"><?php echo esc_html( sf( 'cont_text', $pid ) ); ?></p>
	<?php echo simple_sticker_img( 'field:cont_sticker', $pid, 'sticker-eye-lg.png', 108, 95, 'contacts-head__eye' ); ?>
</section>

<section class="contacts-body" id="contact">
	<div class="contacts-body__left">
		<p class="eyebrow eyebrow--lime"><?php echo esc_html( sf( 'cont_left_label', $pid ) ); ?></p>
		<h2 class="h3"><?php echo simple_br( sf( 'cont_left_title', $pid ) ); ?></h2>
		<p><?php echo esc_html( sf( 'cont_left_text', $pid ) ); ?></p>
		<dl class="contacts-body__direct">
			<dt><?php echo esc_html( sf( 'cont_lbl_email', $pid ) ); ?></dt>
			<dd><a class="is-underline" href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a></dd>
			<dt><?php echo esc_html( sf( 'cont_lbl_phone', $pid ) ); ?></dt>
			<dd><a href="tel:<?php echo esc_attr( preg_replace( '/[^\d+]/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a></dd>
		</dl>
	</div>
	<div class="contacts-body__right">
		<h2 class="h3"><?php echo esc_html( sf( 'cont_form_title', $pid ) ); ?></h2>
		<?php simple_contact_form( $pid ); ?>
	</div>
</section>

<?php

add_filter( 'simple_footer_show_contact', '__return_false' );
get_footer();
