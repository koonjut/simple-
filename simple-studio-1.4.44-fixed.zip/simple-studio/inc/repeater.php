<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function simple_rep_defs() {
	return array(
		'photos'   => array(
			'title'  => 'Фото «Внутри Simple»',
			'add'    => '+ Добавить фото',
			'fields' => array(
				'img'     => array( 'Фото', 'img' ),
				'caption' => array( 'Подпись (например: 01 / ПРОЦЕСС)', 'text' ),
			),
		),
		'awards'   => array(
			'title'  => 'Награды',
			'add'    => '+ Добавить награду',
			'fields' => array(
				'img'     => array( 'Иконка', 'img' ),
				'title'   => array( 'Название (например: Pentawards / Gold)', 'text' ),
				'project' => array( 'Проект', 'text' ),
				'text'    => array( 'Описание', 'ta' ),
			),
		),
		'clients'  => array(
			'title'  => 'Клиенты (логотипы)',
			'add'    => '+ Добавить клиента',
			'fields' => array(
				'img'   => array( 'Логотип (лучше чёрный на прозрачном фоне)', 'img' ),
				'title' => array( 'Название (показывается, если нет логотипа)', 'text' ),
			),
		),
		'clients_about' => array(
			'title'  => 'Клиенты на странице «О нас»',
			'add'    => '+ Добавить клиента',
			'fields' => array(
				'img'   => array( 'Логотип (тёмный, для белого фона)', 'img' ),
				'title' => array( 'Название (показывается, если нет логотипа)', 'text' ),
			),
		),
		'svc_stages'   => array(
			'title'  => 'Этапы',
			'label'  => 'Этап',
			'add'    => '+ Добавить этап',
			'fields' => array(
				'title' => array( 'Название этапа', 'text' ),
				'text'  => array( 'Описание этапа', 'ta' ),
			),
		),
		'svc_gets'     => array(
			'title'  => 'Что вы получите',
			'label'  => 'Пункт',
			'add'    => '+ Добавить пункт',
			'fields' => array(
				'title' => array( 'Название', 'text' ),
				'text'  => array( 'Описание', 'ta' ),
			),
		),
		'svc_faq'      => array(
			'title'  => 'Вопросы перед стартом',
			'label'  => 'Вопрос',
			'add'    => '+ Добавить вопрос',
			'fields' => array(
				'title' => array( 'Вопрос', 'text' ),
				'text'  => array( 'Ответ', 'ta' ),
			),
		),
		'svc_projects' => array(
			'title'  => 'Проекты на первом экране',
			'label'  => 'Проект',
			'add'    => '+ Добавить проект',
			'fields' => array(
				'img'     => array( 'Картинка проекта (квадрат, лучше 128×128)', 'img' ),
				'project' => array( 'Ссылка на кейс', 'project' ),
			),
		),
		'art_sections' => array(
			'title'  => 'Разделы статьи',
			'label'  => 'Раздел',
			'add'    => '+ Добавить раздел',
			'fields' => array(
				'title'   => array( 'Заголовок раздела (слева)', 'text' ),
				'level'   => array( 'Уровень заголовка', 'level' ),
				'text'    => array( 'Текст раздела (пустая строка = новый абзац)', 'fmt' ),
				'img'     => array( 'Фото 1 (если фото одно — оно на всю ширину страницы)', 'img' ),
				'img2'    => array( 'Фото 2 (необязательно: тогда два фото рядом)', 'img' ),
				'caption' => array( 'Подпись под фото', 'text' ),
				'quote'   => array( 'Цитата-плашка после раздела (необязательно)', 'ta' ),
			),
		),
		'case_blocks' => array(
			'title'  => 'Содержимое страницы проекта',
			'label'  => 'Блок',
			'add'    => '+ Добавить блок',
			'fields' => array(
				'type'   => array( 'Тип блока', 'ptype' ),
				'label'  => array( 'Подпись над блоком (например: ЗАДАЧА или 01 / НЕЙМИНГ)', 'text', array( 'chapter' ) ),
				'title'  => array( 'Заголовок (Enter — новая строка)', 'ta', array( 'chapter' ) ),
				'text'   => array( 'Текст', 'fmt', array( 'chapter', 'statement' ) ),
				'img'    => array( 'Фото 1', 'img', array( 'media', 'two' ) ),
				'video'  => array( 'Видео 1 вместо фото (необязательно)', 'video', array( 'media', 'two' ) ),
				'img2'   => array( 'Фото 2', 'img', array( 'two' ) ),
				'video2' => array( 'Видео 2 вместо фото (необязательно)', 'video', array( 'two' ) ),
			),
		),
		'art_sticker' => array(
			'title'  => 'Стикер статьи',
			'label'  => 'Стикер',
			'add'    => '+ Добавить стикер',
			'fields' => array(
				'img' => array( 'Стикер на обложке статьи и на её карточке в блоге (используется первый)', 'img' ),
			),
		),
		'services' => array(
			'title'  => 'Услуги',
			'add'    => '+ Добавить услугу',
			'fields' => array(
				'img'   => array( 'Стикер справа', 'img' ),
				'title' => array( 'Название', 'text' ),
				'text'  => array( 'Описание', 'ta' ),
				'page'  => array( 'Страница услуги (для «Подробнее»)', 'service' ),
			),
		),
	);
}

function simple_rep_kinds_for( $post ) {
	if ( ! $post ) {
		return array();
	}
	if ( (int) get_option( 'page_on_front' ) === (int) $post->ID ) {
		return array( 'awards', 'services', 'clients' );
	}
	if ( 'project' === $post->post_type ) {
		return array( 'case_blocks' );
	}
	if ( 'post' === $post->post_type ) {
		return array( 'art_sections', 'art_sticker' );
	}
	if ( 'service' === $post->post_type ) {
		return array( 'svc_stages', 'svc_gets', 'svc_faq', 'svc_projects' );
	}
	if ( 'templates/template-about.php' === get_page_template_slug( $post ) ) {
		return array( 'photos', 'clients_about' );
	}
	return array();
}

add_action( 'add_meta_boxes_page', 'simple_rep_metabox' );
add_action( 'add_meta_boxes_service', 'simple_rep_metabox_service' );
add_action( 'add_meta_boxes_project', function ( $post ) {
	if ( function_exists( 'acf_add_local_field_group' ) ) {
		return;
	}
	add_meta_box( 'simple_rep', 'Содержимое страницы проекта', 'simple_rep_render', 'project', 'normal', 'default' );
} );
add_action( 'add_meta_boxes_post', function ( $post ) {
	if ( function_exists( 'acf_add_local_field_group' ) ) {
		return;
	}
	add_meta_box( 'simple_rep', 'Разделы статьи', 'simple_rep_render', 'post', 'normal', 'default' );
} );
function simple_rep_metabox_service( $post ) {
	if ( function_exists( 'acf_add_local_field_group' ) ) {
		return;
	}
	add_meta_box( 'simple_rep', 'Списки на странице', 'simple_rep_render', 'service', 'normal', 'default' );
}
function simple_rep_metabox( $post ) {
	if ( function_exists( 'acf_add_local_field_group' ) ) {
		return;
	}
	if ( ! simple_rep_kinds_for( $post ) ) {
		return;
	}
	add_meta_box( 'simple_rep', 'Списки на странице', 'simple_rep_render', 'page', 'normal', 'default' );
}

add_action( 'admin_enqueue_scripts', 'simple_rep_assets' );
function simple_rep_assets( $hook ) {
	if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
		return;
	}
	$p = get_post();
	if ( ! simple_rep_kinds_for( $p ) ) {
		return;
	}
	wp_enqueue_media();
	wp_enqueue_style( 'simple-rep', SIMPLE_URI . '/assets/css/admin-rep.css', array(), SIMPLE_VERSION );
	wp_enqueue_script( 'simple-rep', SIMPLE_URI . '/assets/js/admin-rep.js', array( 'jquery' ), SIMPLE_VERSION, true );
}

function simple_rep_rows( $post_id, $kind ) {
	$rows = get_post_meta( $post_id, 'home_rep_' . $kind, true );
	if ( metadata_exists( 'post', $post_id, 'home_rep_' . $kind ) ) {
		return is_array( $rows ) ? array_values( $rows ) : array();
	}
	if ( ! is_array( $rows ) || ! $rows ) {
		if ( 'clients' === $kind ) {
			return simple_rep_legacy_clients();
		}
		if ( 0 === strpos( $kind, 'svc_' ) ) {
			return simple_rep_legacy_svc( $post_id, $kind );
		}
		return 'photos' === $kind ? simple_rep_legacy_photos( $post_id ) : array();
	}
	return array_values( $rows );
}

function simple_rep_legacy_svc( $post_id, $kind ) {
	$map = array(
		'svc_stages'   => array( 4, 'svc_stage_%d_title', 'svc_stage_%d_text' ),
		'svc_gets'     => array( 6, 'svc_get_%d_title', 'svc_get_%d_text' ),
		'svc_faq'      => array( 5, 'svc_faq_%d_q', 'svc_faq_%d_a' ),
	);
	$out = array();
	if ( isset( $map[ $kind ] ) ) {
		for ( $i = 1; $i <= $map[ $kind ][0]; $i++ ) {
			$t = get_post_meta( $post_id, sprintf( $map[ $kind ][1], $i ), true );
			if ( $t ) {
				$out[] = array( 'title' => $t, 'text' => (string) get_post_meta( $post_id, sprintf( $map[ $kind ][2], $i ), true ) );
			}
		}
	} elseif ( 'svc_projects' === $kind ) {
		$img = (int) get_post_meta( $post_id, 'svc_img_2', true );
		if ( $img ) {
			$out[] = array( 'img' => $img, 'project' => (int) get_post_meta( $post_id, 'svc_case_link', true ) );
		}
	}
	return $out;
}

function simple_rep_legacy_clients() {
	$out = array();
	foreach ( get_posts( array( 'post_type' => 'client', 'posts_per_page' => -1, 'orderby' => 'menu_order date', 'order' => 'ASC', 'no_found_rows' => true ) ) as $c ) {
		$out[] = array( 'img' => (int) get_post_thumbnail_id( $c->ID ), 'title' => get_the_title( $c ) );
	}
	return $out;
}

function simple_clients_about_list( $pid ) {
	$rows = $pid ? get_post_meta( $pid, 'home_rep_clients_about', true ) : array();
	$out  = array();
	foreach ( is_array( $rows ) ? $rows : array() as $r ) {
		$img   = isset( $r['img'] ) ? (int) $r['img'] : 0;
		$title = isset( $r['title'] ) ? $r['title'] : '';
		if ( $img || $title ) {
			$out[] = array( 'img' => $img, 'title' => $title );
		}
	}
	return $out;
}

function simple_clients_list() {
	$home = (int) get_option( 'page_on_front' );
	$rows = $home ? simple_rep_rows( $home, 'clients' ) : simple_rep_legacy_clients();
	$out  = array();
	foreach ( $rows as $r ) {
		$img   = isset( $r['img'] ) ? (int) $r['img'] : 0;
		$title = isset( $r['title'] ) ? $r['title'] : '';
		if ( $img || $title ) {
			$out[] = array( 'img' => $img, 'title' => $title );
		}
	}
	return $out;
}

function simple_rep_legacy_photos( $post_id ) {
	$out = array();
	for ( $i = 1; $i <= 6; $i++ ) {
		$img = (int) get_post_meta( $post_id, 'about_photo_' . $i, true );
		if ( $img ) {
			$cap   = get_post_meta( $post_id, 'about_photo_cap_' . $i, true );
			$out[] = array( 'img' => $img, 'caption' => $cap ? $cap : '' );
		}
	}
	return $out;
}

function simple_rich_tags() {
	return array(
		'p'      => array(),
		'br'     => array(),
		'strong' => array(),
		'b'      => array(),
		'em'     => array(),
		'i'      => array(),
		'a'      => array( 'href' => true ),
	);
}

function simple_rep_row_html( $kind, $i, $row ) {
	$defs = simple_rep_defs();
	$name = 'simple_rep[' . $kind . '][' . $i . ']';
	ob_start();
	?>
	<div class="srep__row">
		<div class="srep__bar">
			<span class="srep__num"></span>
			<span class="srep__btns">
				<button type="button" class="button-link srep__up" title="Выше">↑</button>
				<button type="button" class="button-link srep__down" title="Ниже">↓</button>
				<button type="button" class="button-link srep__del" title="Удалить">Удалить</button>
			</span>
		</div>
		<div class="srep__fields">
			<?php foreach ( $defs[ $kind ]['fields'] as $key => $f ) :
				$val = isset( $row[ $key ] ) ? $row[ $key ] : '';
				?>
				<label class="srep__f srep__f--<?php echo esc_attr( $key ); ?>"<?php echo isset( $f[2] ) ? ' data-show="' . esc_attr( implode( ' ', $f[2] ) ) . '"' : ''; ?><?php echo ( 'title' === $key && ( 0 === strpos( $kind, 'svc_' ) || 'art_sections' === $kind ) ) ? ' style="grid-column:1 / -1"' : ''; ?>>
					<span><?php echo esc_html( $f[0] ); ?></span>
					<?php if ( 'img' === $f[1] ) :
						$src = $val ? wp_get_attachment_image_url( (int) $val, 'thumbnail' ) : '';
						?>
						<span class="srep__img" data-img>
							<input type="hidden" name="<?php echo esc_attr( $name . '[' . $key . ']' ); ?>" value="<?php echo esc_attr( $val ); ?>">
							<span class="srep__prev"><?php echo $src ? '<img src="' . esc_url( $src ) . '" alt="">' : ''; ?></span>
							<button type="button" class="button srep__pick">Выбрать фото</button>
							<button type="button" class="button-link srep__clear">убрать</button>
						</span>
					<?php elseif ( 'ptype' === $f[1] ) : ?>
						<select class="srep__type" name="<?php echo esc_attr( $name . '[' . $key . ']' ); ?>">
							<?php foreach ( array( 'media' => 'Фото или видео на всю ширину', 'two' => 'Два фото / видео рядом', 'chapter' => 'Текст: подпись, заголовок и описание', 'statement' => 'Крупная фраза-вывод' ) as $tv => $tn ) : ?>
								<option value="<?php echo esc_attr( $tv ); ?>"<?php selected( $val ? $val : 'media', $tv ); ?>><?php echo esc_html( $tn ); ?></option>
							<?php endforeach; ?>
						</select>
					<?php elseif ( 'video' === $f[1] ) : ?>
						<span class="srep__video">
							<input type="text" name="<?php echo esc_attr( $name . '[' . $key . ']' ); ?>" value="<?php echo esc_attr( $val ); ?>" placeholder="Ссылка на .mp4 или YouTube / Vimeo">
							<button type="button" class="button srep__pickvideo">Выбрать из медиафайлов</button>
						</span>
					<?php elseif ( 'level' === $f[1] ) : ?>
						<select name="<?php echo esc_attr( $name . '[' . $key . ']' ); ?>">
							<?php foreach ( array( 'h2' => 'H2 — основной (по умолчанию)', 'h1' => 'H1 — самый крупный', 'h3' => 'H3 — средний', 'h4' => 'H4 — мелкий' ) as $lv => $ln ) : ?>
								<option value="<?php echo esc_attr( $lv ); ?>"<?php selected( $val ? $val : 'h2', $lv ); ?>><?php echo esc_html( $ln ); ?></option>
							<?php endforeach; ?>
						</select>
					<?php elseif ( 'fmt' === $f[1] ) :
						$rich = ( false === strpos( (string) $val, '<' ) && '' !== trim( (string) $val ) ) ? simple_fmt( $val ) : (string) $val;
						if ( false === strpos( $rich, '<p' ) && '' !== trim( $rich ) ) {
							$rich = wpautop( $rich );
						}
						?>
						<span class="srep__fmt">
							<button type="button" class="button" data-cmd="bold" title="Жирный"><b>Ж</b></button>
							<button type="button" class="button" data-cmd="italic" title="Курсив"><i>К</i></button>
							<button type="button" class="button" data-cmd="link" title="Ссылка">Ссылка</button>
							<button type="button" class="button" data-cmd="unlink" title="Убрать ссылку">Без ссылки</button>
						</span>
						<div class="srep__rich" contenteditable="true"><?php echo wp_kses( $rich, simple_rich_tags() ); ?></div>
						<textarea class="srep__rich-src" hidden name="<?php echo esc_attr( $name . '[' . $key . ']' ); ?>"><?php echo esc_textarea( wp_kses( $rich, simple_rich_tags() ) ); ?></textarea>
					<?php elseif ( 'ta' === $f[1] ) : ?>
						<textarea rows="3" name="<?php echo esc_attr( $name . '[' . $key . ']' ); ?>"><?php echo esc_textarea( $val ); ?></textarea>
					<?php elseif ( 'project' === $f[1] ) : ?>
						<select name="<?php echo esc_attr( $name . '[' . $key . ']' ); ?>">
							<option value="">— без ссылки —</option>
							<?php foreach ( get_posts( array( 'post_type' => 'project', 'posts_per_page' => -1, 'orderby' => 'menu_order date', 'order' => 'ASC', 'no_found_rows' => true ) ) as $s ) : ?>
								<option value="<?php echo (int) $s->ID; ?>"<?php selected( (int) $val, $s->ID ); ?>><?php echo esc_html( get_the_title( $s ) ); ?></option>
							<?php endforeach; ?>
						</select>
					<?php elseif ( 'service' === $f[1] ) : ?>
						<select name="<?php echo esc_attr( $name . '[' . $key . ']' ); ?>">
							<option value="">— раздел «Услуги» —</option>
							<?php foreach ( get_posts( array( 'post_type' => 'service', 'posts_per_page' => -1, 'orderby' => 'menu_order title', 'order' => 'ASC' ) ) as $s ) : ?>
								<option value="<?php echo (int) $s->ID; ?>"<?php selected( (int) $val, $s->ID ); ?>><?php echo esc_html( get_the_title( $s ) ); ?></option>
							<?php endforeach; ?>
						</select>
					<?php else : ?>
						<input type="text" name="<?php echo esc_attr( $name . '[' . $key . ']' ); ?>" value="<?php echo esc_attr( $val ); ?>">
					<?php endif; ?>
				</label>
			<?php endforeach; ?>
		</div>
	</div>
	<?php
	return ob_get_clean();
}

function simple_rep_render_kind( $post_id, $kind ) {
	$defs = simple_rep_defs();
	$def  = $defs[ $kind ];
	wp_nonce_field( 'simple_rep', 'simple_rep_nonce', false );
	?>
	<input type="hidden" name="simple_rep_kinds[]" value="<?php echo esc_attr( $kind ); ?>">
	<div class="srep" data-kind="<?php echo esc_attr( $kind ); ?>" data-label="<?php echo esc_attr( isset( $def['label'] ) ? $def['label'] : '№' ); ?>">
		<div class="srep__list">
			<?php foreach ( simple_rep_rows( $post_id, $kind ) as $i => $row ) {
				echo simple_rep_row_html( $kind, $i, $row );
			} ?>
		</div>
		<script type="text/template" class="srep__tpl"><?php echo simple_rep_row_html( $kind, '__i__', array() ); ?></script>
		<p><button type="button" class="button button-primary srep__add"><?php echo esc_html( $def['add'] ); ?></button></p>
	</div>
	<?php
}

function simple_rep_render( $post ) {
	$defs = simple_rep_defs();
	foreach ( simple_rep_kinds_for( $post ) as $kind ) {
		echo '<h3>' . esc_html( $defs[ $kind ]['title'] ) . '</h3>';
		simple_rep_render_kind( $post->ID, $kind );
	}
}

add_action( 'acf/render_field/key=field_about_photos_note', function () {
	simple_rep_render_kind( get_the_ID(), 'photos' );
} );

add_action( 'acf/render_field/key=field_home_awards_note', function () {
	simple_rep_render_kind( get_the_ID(), 'awards' );
} );
add_action( 'acf/render_field/key=field_about_clients_note', function () {
	simple_rep_render_kind( get_the_ID(), 'clients_about' );
} );
add_action( 'acf/render_field/key=field_home_clients_note', function () {
	simple_rep_render_kind( get_the_ID(), 'clients' );
} );
foreach ( array( 'stages' => 'svc_stages', 'gets' => 'svc_gets', 'faq' => 'svc_faq', 'projects' => 'svc_projects' ) as $simple_k => $simple_kind ) {
	add_action( 'acf/render_field/key=field_svc_' . $simple_k . '_note', function () use ( $simple_kind ) {
		simple_rep_render_kind( get_the_ID(), $simple_kind );
	} );
}
add_action( 'acf/render_field/key=field_home_svc_note', function () {
	simple_rep_render_kind( get_the_ID(), 'services' );
} );

add_action( 'save_post_page', 'simple_rep_save' );
add_action( 'save_post_service', 'simple_rep_save' );
add_action( 'save_post_post', 'simple_rep_save' );
add_action( 'save_post_project', 'simple_rep_save' );
add_action( 'acf/render_field/key=field_project_blocks_note', function () {
	simple_rep_render_kind( get_the_ID(), 'case_blocks' );
} );
add_action( 'acf/render_field/key=field_post_art_sections_note', function () {
	simple_rep_render_kind( get_the_ID(), 'art_sections' );
} );
add_action( 'acf/render_field/key=field_post_art_sticker_note', function () {
	simple_rep_render_kind( get_the_ID(), 'art_sticker' );
} );
function simple_rep_save( $post_id ) {
	if ( ! isset( $_POST['simple_rep_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['simple_rep_nonce'] ) ), 'simple_rep' ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ) {
		return;
	}
	$in = isset( $_POST['simple_rep'] ) ? wp_unslash( $_POST['simple_rep'] ) : array();
	$kinds = isset( $_POST['simple_rep_kinds'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['simple_rep_kinds'] ) ) : array();
	foreach ( simple_rep_defs() as $kind => $def ) {
		if ( ! in_array( $kind, $kinds, true ) ) {
			continue;
		}
		$out = array();
		$src = isset( $in[ $kind ] ) && is_array( $in[ $kind ] ) ? $in[ $kind ] : array();
		foreach ( $src as $row ) {
			$clean = array();
			foreach ( $def['fields'] as $key => $f ) {
				$v = isset( $row[ $key ] ) ? $row[ $key ] : '';
				if ( 'ptype' === $f[1] ) {
					$clean[ $key ] = in_array( $v, array( 'media', 'two', 'chapter', 'statement' ), true ) ? $v : 'media';
				} elseif ( 'video' === $f[1] ) {
					$clean[ $key ] = esc_url_raw( trim( $v ) );
				} elseif ( 'fmt' === $f[1] ) {
					$clean[ $key ] = wp_kses( $v, simple_rich_tags() );
				} elseif ( 'level' === $f[1] ) {
					$clean[ $key ] = in_array( $v, array( 'h1', 'h2', 'h3', 'h4' ), true ) ? $v : 'h2';
				} elseif ( 'ta' === $f[1] ) {
					$clean[ $key ] = sanitize_textarea_field( $v );
				} elseif ( in_array( $f[1], array( 'img', 'service', 'project' ), true ) ) {
					$clean[ $key ] = absint( $v );
				} else {
					$clean[ $key ] = sanitize_text_field( $v );
				}
			}
			if ( ! array_filter( $clean ) ) {
				continue;
			}
			$out[] = $clean;
		}
		update_post_meta( $post_id, 'home_rep_' . $kind, $out );
	}
}
