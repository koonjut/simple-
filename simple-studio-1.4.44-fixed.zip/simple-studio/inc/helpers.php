<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function simple_t( $string, $name = '' ) {
	if ( function_exists( 'pll__' ) ) {
		return pll__( $string );
	}
	return $string;
}

function sf( $name, $post_id = false ) {
	$value = null;
	if ( function_exists( 'get_field' ) ) {
		$value = get_field( $name, $post_id );
	} else {
		$pid   = $post_id ? $post_id : get_the_ID();
		$value = $pid ? get_post_meta( $pid, $name, true ) : null;
	}
	if ( null === $value || false === $value || '' === $value || array() === $value ) {
		$defaults = simple_defaults();
		$value    = isset( $defaults[ $name ] ) ? $defaults[ $name ] : '';
	}
	if ( is_string( $value ) ) {
		$value = trim( $value );
	}
	return $value;
}

function sf_raw( $name, $post_id = false ) {
	$value = null;
	if ( function_exists( 'get_field' ) ) {
		$value = get_field( $name, $post_id );
	} else {
		$pid   = $post_id ? $post_id : get_the_ID();
		$value = $pid ? get_post_meta( $pid, $name, true ) : null;
	}
	if ( is_string( $value ) ) {
		$value = trim( $value );
	}
	return ( false === $value || null === $value ) ? '' : $value;
}

function simple_opt( $key ) {
	static $opts = null;
	if ( null === $opts ) {
		$opts = get_option( 'simple_options', array() );
		if ( ! is_array( $opts ) ) {
			$opts = array();
		}
	}
	$full = 'opt_' . $key;
	if ( isset( $opts[ $full ] ) && '' !== trim( (string) $opts[ $full ] ) ) {
		return trim( (string) $opts[ $full ] );
	}
	$defaults = simple_defaults();
	return isset( $defaults[ $full ] ) ? $defaults[ $full ] : '';
}

function simple_opt_image_id( $key ) {
	$opts = get_option( 'simple_options', array() );
	return ( is_array( $opts ) && ! empty( $opts[ 'img_' . $key ] ) ) ? absint( $opts[ 'img_' . $key ] ) : 0;
}

function simple_lines( $text ) {
	$lines = preg_split( '/\r\n|\r|\n/', (string) $text );
	$lines = array_map( 'trim', $lines );
	return array_values( array_filter( $lines, 'strlen' ) );
}

function simple_br( $text ) {
	return nl2br( esc_html( (string) $text ) );
}

function simple_arrow( $size = 20, $class = 'icon-arrow' ) {
	return '<svg class="' . esc_attr( $class ) . '" width="' . (int) $size . '" height="' . (int) $size . '" viewBox="0 0 73 73" fill="none" aria-hidden="true" focusable="false"><path d="M3 70L69 4M1 3.75H69.25V72" stroke="currentColor" stroke-width="' . ( $size < 30 ? 6 : 7.5 ) . '"/></svg>';
}

function simple_img( $id, $size = 'large', $class = '', $attrs = array() ) {
	$id = absint( $id );
	if ( ! $id ) {
		return '';
	}
	$attrs = wp_parse_args(
		$attrs,
		array(
			'class'    => $class,
			'loading'  => 'lazy',
			'decoding' => 'async',
		)
	);
	return wp_get_attachment_image( $id, $size, false, $attrs );
}

function sf_img( $name, $size = 'large', $class = '', $post_id = false ) {
	$id = sf_raw( $name, $post_id );
	if ( is_array( $id ) && isset( $id['ID'] ) ) {
		$id = $id['ID'];
	}
	return simple_img( $id, $size, $class );
}

function simple_thumb( $post_id, $size = 'large', $class = '' ) {
	$id = get_post_thumbnail_id( $post_id );
	return $id ? simple_img( $id, $size, $class ) : '';
}

function simple_sticker( $field, $class = 'sticker', $size = 'medium' ) {
	$html = sf_img( $field, $size, $class );
	return $html ? '<span class="' . esc_attr( $class ) . '-wrap" aria-hidden="true">' . $html . '</span>' : '';
}

function simple_bike( $tag = '', $light = false, $override_id = 0 ) {
	$html = '<span class="bike" aria-hidden="true">';
	if ( $override_id ) {
		$html .= simple_img( $override_id, 'medium', 'bike__img', array( 'loading' => 'lazy' ) );
	} else {
		$file  = $light ? 'bike-light.png' : 'bike-dark.png';
		$html .= '<img class="bike__img" src="' . esc_url( SIMPLE_URI . '/assets/img/' . $file ) . '" width="59" height="48" alt="" loading="lazy">';
	}
	if ( '' !== $tag ) {
		$html .= '<span class="bike__tag">' . esc_html( $tag ) . '</span>';
	}
	return $html . '</span>';
}

function simple_sticker_img( $source, $pid, $default_file, $w, $h, $class = '' ) {
	$id = 0;
	if ( 0 === strpos( $source, 'opt:' ) ) {
		$id = simple_opt_image_id( substr( $source, 4 ) );
	} else {
		$v  = sf_raw( substr( $source, 6 ), $pid );
		$id = is_array( $v ) ? ( isset( $v['ID'] ) ? (int) $v['ID'] : 0 ) : (int) $v;
	}
	if ( $id ) {
		return simple_img( $id, 'medium', $class . ' is-custom', array( 'aria-hidden' => 'true', 'alt' => '' ) );
	}
	return simple_asset_img( $default_file, $w, $h, $class );
}

function simple_asset_img( $file, $w, $h, $class = '' ) {
	return '<img class="' . esc_attr( $class ) . '" src="' . esc_url( SIMPLE_URI . '/assets/img/' . $file ) . '" width="' . (int) $w . '" height="' . (int) $h . '" alt="" loading="lazy" aria-hidden="true">';
}

function simple_page_by_template( $template ) {
	static $cache = array();
	if ( isset( $cache[ $template ] ) ) {
		return $cache[ $template ];
	}
	$pages = get_posts(
		array(
			'post_type'              => 'page',
			'post_status'            => 'publish',
			'posts_per_page'         => 1,
			'meta_key'               => '_wp_page_template',
			'meta_value'             => $template,
			'no_found_rows'          => true,
			'update_post_term_cache' => false,
			'fields'                 => 'ids',
		)
	);
	$cache[ $template ] = $pages ? (int) $pages[0] : 0;
	return $cache[ $template ];
}

function simple_section_url( $section ) {
	$map = array(
		'services' => 'templates/template-services.php',
		'projects' => 'templates/template-projects.php',
		'team'     => 'templates/template-team.php',
		'about'    => 'templates/template-about.php',
		'contacts' => 'templates/template-contacts.php',
	);
	if ( 'blog' === $section ) {
		$pid = (int) get_option( 'page_for_posts' );
		return $pid ? get_permalink( $pid ) : home_url( '/' );
	}
	if ( isset( $map[ $section ] ) ) {
		$pid = simple_page_by_template( $map[ $section ] );
		if ( $pid ) {
			return get_permalink( $pid );
		}
	}
	return home_url( '/' );
}

function simple_blog_page_id() {
	return (int) get_option( 'page_for_posts' );
}

function simple_current_section() {
	if ( is_singular( 'service' ) || is_page_template( 'templates/template-services.php' ) ) {
		return 'services';
	}
	if ( is_singular( 'project' ) || is_page_template( 'templates/template-projects.php' ) ) {
		return 'projects';
	}
	if ( is_page_template( 'templates/template-team.php' ) ) {
		return 'team';
	}
	if ( is_page_template( 'templates/template-about.php' ) ) {
		return 'about';
	}
	if ( is_page_template( 'templates/template-contacts.php' ) ) {
		return 'contacts';
	}
	if ( is_home() || is_singular( 'post' ) || is_category() || is_tag() ) {
		return 'blog';
	}
	return '';
}

function simple_default_menu( $location ) {
	$items = array();
	switch ( $location ) {
		case 'primary':
			$items = array(
				array( 'О нас', simple_section_url( 'about' ), 'about' ),
				array( 'Проекты', simple_section_url( 'projects' ), 'projects' ),
				array( 'Услуги', simple_section_url( 'services' ), 'services' ),
				array( 'Команда', simple_section_url( 'team' ), 'team' ),
				array( 'Блог', simple_section_url( 'blog' ), 'blog' ),
				array( 'Контакты', simple_section_url( 'contacts' ), 'contacts' ),
			);
			break;
		case 'footer_1':
			$items = array(
				array( 'Проекты', simple_section_url( 'projects' ), 'projects' ),
				array( 'Услуги', simple_section_url( 'services' ), 'services' ),
				array( 'О компании', simple_section_url( 'about' ), 'about' ),
			);
			break;
		case 'footer_2':
			$items = array(
				array( 'Команда', simple_section_url( 'team' ), 'team' ),
				array( 'Блог', simple_section_url( 'blog' ), 'blog' ),
				array( 'Контакты', simple_section_url( 'contacts' ), 'contacts' ),
			);
			break;
		case 'footer_social':
			$items = array(
				array( 'Instagram', simple_opt( 'instagram' ), '' ),
				array( 'Behance', simple_opt( 'behance' ), '' ),
				array( 'Linkedin', simple_opt( 'linkedin' ), '' ),
			);
			break;
		case 'mobile':
			$items = array(
				array( 'О нас', simple_section_url( 'about' ), 'about' ),
				array( 'Проекты', simple_section_url( 'projects' ), 'projects' ),
				array( 'Услуги', simple_section_url( 'services' ), 'services' ),
				array( 'Команда', simple_section_url( 'team' ), 'team' ),
				array( 'Блог', simple_section_url( 'blog' ), 'blog' ),
				array( 'Контакты', simple_section_url( 'contacts' ), 'contacts' ),
			);
			break;
	}
	return $items;
}

function simple_menu( $location, $class = '' ) {
	if ( has_nav_menu( $location ) ) {
		wp_nav_menu(
			array(
				'theme_location' => $location,
				'container'      => false,
				'menu_class'     => $class,
				'depth'          => 1,
				'fallback_cb'    => false,
			)
		);
		return;
	}
	$current = simple_current_section();
	echo '<ul class="' . esc_attr( $class ) . '">';
	foreach ( simple_default_menu( $location ) as $item ) {
		$is_current = ( '' !== $item[2] && $item[2] === $current );
		$attrs      = $is_current ? ' aria-current="page"' : '';
		$li_class   = $is_current ? ' class="current-menu-item"' : '';
		echo '<li' . $li_class . '><a href="' . esc_url( $item[1] ) . '"' . $attrs . '>' . esc_html( simple_t( $item[0] ) ) . '</a></li>';
	}
	echo '</ul>';
}

function simple_lang_items() {
	$items = array();
	if ( function_exists( 'pll_the_languages' ) ) {
		$langs = pll_the_languages( array( 'raw' => 1, 'hide_if_empty' => 0 ) );
		if ( is_array( $langs ) ) {
			foreach ( $langs as $l ) {
				$items[] = array(
					'label'   => strtoupper( $l['slug'] ),
					'url'     => $l['url'],
					'lang'    => $l['locale'],
					'current' => ! empty( $l['current_lang'] ),
					'soon'    => false,
				);
			}
		}
	}
	if ( ! $items ) {
		$items = array(
			array( 'label' => 'RU', 'url' => home_url( '/' ), 'lang' => 'ru', 'current' => true, 'soon' => false ),
			array( 'label' => 'KZ', 'url' => '', 'lang' => 'kk', 'current' => false, 'soon' => true ),
			array( 'label' => 'EN', 'url' => '', 'lang' => 'en', 'current' => false, 'soon' => true ),
		);
	}
	return $items;
}

function simple_lang_switcher( $inline = false ) {
	$items   = simple_lang_items();
	$current = $items[0];
	foreach ( $items as $it ) {
		if ( $it['current'] ) {
			$current = $it;
		}
	}
	$render = function ( $it ) {
		if ( $it['soon'] || '' === $it['url'] ) {
			return '<li class="is-soon"><span title="Скоро">' . esc_html( $it['label'] ) . '</span></li>';
		}
		return sprintf(
			'<li%s><a href="%s" hreflang="%s" lang="%s"%s>%s</a></li>',
			$it['current'] ? ' class="current-lang"' : '',
			esc_url( $it['url'] ),
			esc_attr( $it['lang'] ),
			esc_attr( $it['lang'] ),
			$it['current'] ? ' aria-current="true"' : '',
			esc_html( $it['label'] )
		);
	};

	if ( $inline ) {
		echo '<ul class="lang lang--inline" aria-label="Язык сайта">';
		foreach ( $items as $it ) {
			echo $render( $it );
		}
		echo '</ul>';
		return;
	}

	echo '<div class="lang" data-lang>';
	echo '<button type="button" class="lang__btn" aria-haspopup="true" aria-expanded="false" aria-label="Язык сайта"><span>' . esc_html( $current['label'] ) . '</span></button>';
	echo '<ul class="lang__list" hidden>';
	foreach ( $items as $it ) {
		echo $render( $it );
	}
	echo '</ul></div>';
}

function simple_logo( $class = 'logo', $light = false ) {
	$home = esc_url( home_url( '/' ) );
	echo '<a class="' . esc_attr( $class ) . '" href="' . $home . '" aria-label="' . esc_attr( get_bloginfo( 'name' ) ) . '">';
	if ( has_custom_logo() ) {
		$logo_id = get_theme_mod( 'custom_logo' );
		echo wp_get_attachment_image( $logo_id, 'full', false, array( 'class' => 'logo__img' . ( $light ? ' logo__img--invert' : '' ), 'alt' => get_bloginfo( 'name' ) ) );
	} else {
		$file = $light ? 'logo-light.png' : 'logo.png';
		$w    = $light ? 149 : 115;
		$h    = $light ? 24 : 18;
		echo '<img class="logo__img logo__img--default" src="' . esc_url( SIMPLE_URI . '/assets/img/' . $file ) . '" width="' . (int) $w . '" height="' . (int) $h . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '">';
	}
	echo '</a>';
}

function simple_button( $label, $url, $variant = 'primary', $arrow = true, $extra = '' ) {
	$cls = 'btn btn--' . $variant;
	return '<a class="' . esc_attr( $cls ) . '" href="' . esc_url( $url ) . '"' . $extra . '><span>' . esc_html( $label ) . '</span>' . ( $arrow ? simple_arrow( 20 ) : '' ) . '</a>';
}

function simple_eyebrow( $text, $class = '' ) {
	if ( '' === trim( (string) $text ) ) {
		return '';
	}
	return '<p class="eyebrow ' . esc_attr( $class ) . '">' . esc_html( $text ) . '</p>';
}

function simple_home_slots( $kind, $max = 50, $pid = false ) {
	if ( ! $pid ) {
		$pid = (int) get_option( 'page_on_front' );
	}
	$rows = $pid ? get_post_meta( $pid, 'home_rep_' . ( 'award' === $kind ? 'awards' : 'services' ), true ) : array();
	$out  = array();
	foreach ( is_array( $rows ) ? $rows : array() as $r ) {
		if ( empty( $r['title'] ) ) {
			continue;
		}
		$out[] = array(
			'title'   => $r['title'],
			'text'    => isset( $r['text'] ) ? $r['text'] : '',
			'project' => isset( $r['project'] ) ? $r['project'] : '',
			'img'     => isset( $r['img'] ) ? (int) $r['img'] : 0,
			'page'    => isset( $r['page'] ) ? (int) $r['page'] : 0,
		);
	}
	return $out;
}

function simple_about_photos( $pid ) {
	$rows = function_exists( 'simple_rep_rows' ) ? simple_rep_rows( $pid, 'photos' ) : array();
	$out  = array();
	foreach ( $rows as $r ) {
		$img = isset( $r['img'] ) ? (int) $r['img'] : 0;
		if ( ! $img ) {
			continue;
		}
		$meta = wp_get_attachment_metadata( $img );
		$w    = isset( $meta['width'] ) ? (int) $meta['width'] : 0;
		$h    = isset( $meta['height'] ) ? (int) $meta['height'] : 0;
		$out[] = array(
			'img'     => $img,
			'caption' => isset( $r['caption'] ) ? $r['caption'] : '',
			'wide'    => ( $w && $h && $w / $h >= 1.25 ),
		);
	}
	return $out;
}
