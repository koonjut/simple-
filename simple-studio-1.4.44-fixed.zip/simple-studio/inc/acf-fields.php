<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function sfp( $name, $section ) {
	if ( 'blog' === $section ) {
		$pid = simple_blog_page_id();
	} elseif ( 'home' === $section ) {
		$pid = (int) get_option( 'page_on_front' );
	} else {
		$pid = simple_page_by_template( 'templates/template-' . $section . '.php' );
	}
	return sf( $name, $pid ? $pid : false );
}

function simple_field_labels() {
	$raw = <<<'TXT'
home_hero_img|Главная: большое фото на первом экране|img
home_hero_tag|Главная: подпись над названием проекта (первый экран)
home_hero_title|Главная: название проекта (первый экран)
home_hero_sub|Главная: подпись под названием
home_hero_link|Главная: ссылка на заголовке первого экрана|url
home_intro_label|Главная: подпись над заголовком (мелким шрифтом)
home_intro_title|Главная: большой заголовок|ta
home_intro_text|Главная: описание студии|ta
home_tags|Главная: теги под заголовком (каждый с новой строки)|ta
home_pill|Главная: розовая плашка «Все проекты»
home_manifesto_title|Главная: манифест — заголовок
home_manifesto_text|Главная: манифест — текст|ta
home_approach_1|Главная: «подход» — абзац 1|ta
home_approach_2|Главная: «подход» — абзац 2|ta
home_awards_title|Главная: заголовок «Награды»
home_sticker_eye|Главная: стикер «глаз» у заголовка|img
home_sticker_bike|Главная: стикер «велосипед» у плашки «Все проекты»|img
home_sticker_brain|Главная: стикер «мозг на велосипеде» у блока подхода|img
home_services_title|Главная: заголовок «Услуги»
home_services_all|Главная: ссылка «Все услуги»
home_service_more|Главная: ссылка «Подробнее об услуге»
about_label|О нас: подпись над заголовком
about_title|О нас: заголовок
about_text|О нас: вводный текст|ta
about_sticker|О нас: стикер у заголовка|img
about_photos_title|О нас: заголовок блока с фото
about_appr_label|О нас: подход — подпись
about_appr_title|О нас: подход — заголовок
about_prin_1_title|О нас: принцип 1 — заголовок
about_prin_1_text|О нас: принцип 1 — текст|ta
about_prin_2_title|О нас: принцип 2 — заголовок
about_prin_2_text|О нас: принцип 2 — текст|ta
about_prin_3_title|О нас: принцип 3 — заголовок
about_prin_3_text|О нас: принцип 3 — текст|ta
about_facts_label|О нас: факты — подпись
about_fact_1_num|О нас: факт 1 — число
about_fact_1_title|О нас: факт 1 — название
about_fact_1_text|О нас: факт 1 — описание|ta
about_fact_2_num|О нас: факт 2 — число
about_fact_2_title|О нас: факт 2 — название
about_fact_2_text|О нас: факт 2 — описание|ta
about_fact_3_num|О нас: факт 3 — число
about_fact_3_title|О нас: факт 3 — название
about_fact_3_text|О нас: факт 3 — описание|ta
about_fact_4_num|О нас: факт 4 — число
about_fact_4_title|О нас: факт 4 — название
about_fact_4_text|О нас: факт 4 — описание|ta
about_team_label|О нас: команда — подпись
about_team_title|О нас: команда — заголовок
about_team_text|О нас: команда — текст|ta
about_clients_label|О нас: подпись над логотипами клиентов
about_awards_title|О нас: заголовок «Награды»
team_label|Команда: подпись над заголовком
team_title|Команда: заголовок (перенос строки — Enter)|ta
team_sticker|Команда: стикер у заголовка|img
team_text|Команда: вводный текст|ta
team_join_label|Команда: блок «Хотите работать» — подпись
team_join_title|Команда: блок «Хотите работать» — заголовок|ta
team_join_text|Команда: блок «Хотите работать» — текст|ta
team_join_btn|Команда: кнопка
team_join_link|Команда: ссылка кнопки (mailto: или https://)
team_join_sticker|Команда: стикер в блоке «Хотите работать»|img
svcs_label|Услуги: подпись над заголовком
svcs_title|Услуги: заголовок
svcs_text|Услуги: вводный текст|ta
svcs_sticker|Услуги: стикер у заголовка|img
svc_case_label|Страница услуги: «Посмотреть кейс:»
svc_stages_title|Страница услуги: заголовок «Этапы»
svc_stages_text|Страница услуги: текст под «Этапы»|ta
svc_get_title|Страница услуги: «Что вы получите»
svc_more_title|Страница услуги: «Другие проекты»
svc_more_label|Страница услуги: подпись у «Другие проекты»
svc_more_btn|Страница услуги: кнопка «Все проекты»
svc_more_link|Страница услуги: «Подробнее» на карточке
svc_faq_title|Страница услуги: заголовок вопросов
prjs_label|Кейсы: подпись над заголовком
prjs_title|Кейсы: заголовок|ta
prjs_all|Кейсы: название фильтра «Все проекты»
prjs_sticker|Кейсы: стикер справа от заголовка|img
blog_label|Блог: подпись над заголовком
blog_title|Блог: заголовок|ta
blog_text|Блог: вводный текст|ta
blog_card_label|Блог: подпись на карточке без картинки
cont_label|Контакты: подпись над заголовком
cont_title|Контакты: большой заголовок|ta
cont_text|Контакты: текст под заголовком|ta
cont_sticker|Контакты: стикер справа вверху|img
cont_left_label|Контакты: чёрный блок — подпись (зелёная)
cont_left_title|Контакты: чёрный блок — заголовок|ta
cont_left_text|Контакты: чёрный блок — текст|ta
cont_lbl_email|Контакты: подпись «Почта»
cont_lbl_phone|Контакты: подпись «Телефон»
cont_form_title|Контакты: заголовок формы
cont_f_name|Контакты: поле «Имя» — подпись
cont_f_name_ph|Контакты: поле «Имя» — подсказка
cont_f_contact|Контакты: поле «Почта или телефон» — подпись
cont_f_contact_ph|Контакты: поле «Почта или телефон» — подсказка
cont_f_msg|Контакты: поле «О проекте» — подпись
cont_f_msg_ph|Контакты: поле «О проекте» — подсказка
cont_btn|Контакты: кнопка
cont_consent|Контакты: текст согласия|ta
prjs_case_client|Страница кейса: подпись «Клиент»
prjs_case_services|Страница кейса: подпись «Услуги»
prjs_case_place|Страница кейса: подпись «Место»
prjs_case_team|Страница кейса: заголовок команды
prjs_case_more|Страница кейса: «Ещё проекты»
prjs_case_more_all|Страница кейса: кнопка «Все проекты»
art_back|Статья: «Все статьи»
art_toc_label|Статья: «В этой статье»
art_up|Статья: «Наверх»
art_more_title|Статья: «Читайте также»
TXT;
	$out = array();
	foreach ( explode( "\n", $raw ) as $line ) {
		$p = explode( '|', trim( $line ) );
		if ( count( $p ) < 2 ) {
			continue;
		}
		$out[ $p[0] ] = array( $p[1], isset( $p[2] ) ? $p[2] : 'text' );
	}
	return $out;
}

function simple_acf_fields( $keys, $prefix ) {
	$labels   = simple_field_labels();
	$defaults = simple_defaults();
	$fields   = array();
	foreach ( $keys as $key ) {
		if ( ! isset( $labels[ $key ] ) ) {
			continue;
		}
		$f = array(
			'key'   => 'field_' . $prefix . '_' . $key,
			'label' => $labels[ $key ][0],
			'name'  => $key,
		);
		switch ( $labels[ $key ][1] ) {
			case 'img':
				$f['type']          = 'image';
				$f['return_format'] = 'id';
				$f['preview_size']  = 'medium';
				$f['instructions']  = ( false !== strpos( $key, 'sticker' ) ) ? 'Если не выбрано — стандартный стикер из макета. Лучше PNG с прозрачным фоном.' : 'Если не выбрано — показывается серая заглушка.';
				break;
			case 'url':
				$f['type']         = 'url';
				$f['instructions'] = 'Вставьте ссылку на кейс или любую страницу. Если пусто — заголовок не будет ссылкой.';
				$f['placeholder']  = 'https://';
				break;
			case 'ta':
				$f['type']        = 'textarea';
				$f['rows']        = 3;
				$f['new_lines']   = '';
				$f['placeholder'] = isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
				break;
			default:
				$f['type']        = 'text';
				$f['placeholder'] = isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
		}
		$fields[] = $f;
	}
	return $fields;
}

function simple_keys_with( $prefixes, $extra = array() ) {
	$keys = array();
	foreach ( array_keys( simple_field_labels() ) as $k ) {
		foreach ( (array) $prefixes as $p ) {
			if ( 0 === strpos( $k, $p ) ) {
				$keys[] = $k;
				break;
			}
		}
	}
	return array_merge( $keys, $extra );
}

function simple_acf_tabs( $tabs, $prefix ) {
	$labels = simple_field_labels();
	$fields = array();
	$n      = 0;
	foreach ( $tabs as $tab_title => $patterns ) {
		$keys = array();
		foreach ( array_keys( $labels ) as $k ) {
			foreach ( (array) $patterns as $pat ) {
				if ( 0 === strpos( $k, $pat ) ) {
					$keys[] = $k;
					break;
				}
			}
		}
		if ( ! $keys ) {
			continue;
		}
		$n++;
		$fields[] = array(
			'key'       => 'field_tab_' . $prefix . '_' . $n,
			'label'     => $n . '. ' . $tab_title,
			'name'      => '',
			'type'      => 'tab',
			'placement' => 'top',
		);
		foreach ( simple_acf_fields( $keys, $prefix ) as $f ) {
			if ( false !== ( $pos = mb_strpos( $f['label'], ': ' ) ) ) {
				$short      = mb_substr( $f['label'], $pos + 2 );
				$f['label'] = mb_strtoupper( mb_substr( $short, 0, 1 ) ) . mb_substr( $short, 1 );
			}
			$fields[] = $f;
		}
	}
	return $fields;
}

function simple_home_fields() {
	$tabs   = simple_acf_tabs(
		array(
			'Первый экран'      => array( 'home_hero_' ),
			'О студии'          => array( 'home_intro_', 'home_tags', 'home_pill' ),
			'Манифест и подход' => array( 'home_manifesto_', 'home_approach_' ),
			'Награды'           => array( 'home_awards_' ),
			'Стикеры'           => array( 'home_sticker_' ),
			'Услуги'            => array( 'home_services_', 'home_service_' ),
		),
		'home'
	);
	$fields = array();
	foreach ( $tabs as $f ) {
		$fields[] = $f;
		if ( 'field_home_home_awards_title' === $f['key'] ) {
			$fields[] = array( 'key' => 'field_home_awards_note', 'label' => '', 'name' => '', 'type' => 'message', 'message' => ' ', 'new_lines' => 'wpautop', 'esc_html' => 0 );
		}
		if ( 'field_home_home_service_more' === $f['key'] ) {
			$fields[] = array( 'key' => 'field_home_svc_note', 'label' => '', 'name' => '', 'type' => 'message', 'message' => ' ', 'new_lines' => 'wpautop', 'esc_html' => 0 );
		}
	}

	$n        = 0;
	foreach ( $fields as $f ) {
		if ( 'tab' === $f['type'] ) {
			$n++;
		}
	}
	$fields[] = array( 'key' => 'field_tab_home_clients', 'label' => ( $n + 1 ) . '. Клиенты', 'name' => '', 'type' => 'tab', 'placement' => 'top' );
	$fields[] = array( 'key' => 'field_home_clients_note', 'label' => '', 'name' => '', 'type' => 'message', 'message' => ' ', 'new_lines' => 'wpautop', 'esc_html' => 0 );
	return $fields;
}

add_action( 'acf/init', 'simple_register_acf' );
function simple_register_acf() {
	if ( ! function_exists( 'acf_add_local_field_group' ) ) {
		return;
	}

	$page_tpl = function ( $tpl ) {
		return array( array( array( 'param' => 'page_template', 'operator' => '==', 'value' => $tpl ) ) );
	};

	acf_add_local_field_group(
		array(
			'key'      => 'group_simple_home',
			'title'    => 'Главная страница',
			'fields'   => simple_home_fields(),
			'location' => array( array( array( 'param' => 'page_type', 'operator' => '==', 'value' => 'front_page' ) ) ),
			'menu_order' => 0,
		)
	);

	$groups = array(
		'about'    => array(
			'Страница «О нас»',
			'templates/template-about.php',
			array(
				'Заголовок'          => array( 'about_label', 'about_title', 'about_text', 'about_sticker' ),
				'Фото'               => array( 'about_photo' ),
				'Наш подход'         => array( 'about_appr_', 'about_prin_' ),
				'Факты'              => array( 'about_facts_', 'about_fact_' ),
				'Команда и клиенты'  => array( 'about_team_', 'about_clients_', 'about_awards_' ),
			),
		),
		'team'     => array(
			'Страница «Команда»',
			'templates/template-team.php',
			array(
				'Заголовок'               => array( 'team_label', 'team_title', 'team_text', 'team_sticker' ),
				'Блок «Хотите работать»'  => array( 'team_join_' ),
			),
		),
		'services' => array(
			'Страница «Услуги»',
			'templates/template-services.php',
			array(
				'Заголовок'                 => array( 'svcs_' ),
				'Подписи на страницах услуг' => array( 'svc_' ),
			),
		),
		'projects' => array(
			'Страница «Кейсы»',
			'templates/template-projects.php',
			array(
				'Заголовок'          => array( 'prjs_label', 'prjs_title', 'prjs_all', 'prjs_sticker' ),
				'Подписи страницы кейса' => array( 'prjs_case_' ),
			),
		),
	);
	foreach ( $groups as $id => $g ) {
		$gfields = simple_acf_tabs( $g[2], $id );
		if ( 'about' === $id ) {
			$with = array();
			foreach ( $gfields as $gf ) {
				$with[] = $gf;
				if ( 'field_about_about_photos_title' === $gf['key'] ) {
					$with[] = array( 'key' => 'field_about_photos_note', 'label' => '', 'name' => '', 'type' => 'message', 'message' => ' ', 'new_lines' => 'wpautop', 'esc_html' => 0 );
				}
				if ( 'field_about_about_clients_label' === $gf['key'] ) {
					$with[] = array( 'key' => 'field_about_clients_note', 'label' => '', 'name' => '', 'type' => 'message', 'message' => ' ', 'new_lines' => 'wpautop', 'esc_html' => 0 );
				}
				if ( 'field_about_about_awards_title' === $gf['key'] ) {
					$with[] = array( 'key' => 'field_about_awards_info', 'label' => 'Список наград', 'name' => '', 'type' => 'message', 'message' => 'Список наград общий для всего сайта. Чтобы добавить, удалить или изменить награду, откройте страницу «Главная» → вкладка «4. Награды». Здесь меняется только заголовок блока.', 'new_lines' => 'wpautop', 'esc_html' => 0 );
				}
			}
			$gfields = $with;
		}
		acf_add_local_field_group(
			array(
				'key'      => 'group_simple_' . $id,
				'title'    => $g[0],
				'fields'   => $gfields,
				'location' => $page_tpl( $g[1] ),
			)
		);
	}

	acf_add_local_field_group(
		array(
			'key'      => 'group_simple_contacts',
			'title'    => 'Страница «Контакты»',
			'fields'   => simple_acf_tabs(
				array(
					'Заголовок'   => array( 'cont_label', 'cont_title', 'cont_text', 'cont_sticker' ),
					'Чёрный блок' => array( 'cont_left_', 'cont_lbl_' ),
					'Форма'       => array( 'cont_form_', 'cont_f_', 'cont_btn', 'cont_consent' ),
				),
				'contacts'
			),
			'location' => $page_tpl( 'templates/template-contacts.php' ),
		)
	);

	acf_add_local_field_group(
		array(
			'key'      => 'group_simple_blog',
			'title'    => 'Страница «Блог»',
			'fields'   => simple_acf_tabs(
				array(
					'Заголовок' => array( 'blog_' ),
					'Статья'    => array( 'art_' ),
				),
				'blog'
			),
			'location' => array( array( array( 'param' => 'page_type', 'operator' => '==', 'value' => 'posts_page' ) ) ),
		)
	);

	$f   = array();
	$txt = function ( $key, $label, $type = 'text', $instr = '' ) {
		$a = array(
			'key'          => 'field_' . $key,
			'label'        => $label,
			'name'         => $key,
			'type'         => $type,
			'instructions' => $instr,
		);
		if ( 'textarea' === $type ) {
			$a['rows']      = 3;
			$a['new_lines'] = '';
		}
		return $a;
	};
	$tab = function ( $key, $label ) {
		return array( 'key' => 'field_tab_' . $key, 'label' => $label, 'name' => '', 'type' => 'tab', 'placement' => 'top' );
	};

	$f[] = $tab( 'svc_hero', 'Первый экран' );
	$f[] = $txt( 'svc_lead', 'Подзаголовок под названием услуги', 'textarea', 'Если пусто — берётся краткое описание услуги.' );
	$f[] = array( 'key' => 'field_svc_img_1', 'label' => 'Фоновая картинка первого экрана', 'name' => 'svc_img_1', 'type' => 'image', 'return_format' => 'id', 'preview_size' => 'medium' );
	$f[] = $txt( 'svc_case_title', 'Название кейса на первом экране' );
	$f[] = $txt( 'svc_case_tags', 'Теги кейса (например: ЛОГОТИП / АЙДЕНТИКА / НОСИТЕЛИ)' );
	$f[] = array( 'key' => 'field_svc_case_link', 'label' => 'Ссылка на кейс (запасная: если ниже нет проектов, покажется кнопка-стрелка)', 'name' => 'svc_case_link', 'type' => 'post_object', 'post_type' => array( 'project' ), 'return_format' => 'id', 'allow_null' => 1 );
	$f[] = array( 'key' => 'field_svc_projects_head', 'label' => 'Проекты на первом экране (Проект 1, Проект 2…)', 'name' => '', 'type' => 'message', 'message' => 'Квадратные превью внизу баннера. Видно 4, если добавить больше — появятся стрелки для прокрутки.', 'new_lines' => 'wpautop', 'esc_html' => 0 );
	$f[] = array( 'key' => 'field_svc_projects_note', 'label' => '', 'name' => '', 'type' => 'message', 'message' => ' ', 'new_lines' => 'wpautop', 'esc_html' => 0 );

	$f[] = $tab( 'svc_stages', 'Этапы' );
	$f[] = array( 'key' => 'field_svc_stages_note', 'label' => '', 'name' => '', 'type' => 'message', 'message' => ' ', 'new_lines' => 'wpautop', 'esc_html' => 0 );

	$f[] = $tab( 'svc_why', 'Зачем это бренду' );
	$f[] = $txt( 'svc_why_label', 'Подпись' );
	$f[] = $txt( 'svc_why_title', 'Заголовок (каждая строка — с новой строки)', 'textarea' );
	$f[] = $txt( 'svc_why_text', 'Текст', 'textarea' );

	$f[] = $tab( 'svc_get', 'Что вы получите' );
	$f[] = $txt( 'svc_get_sub', 'Подзаголовок', 'textarea' );
	$f[] = array( 'key' => 'field_svc_gets_note', 'label' => '', 'name' => '', 'type' => 'message', 'message' => ' ', 'new_lines' => 'wpautop', 'esc_html' => 0 );

	$f[] = $tab( 'svc_faq', 'Вопросы перед стартом' );
	$f[] = array( 'key' => 'field_svc_faq_note', 'label' => '', 'name' => '', 'type' => 'message', 'message' => ' ', 'new_lines' => 'wpautop', 'esc_html' => 0 );

	$f[] = $tab( 'svc_more', 'Другие проекты' );
	$f[] = array( 'key' => 'field_svc_more_projects', 'label' => 'Какие кейсы показать внизу (до 2)', 'name' => 'svc_more_projects', 'type' => 'relationship', 'post_type' => array( 'project' ), 'return_format' => 'id', 'max' => 2, 'instructions' => 'Если пусто — покажутся два последних кейса.' );

	acf_add_local_field_group(
		array(
			'key'      => 'group_simple_service',
			'title'    => 'Страница услуги',
			'fields'   => $f,
			'location' => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'service' ) ) ),
		)
	);

	acf_add_local_field_group(
		array(
			'key'      => 'group_simple_post',
			'title'    => 'Страница статьи',
			'fields'   => array(
				array( 'key' => 'field_post_art_help', 'label' => 'Как заполнять', 'name' => '', 'type' => 'message', 'message' => 'Название, краткое описание (лид), картинка обложки и вводный текст — в обычном редакторе выше (картинка обложки — «Изображение записи» справа). Разделы с заголовком слева, фото и цитатами добавляются здесь; оглавление «В этой статье» собирается из заголовков разделов автоматически.', 'new_lines' => 'wpautop', 'esc_html' => 0 ),
				array( 'key' => 'field_post_art_sections_note', 'label' => '', 'name' => '', 'type' => 'message', 'message' => ' ', 'new_lines' => 'wpautop', 'esc_html' => 0 ),
				array( 'key' => 'field_post_art_sticker_note', 'label' => '', 'name' => '', 'type' => 'message', 'message' => ' ', 'new_lines' => 'wpautop', 'esc_html' => 0 ),
			),
			'location' => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'post' ) ) ),
		)
	);

	acf_add_local_field_group(
		array(
			'key'      => 'group_simple_member',
			'title'    => 'Данные сотрудника',
			'fields'   => array(
				$txt( 'team_role', 'Должность' ),
				$txt( 'team_bio', 'Описание', 'textarea' ),
				$txt( 'team_link', 'Ссылка на сотрудника (LinkedIn, Behance и т.д.)', 'url', 'Необязательно. Если заполнить, имя на сайте станет ссылкой.' ),
			),
			'location' => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'team' ) ) ),
			'position' => 'acf_after_title',
		)
	);

	acf_add_local_field_group(
		array(
			'key'      => 'group_simple_award',
			'title'    => 'Данные награды',
			'fields'   => array( $txt( 'award_project', 'Проект' ) ),
			'location' => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'award' ) ) ),
			'position' => 'acf_after_title',
		)
	);

	acf_add_local_field_group(
		array(
			'key'      => 'group_simple_project',
			'title'    => 'Данные кейса',
			'fields'   => array(
				array( 'key' => 'field_project_slide', 'label' => 'Показывать в слайдере на главной', 'name' => 'project_slide', 'type' => 'true_false', 'ui' => 1, 'instructions' => 'Обложка кейса (миниатюра записи) станет фоном слайда на первом экране главной.' ),
				array( 'key' => 'field_project_footer', 'label' => 'Показывать в подвале сайта («Другие проекты»)', 'name' => 'project_footer', 'type' => 'true_false', 'ui' => 1, 'instructions' => 'Этот кейс будет в блоке «Другие проекты» внизу всех страниц. Если отмечено несколько — берётся первый по порядку. Если не отмечен ни один — первый кейс в списке.' ),
				$txt( 'project_tags', 'Подпись на карточке и в слайдере (услуги)', 'text', 'Например: Branding, Packaging. Если пусто — берётся краткое описание.' ),
				array( 'key' => 'field_project_badge', 'label' => 'Бейдж награды на карточке', 'name' => 'project_badge', 'type' => 'image', 'return_format' => 'id', 'preview_size' => 'thumbnail', 'instructions' => 'Необязательно. Маленькая ленточка-бейдж (например, награда) в левом верхнем углу карточки на странице «Кейсы». Лучше PNG или SVG с прозрачным фоном, примерно 40×63 px.' ),
				$txt( 'case_subtitle', 'Подзаголовок под названием (страница кейса)' ),
				$txt( 'case_client', 'Клиент' ),
				$txt( 'case_services', 'Услуги' ),
				$txt( 'case_place', 'Место' ),
				$txt( 'case_team', 'Команда проекта', 'textarea', 'Каждая строка: Должность | Имя. Например: Art Director | Nikita Chuvaldin' ),
				array( 'key' => 'field_project_blocks_help', 'label' => 'Содержимое страницы проекта', 'name' => '', 'type' => 'message', 'message' => 'Обложка (первое большое фото) — «Изображение записи» справа. Ниже добавляйте блоки по порядку, как в макете: фото или видео на всю ширину, два фото рядом, текстовый блок («ЗАДАЧА», «01 / НЕЙМИНГ»…), крупная фраза. Блоки можно переставлять стрелками. Если подпись начинается с цифры, заголовок и текст идут двумя равными колонками.', 'new_lines' => 'wpautop', 'esc_html' => 0 ),
				array( 'key' => 'field_project_blocks_note', 'label' => '', 'name' => '', 'type' => 'message', 'message' => ' ', 'new_lines' => 'wpautop', 'esc_html' => 0 ),
				array( 'key' => 'field_project_cover_alt', 'label' => 'Запасная обложка (для подвала, тёмная)', 'name' => 'project_cover_alt', 'type' => 'image', 'return_format' => 'id', 'preview_size' => 'medium' ),
			),
			'location' => array( array( array( 'param' => 'post_type', 'operator' => '==', 'value' => 'project' ) ) ),
		)
	);
}
