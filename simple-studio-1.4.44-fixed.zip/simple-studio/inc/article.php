<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function simple_article_parts( $html ) {
	$result = array( 'toc' => array(), 'intro' => '', 'body' => '' );
	if ( '' === trim( $html ) ) {
		return $result;
	}
	if ( ! class_exists( 'DOMDocument' ) ) {
		$result['intro'] = $html;
		return $result;
	}

	$dom = new DOMDocument();
	$previous_errors = libxml_use_internal_errors( true );
	$dom->loadHTML( '<?xml encoding="utf-8" ?><div id="root">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
	libxml_clear_errors();
	libxml_use_internal_errors( $previous_errors );
	$root = $dom->getElementById( 'root' );
	if ( ! $root ) {
		$result['intro'] = $html;
		return $result;
	}

	$outer = function ( $node ) use ( $dom ) {
		return $dom->saveHTML( $node );
	};

	$sections = array();
	$intro    = array();
	$cur      = -1;
	$n        = 0;

	foreach ( iterator_to_array( $root->childNodes ) as $node ) {
		if ( XML_TEXT_NODE === $node->nodeType && '' === trim( $node->textContent ) ) {
			continue;
		}
		$tag = ( XML_ELEMENT_NODE === $node->nodeType ) ? strtolower( $node->nodeName ) : '';

		if ( 'h2' === $tag ) {
			$n++;
			$title = trim( $node->textContent );
			$id    = 'sec-' . $n;
			$sections[] = array( 'title' => $title, 'id' => $id, 'items' => array() );
			$cur        = count( $sections ) - 1;
			$result['toc'][] = array( 'id' => $id, 'title' => $title );
			continue;
		}

		$html_node = $outer( $node );
		$kind      = 'text';
		if ( 'blockquote' === $tag ) {
			$kind = 'band';
		} elseif ( 'figure' === $tag || 'img' === $tag ) {
			$kind = 'wide';
		} elseif ( 'div' === $tag && false !== strpos( (string) $node->getAttribute( 'class' ), 'wp-block-gallery' ) ) {
			$kind = 'wide';
		} elseif ( 'p' === $tag && 1 === $node->childNodes->length && XML_ELEMENT_NODE === $node->firstChild->nodeType && 'img' === strtolower( $node->firstChild->nodeName ) ) {
			$kind = 'wide';
		}

		if ( $cur < 0 ) {
			$intro[] = array( $kind, $html_node );
		} else {
			$sections[ $cur ]['items'][] = array( $kind, $html_node );
		}
	}

	$out = '';
	foreach ( $intro as $it ) {
		$out .= $it[1];
	}
	$result['intro'] = $out;

	$body = '';
	$head = function ( $sec ) {
		return '<h2 id="' . esc_attr( $sec['id'] ) . '" class="art-row__title">' . esc_html( $sec['title'] ) . '</h2>';
	};
	foreach ( $sections as $sec ) {
		$buf    = '';
		$titled = false;
		$emit   = function () use ( &$buf, &$body, &$titled, $sec, $head ) {
			if ( '' === $buf && $titled ) {
				return;
			}
			$body  .= '<div class="art-row"><div class="art-row__side">' . ( $titled ? '' : $head( $sec ) ) . '</div><div class="art-row__text">' . $buf . '</div></div>';
			$titled = true;
			$buf    = '';
		};
		foreach ( $sec['items'] as $it ) {
			if ( 'text' === $it[0] ) {
				$buf .= $it[1];
				continue;
			}
			$emit();
			$body .= ( 'band' === $it[0] ) ? '<div class="art-band">' . $it[1] . '</div>' : '<div class="art-wide">' . $it[1] . '</div>';
		}
		$emit();
	}
	$result['body'] = $body;
	return $result;
}

function simple_fmt( $text ) {
	$t = esc_html( $text );
	$t = preg_replace( '/\*{4,}/u', '', $t );
	$t = preg_replace( '/\*\*\*(.+?)\*\*\*/su', '<strong><em>$1</em></strong>', $t );
	$t = preg_replace( '/\*\*(.+?)\*\*/su', '<strong>$1</strong>', $t );
	$t = preg_replace( '/(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)/su', '<em>$1</em>', $t );
	$t = preg_replace_callback(
		'/\[([^\]]+)\]\(([^)\s]+)\)/u',
		function ( $m ) {
			$url = esc_url( html_entity_decode( $m[2] ) );
			return $url ? '<a href="' . $url . '">' . $m[1] . '</a>' : $m[1];
		},
		$t
	);
	return wpautop( $t );
}

function simple_rich_html( $text ) {
	if ( false === strpos( $text, '<' ) ) {
		return simple_fmt( $text );
	}
	$h = wp_kses( $text, simple_rich_tags() );
	return false === strpos( $h, '<p' ) ? wpautop( $h ) : $h;
}

function simple_article_sections( $post_id, array $parts ) {
	$rows = simple_rep_rows( $post_id, 'art_sections' );
	$n    = count( $parts['toc'] );
	foreach ( $rows as $r ) {
		$title = isset( $r['title'] ) ? trim( $r['title'] ) : '';
		$text  = isset( $r['text'] ) ? trim( $r['text'] ) : '';
		$id    = 'sec-' . ( ++$n );
		$html  = '<div class="art-row"><div class="art-row__side">';
		if ( '' !== $title ) {
			$lv    = ( isset( $r['level'] ) && in_array( $r['level'], array( 'h1', 'h2', 'h3', 'h4' ), true ) ) ? $r['level'] : 'h2';
			$html .= '<' . $lv . ' id="' . esc_attr( $id ) . '" class="art-row__title art-row__title--' . $lv . '">' . esc_html( $title ) . '</' . $lv . '>';
			$parts['toc'][] = array( 'id' => $id, 'title' => $title );
		}
		$html .= '</div><div class="art-row__text">' . simple_rich_html( $text ) . '</div></div>';
		$imgs = array_filter( array( (int) ( $r['img'] ?? 0 ), (int) ( $r['img2'] ?? 0 ) ) );
		if ( $imgs ) {
			$html .= '<div class="art-wide' . ( count( $imgs ) > 1 ? ' art-wide--two' : '' ) . '"><figure>';
			$html .= '<div class="art-wide__imgs">';
			foreach ( $imgs as $im ) {
				$html .= wp_get_attachment_image( $im, 'large' );
			}
			$html .= '</div>';
			if ( ! empty( $r['caption'] ) ) {
				$html .= '<figcaption>' . esc_html( $r['caption'] ) . '</figcaption>';
			}
			$html .= '</figure></div>';
		}
		if ( ! empty( $r['quote'] ) ) {
			$html .= '<div class="art-band"><blockquote>' . nl2br( esc_html( $r['quote'] ) ) . '</blockquote></div>';
		}
		$parts['body'] .= $html;
	}
	return $parts;
}

function simple_post_sticker( $post_id, $default, $class ) {
	$rows = simple_rep_rows( $post_id, 'art_sticker' );
	if ( $rows && ! empty( $rows[0]['img'] ) ) {
		return simple_img( (int) $rows[0]['img'], 'medium', $class . ' is-custom', array( 'aria-hidden' => 'true', 'alt' => '' ) );
	}
	return simple_asset_img( $default, 48, 48, $class );
}

function simple_card_tone( $index ) {
	$tones = array( 'black', 'subtle', 'subtle', 'black', 'subtle', 'accent', 'black' );
	return $tones[ $index % count( $tones ) ];
}

function simple_card_slot( $index ) {
	$slots = array( 'wide', 'third', 'third', 'wide', 'third', 'third', 'third' );
	return $slots[ $index % count( $slots ) ];
}

function simple_case_render( $html ) {
	if ( '' === trim( $html ) ) {
		return '';
	}
	if ( ! class_exists( 'DOMDocument' ) ) {
		return $html;
	}
	$dom = new DOMDocument();
	$previous_errors = libxml_use_internal_errors( true );
	$dom->loadHTML( '<?xml encoding="utf-8" ?><div id="root">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
	libxml_clear_errors();
	libxml_use_internal_errors( $previous_errors );
	$root = $dom->getElementById( 'root' );
	if ( ! $root ) {
		return $html;
	}

	$out   = '';
	$title = '';
	$buf   = '';
	$half  = false;
	$flush = function () use ( &$out, &$title, &$buf, &$half ) {
		if ( '' === $title && '' === $buf ) {
			return;
		}
		if ( '' === trim( $buf ) && '' !== $title ) {
			$out  .= '<div class="case-statement"><p>' . nl2br( esc_html( $title ) ) . '</p></div>';
			$title = '';
			return;
		}
		$out  .= '<section class="case-chapter' . ( $half ? ' case-chapter--half' : '' ) . '"><div class="case-chapter__title">' . ( '' !== $title ? '<h2>' . esc_html( $title ) . '</h2>' : '' ) . '</div><div class="case-chapter__text prose">' . $buf . '</div></section>';
		$title = '';
		$buf   = '';
	};

	foreach ( iterator_to_array( $root->childNodes ) as $node ) {
		if ( XML_TEXT_NODE === $node->nodeType && '' === trim( $node->textContent ) ) {
			continue;
		}
		$tag   = ( XML_ELEMENT_NODE === $node->nodeType ) ? strtolower( $node->nodeName ) : '';
		$class = ( XML_ELEMENT_NODE === $node->nodeType ) ? (string) $node->getAttribute( 'class' ) : '';
		$raw   = $dom->saveHTML( $node );

		$is_gallery = ( 'figure' === $tag && false !== strpos( $class, 'wp-block-gallery' ) ) || ( 'div' === $tag && false !== strpos( $class, 'wp-block-gallery' ) );
		$is_image   = in_array( $tag, array( 'figure', 'img' ), true )
			|| ( 'p' === $tag && 1 === $node->childNodes->length && $node->firstChild && XML_ELEMENT_NODE === $node->firstChild->nodeType && 'img' === strtolower( $node->firstChild->nodeName ) );

		if ( 'h3' === $tag ) {
			$flush();
			$label = trim( $node->textContent );
			$half  = (bool) preg_match( '/^\d/u', $label );
			$out  .= '<p class="case-eyebrow eyebrow">' . esc_html( $label ) . '</p>';
		} elseif ( 'blockquote' === $tag ) {
			$flush();
			$out .= '<div class="case-statement">' . wp_kses_post( $node->textContent ? wpautop( esc_html( trim( $node->textContent ) ) ) : '' ) . '</div>';
		} elseif ( 'h2' === $tag ) {
			$flush();
			$title = trim( $node->textContent );
		} elseif ( $is_gallery ) {
			$flush();
			$out .= '<div class="case-gallery">' . $raw . '</div>';
		} elseif ( $is_image ) {
			$flush();
			$out .= '<div class="case-image">' . $raw . '</div>';
		} else {
			$buf .= $raw;
		}
	}
	$flush();
	return $out;
}

function simple_case_media( $img, $video, $eager = false ) {
	$video = trim( (string) $video );
	if ( '' !== $video ) {
		if ( preg_match( '~(?:youtube\.com/(?:watch\?v=|embed/)|youtu\.be/)([\w-]{6,})~i', $video, $m ) ) {
			return '<div class="case-embed"><iframe src="https://www.youtube.com/embed/' . esc_attr( $m[1] ) . '" loading="lazy" allowfullscreen title="Видео"></iframe></div>';
		}
		if ( preg_match( '~vimeo\.com/(?:video/)?(\d+)~i', $video, $m ) ) {
			return '<div class="case-embed"><iframe src="https://player.vimeo.com/video/' . esc_attr( $m[1] ) . '" loading="lazy" allowfullscreen title="Видео"></iframe></div>';
		}
		return '<video class="case-video" src="' . esc_url( $video ) . '" autoplay muted loop playsinline preload="metadata"></video>';
	}
	return $img ? simple_img( (int) $img, 'simple-wide', '', $eager ? array( 'loading' => 'eager' ) : array() ) : '';
}

function simple_case_blocks( $post_id ) {
	$rows = simple_rep_rows( $post_id, 'case_blocks' );
	$out  = '';
	foreach ( $rows as $r ) {
		$type = isset( $r['type'] ) ? $r['type'] : 'media';
		if ( 'media' === $type ) {
			$m = simple_case_media( $r['img'] ?? 0, $r['video'] ?? '' );
			if ( $m ) {
				$out .= '<div class="case-image">' . $m . '</div>';
			}
		} elseif ( 'two' === $type ) {
			$a = simple_case_media( $r['img'] ?? 0, $r['video'] ?? '' );
			$b = simple_case_media( $r['img2'] ?? 0, $r['video2'] ?? '' );
			if ( $a || $b ) {
				$out .= '<div class="case-gallery case-gallery--blocks"><div>' . $a . '</div><div>' . $b . '</div></div>';
			}
		} elseif ( 'chapter' === $type ) {
			$label = trim( $r['label'] ?? '' );
			$title = trim( $r['title'] ?? '' );
			$text  = trim( $r['text'] ?? '' );
			if ( '' === $label . $title . $text ) {
				continue;
			}
			if ( '' === trim( wp_strip_all_tags( $text ) ) && '' !== $title && '' === $label ) {
				$out .= '<div class="case-statement"><p>' . nl2br( esc_html( $title ) ) . '</p></div>';
				continue;
			}
			$half = (bool) preg_match( '/^\d/u', $label );
			if ( '' !== $label ) {
				$out .= '<p class="case-eyebrow eyebrow">' . esc_html( $label ) . '</p>';
			}
			$out .= '<section class="case-chapter' . ( $half ? ' case-chapter--half' : '' ) . '"><div class="case-chapter__title">' . ( '' !== $title ? '<h2>' . nl2br( esc_html( $title ) ) . '</h2>' : '' ) . '</div><div class="case-chapter__text prose">' . simple_rich_html( $text ) . '</div></section>';
		} elseif ( 'statement' === $type && ! empty( $r['text'] ) ) {
			$out .= '<div class="case-statement">' . simple_rich_html( $r['text'] ) . '</div>';
		}
	}
	return $out;
}

function simple_case_team( $raw ) {
	$out  = array();
	$last = -1;
	foreach ( preg_split( '/\R/u', (string) $raw ) as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		$role  = '';
		$names = $line;
		if ( preg_match( '/^(.+?)\s*(?:\||:|\s[—–-]\s)\s*(.+)$/u', $line, $m ) ) {
			$role  = trim( $m[1] );
			$names = $m[2];
		}
		$list = array_values( array_filter( array_map( 'trim', preg_split( '/[;,]/u', $names ) ) ) );
		if ( '' === $role && $last >= 0 ) {
			$out[ $last ][1] = array_merge( $out[ $last ][1], $list );
		} elseif ( $list ) {
			$out[] = array( $role, $list );
			$last  = count( $out ) - 1;
		}
	}
	return $out;
}
