<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function simple_seo_types() {
	return array( 'page', 'post', 'project', 'service' );
}

function simple_native_seo_enabled() {
	$plugin_active = defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'SEOPRESS_VERSION' ) || function_exists( 'aioseo' ) || function_exists( 'the_seo_framework' );
	return (bool) apply_filters( 'simple_native_seo_enabled', ! $plugin_active );
}

add_action( 'add_meta_boxes', function () {
	foreach ( simple_seo_types() as $type ) {
		add_meta_box( 'simple_seo', 'SEO: заголовок и описание для поисковиков', 'simple_seo_box', $type, 'normal', 'low' );
	}
} );

function simple_seo_box( $post ) {
	wp_nonce_field( 'simple_seo', 'simple_seo_nonce' );
	$t = get_post_meta( $post->ID, '_simple_seo_title', true );
	$d = get_post_meta( $post->ID, '_simple_seo_desc', true );
	?>
	<p><label for="simple_seo_title"><strong>Заголовок (title)</strong></label><br>
	<input type="text" class="widefat" id="simple_seo_title" name="simple_seo_title" value="<?php echo esc_attr( $t ); ?>" placeholder="<?php echo esc_attr( get_the_title( $post ) ); ?>" maxlength="70">
	<span class="description">До 60–70 символов. Если пусто — берётся название страницы.</span></p>
	<p><label for="simple_seo_desc"><strong>Описание (description)</strong></label><br>
	<textarea class="widefat" rows="3" id="simple_seo_desc" name="simple_seo_desc" maxlength="320"><?php echo esc_textarea( $d ); ?></textarea>
	<span class="description">120–160 символов — это текст под ссылкой в Google и Яндексе. Если пусто — берётся краткое описание или начало текста.</span></p>
	<?php
}

add_action( 'save_post', function ( $post_id ) {
	if ( ! isset( $_POST['simple_seo_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['simple_seo_nonce'] ) ), 'simple_seo' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	update_post_meta( $post_id, '_simple_seo_title', isset( $_POST['simple_seo_title'] ) ? sanitize_text_field( wp_unslash( $_POST['simple_seo_title'] ) ) : '' );
	update_post_meta( $post_id, '_simple_seo_desc', isset( $_POST['simple_seo_desc'] ) ? sanitize_textarea_field( wp_unslash( $_POST['simple_seo_desc'] ) ) : '' );
} );

function simple_seo_queried_id() {
	if ( is_home() && ! is_front_page() ) {
		return (int) get_option( 'page_for_posts' );
	}
	return is_singular() ? get_queried_object_id() : 0;
}

add_filter( 'pre_get_document_title', function ( $title ) {
	if ( ! simple_native_seo_enabled() ) {
		return $title;
	}
	$id = simple_seo_queried_id();
	if ( $id ) {
		$custom = get_post_meta( $id, '_simple_seo_title', true );
		if ( $custom ) {
			return $custom . ' — ' . get_bloginfo( 'name' );
		}
	}
	return $title;
} );

add_filter( 'document_title_separator', function () {
	return '—';
} );

function simple_seo_description() {
	$id = simple_seo_queried_id();
	$d  = '';
	if ( $id ) {
		$d = (string) get_post_meta( $id, '_simple_seo_desc', true );
		if ( '' === $d && is_singular() && ! is_front_page() ) {
			$d = has_excerpt( $id ) ? get_the_excerpt( $id ) : '';
			if ( '' === $d ) {
				foreach ( array( 'case_subtitle', 'svc_lead', 'svc_text' ) as $k ) {
					$v = get_post_meta( $id, $k, true );
					if ( is_string( $v ) && '' !== trim( $v ) ) {
						$d = $v;
						break;
					}
				}
			}
			if ( '' === $d ) {
				$d = wp_strip_all_tags( strip_shortcodes( get_post_field( 'post_content', $id ) ) );
			}
		}
	}
	if ( '' === $d && is_category() ) {
		$d = category_description();
	}
	if ( '' === $d ) {
		$d = simple_opt( 'seo_desc' );
	}
	$d = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $d ) ) );
	return preg_match_all( '/./us', $d ) > 170 ? rtrim( wp_html_excerpt( $d, 167 ), " ,.;:-—" ) . '…' : $d;
}

function simple_seo_image() {
	$id = is_singular() ? get_post_thumbnail_id( get_queried_object_id() ) : 0;
	if ( $id ) {
		$src = wp_get_attachment_image_src( $id, 'large' );
		if ( $src ) {
			return array( $src[0], (int) $src[1], (int) $src[2] );
		}
	}
	$logo = (int) get_theme_mod( 'custom_logo' );
	if ( $logo ) {
		$src = wp_get_attachment_image_src( $logo, 'full' );
		if ( $src ) {
			return array( $src[0], (int) $src[1], (int) $src[2] );
		}
	}
	return array( SIMPLE_URI . '/assets/img/logo.png', 115, 18 );
}

function simple_seo_canonical() {
	if ( is_singular() ) {
		return get_permalink( get_queried_object_id() );
	}
	if ( is_home() || is_front_page() ) {
		$url = is_front_page() ? home_url( '/' ) : get_permalink( (int) get_option( 'page_for_posts' ) );
		$pg  = (int) get_query_var( 'paged' );
		return $pg > 1 ? trailingslashit( $url ) . 'page/' . $pg . '/' : $url;
	}
	if ( is_category() || is_tag() || is_tax() ) {
		return get_term_link( get_queried_object() );
	}
	return '';
}

add_action( 'wp_head', function () {
	if ( is_404() || ! simple_native_seo_enabled() ) {
		return;
	}
	$title = wp_get_document_title();
	$desc  = simple_seo_description();
	$url   = simple_seo_canonical();
	$img   = simple_seo_image();
	$type  = is_singular( 'post' ) ? 'article' : 'website';
	if ( $desc ) {
		echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
	}
	if ( $url && ! is_singular() ) {
		echo '<link rel="canonical" href="' . esc_url( $url ) . '">' . "\n";
	}
	$og = array(
		'og:locale'      => str_replace( '-', '_', get_locale() ),
		'og:type'        => $type,
		'og:site_name'   => get_bloginfo( 'name' ),
		'og:title'       => $title,
		'og:description' => $desc,
		'og:url'         => $url,
		'og:image'       => $img[0],
	);
	if ( $img[1] && $img[2] ) {
		$og['og:image:width']  = $img[1];
		$og['og:image:height'] = $img[2];
	}
	if ( is_singular( 'post' ) ) {
		$og['article:published_time'] = get_the_date( 'c', get_queried_object_id() );
		$og['article:modified_time']  = get_the_modified_date( 'c', get_queried_object_id() );
	}
	foreach ( $og as $k => $v ) {
		if ( '' !== (string) $v ) {
			echo '<meta property="' . esc_attr( $k ) . '" content="' . esc_attr( $v ) . '">' . "\n";
		}
	}
	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	echo '<meta name="twitter:title" content="' . esc_attr( $title ) . '">' . "\n";
	if ( $desc ) {
		echo '<meta name="twitter:description" content="' . esc_attr( $desc ) . '">' . "\n";
	}
	echo '<meta name="twitter:image" content="' . esc_url( $img[0] ) . '">' . "\n";
}, 2 );

add_filter( 'wp_robots', function ( $robots ) {
	if ( is_search() || is_404() || is_attachment() || is_post_type_archive( 'lead' ) || is_singular( 'lead' ) ) {
		$robots['noindex'] = true;
		$robots['follow']  = true;
		unset( $robots['max-image-preview'] );
	}
	return $robots;
} );

function simple_seo_breadcrumbs() {
	$items = array( array( 'name' => get_bloginfo( 'name' ), 'url' => home_url( '/' ) ) );
	if ( is_front_page() ) {
		return array();
	}
	$section = simple_current_section();
	if ( is_singular( 'service' ) ) {
		$items[] = array( 'name' => 'Услуги', 'url' => simple_section_url( 'services' ) );
	} elseif ( is_singular( 'project' ) ) {
		$items[] = array( 'name' => 'Проекты', 'url' => simple_section_url( 'projects' ) );
	} elseif ( is_singular( 'post' ) ) {
		$items[] = array( 'name' => 'Блог', 'url' => simple_section_url( 'blog' ) );
	}
	if ( is_singular() ) {
		$items[] = array( 'name' => get_the_title( get_queried_object_id() ), 'url' => get_permalink( get_queried_object_id() ) );
	} elseif ( is_home() ) {
		$items[] = array( 'name' => 'Блог', 'url' => simple_section_url( 'blog' ) );
	} elseif ( '' !== $section ) {
		$items[] = array( 'name' => wp_strip_all_tags( wp_get_document_title() ), 'url' => simple_seo_canonical() );
	}
	return count( $items ) > 1 ? $items : array();
}

add_action( 'wp_head', function () {
	if ( is_404() || ! simple_native_seo_enabled() ) {
		return;
	}
	$home = home_url( '/' );
	$logo = simple_seo_image();
	$sameas = array();
	foreach ( array( 'instagram', 'behance', 'linkedin' ) as $n ) {
		$u = simple_opt( $n );
		if ( $u && 0 === strpos( $u, 'http' ) ) {
			$sameas[] = $u;
		}
	}
	$graph = array(
		array(
			'@type'        => 'Organization',
			'@id'          => $home . '#organization',
			'name'         => get_bloginfo( 'name' ),
			'url'          => $home,
			'logo'         => $logo[0],
			'email'        => simple_opt( 'email' ),
			'telephone'    => simple_opt( 'phone' ),
			'sameAs'       => $sameas,
			'contactPoint' => array(
				'@type'             => 'ContactPoint',
				'contactType'       => 'sales',
				'telephone'         => simple_opt( 'phone' ),
				'email'             => simple_opt( 'email' ),
				'availableLanguage' => array( 'ru' ),
			),
		),
		array(
			'@type'     => 'WebSite',
			'@id'       => $home . '#website',
			'url'       => $home,
			'name'      => get_bloginfo( 'name' ),
			'inLanguage'=> get_bloginfo( 'language' ),
			'publisher' => array( '@id' => $home . '#organization' ),
		),
	);
	if ( is_singular() ) {
		$id    = get_queried_object_id();
		$page  = array(
			'@type'         => is_singular( 'post' ) ? 'BlogPosting' : 'WebPage',
			'@id'           => get_permalink( $id ) . '#page',
			'url'           => get_permalink( $id ),
			'name'          => get_the_title( $id ),
			'description'   => simple_seo_description(),
			'inLanguage'    => get_bloginfo( 'language' ),
			'isPartOf'      => array( '@id' => $home . '#website' ),
			'datePublished' => get_the_date( 'c', $id ),
			'dateModified'  => get_the_modified_date( 'c', $id ),
		);
		$thumb = get_post_thumbnail_id( $id );
		if ( $thumb ) {
			$page['image'] = wp_get_attachment_image_url( $thumb, 'large' );
		}
		if ( is_singular( 'post' ) ) {
			$page['headline']  = get_the_title( $id );
			$page['author']    = array( '@id' => $home . '#organization' );
			$page['publisher'] = array( '@id' => $home . '#organization' );
			$page['mainEntityOfPage'] = get_permalink( $id );
		}
		$graph[] = $page;
		if ( is_singular( 'service' ) ) {
			$graph[] = array(
				'@type'       => 'Service',
				'name'        => get_the_title( $id ),
				'description' => simple_seo_description(),
				'url'         => get_permalink( $id ),
				'provider'    => array( '@id' => $home . '#organization' ),
				'areaServed'  => 'KZ',
			);
		}
		if ( is_singular( 'project' ) ) {
			$graph[] = array(
				'@type'   => 'CreativeWork',
				'name'    => get_the_title( $id ),
				'url'     => get_permalink( $id ),
				'creator' => array( '@id' => $home . '#organization' ),
			);
		}
	}
	$crumbs = simple_seo_breadcrumbs();
	if ( $crumbs ) {
		$list = array();
		foreach ( $crumbs as $i => $c ) {
			$list[] = array( '@type' => 'ListItem', 'position' => $i + 1, 'name' => $c['name'], 'item' => $c['url'] );
		}
		$graph[] = array( '@type' => 'BreadcrumbList', 'itemListElement' => $list );
	}
	$clean = function ( $v ) use ( &$clean ) {
		if ( ! is_array( $v ) ) {
			return $v;
		}
		$out = array();
		foreach ( $v as $k => $x ) {
			$x = $clean( $x );
			if ( '' !== $x && null !== $x && array() !== $x ) {
				$out[ $k ] = $x;
			}
		}
		return $out;
	};
	echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => $clean( $graph ) ), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) . '</script>' . "\n";
}, 3 );

add_filter( 'wp_get_attachment_image_attributes', function ( $attr, $attachment ) {
	if ( empty( $attr['alt'] ) && empty( $attr['aria-hidden'] ) ) {
		$alt = get_post_meta( $attachment->ID, '_wp_attachment_image_alt', true );
		$attr['alt'] = $alt ? $alt : wp_strip_all_tags( $attachment->post_title );
	}
	return $attr;
}, 10, 2 );

add_filter( 'script_loader_tag', function ( $tag, $handle ) {
	if ( in_array( $handle, array( 'simple-main', 'simple-lenis' ), true ) && false === strpos( $tag, ' defer' ) ) {
		return str_replace( ' src=', ' defer src=', $tag );
	}
	return $tag;
}, 10, 2 );

add_filter( 'robots_txt', function ( $output ) {
	return $output . "Disallow: /wp-admin/\nAllow: /wp-admin/admin-ajax.php\n";
}, 20 );

remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'wp_shortlink_wp_head' );
add_filter( 'wp_sitemaps_add_provider', function ( $provider, $name ) {
	return 'users' === $name ? false : $provider;
}, 10, 2 );
add_filter( 'wp_sitemaps_post_types', function ( $types ) {
	unset( $types['lead'] );
	return $types;
} );
