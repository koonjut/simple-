<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'after_setup_theme', 'simple_setup' );
function simple_setup() {
	load_theme_textdomain( 'simple', SIMPLE_DIR . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'custom-logo', array( 'height' => 36, 'width' => 230, 'flex-width' => true, 'flex-height' => true ) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );

	add_image_size( 'simple-card', 960, 640, true );
	add_image_size( 'simple-wide', 1920, 1200, false );

	register_nav_menus(
		array(
			'primary'       => 'Главное меню (шапка)',
			'mobile'        => 'Мобильное меню',
			'footer_1'      => 'Подвал — колонка 1',
			'footer_2'      => 'Подвал — колонка 2',
			'footer_social' => 'Подвал — соцсети',
		)
	);
}

add_action( 'wp_enqueue_scripts', 'simple_assets' );
function simple_assets() {
	wp_enqueue_style( 'simple-fonts', SIMPLE_URI . '/assets/css/fonts.css', array(), SIMPLE_VERSION );
	wp_enqueue_style( 'simple-main', SIMPLE_URI . '/assets/css/main.css', array( 'simple-fonts' ), SIMPLE_VERSION );
	wp_enqueue_script( 'simple-lenis', SIMPLE_URI . '/assets/js/vendor/lenis.min.js', array(), '1.1.20', true );
	wp_enqueue_script( 'simple-main', SIMPLE_URI . '/assets/js/main.js', array( 'simple-lenis' ), SIMPLE_VERSION, true );
	wp_localize_script(
		'simple-main',
		'SimpleCfg',
		array(
			'ajax'  => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'simple_lead' ),
			'ok'     => simple_opt( 'form_ok' ),
			'err'    => simple_opt( 'form_err' ),
			'sending' => simple_opt( 'form_sending' ),
			'broken' => simple_opt( 'img_broken' ),
			'retry'  => simple_opt( 'form_retry' ),
		)
	);
}

add_action( 'wp_head', 'simple_preload_fonts', 1 );
function simple_preload_fonts() {
	foreach ( array( 'roboto-cyrillic-400-normal', 'roboto-cyrillic-500-normal', 'roboto-latin-500-normal' ) as $f ) {
		printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( SIMPLE_URI . '/assets/fonts/' . $f . '.woff2' ) );
	}
}

remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'wp_head', 'wp_generator' );

add_filter( 'body_class', function ( $classes ) {
	$s = simple_current_section();
	if ( $s ) {
		$classes[] = 'section-' . $s;
	}
	return $classes;
} );

add_filter( 'excerpt_length', function () {
	return 30;
}, 99 );
add_filter( 'excerpt_more', function () {
	return '…';
} );

add_action( 'admin_notices', function () {
	if ( function_exists( 'get_field' ) || ! current_user_can( 'install_plugins' ) ) {
		return;
	}
	echo '<div class="notice notice-warning"><p><strong>Simple Studio:</strong> чтобы редактировать тексты страниц, установите и активируйте бесплатный плагин <em>Advanced Custom Fields</em> (Плагины → Добавить новый).</p></div>';
} );

function simple_reading_time( $post_id = null ) {
	$text  = wp_strip_all_tags( get_post_field( 'post_content', $post_id ) );
	$words = max( 1, str_word_count( $text, 0, 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюяӘәҒғҚқҢңӨөҰұҮүҺһІі' ) );
	return max( 1, (int) ceil( $words / 180 ) );
}
