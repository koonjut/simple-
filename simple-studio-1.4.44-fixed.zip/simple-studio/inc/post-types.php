<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'init', 'simple_register_types' );
function simple_register_types() {
	$common = array(
		'public'       => true,
		'show_in_rest' => true,
		'has_archive'  => false,
		'menu_position' => 20,
	);

	register_post_type(
		'service',
		array_merge(
			$common,
			array(
				'labels'     => simple_labels( 'Услуга', 'Услуги', 'Добавить услугу' ),
				'menu_icon'  => 'dashicons-lightbulb',
				'supports'   => array( 'title', 'editor', 'excerpt', 'page-attributes', 'thumbnail' ),
				'rewrite'    => array( 'slug' => 'services', 'with_front' => false ),
				'hierarchical' => false,
			)
		)
	);

	register_post_type(
		'project',
		array_merge(
			$common,
			array(
				'labels'    => simple_labels( 'Кейс', 'Кейсы', 'Добавить кейс' ),
				'menu_icon' => 'dashicons-portfolio',
				'supports'  => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes' ),
				'rewrite'   => array( 'slug' => 'projects', 'with_front' => false ),
			)
		)
	);

	register_taxonomy(
		'project_cat',
		'project',
		array(
			'labels'       => simple_labels( 'Категория', 'Категории кейсов', 'Добавить категорию' ),
			'public'       => true,
			'hierarchical' => true,
			'show_in_rest' => true,
			'show_admin_column' => true,
			'rewrite'      => array( 'slug' => 'project-category', 'with_front' => false ),
		)
	);

	$private = array(
		'public'       => false,
		'show_ui'      => true,
		'show_in_rest' => false,
		'menu_position' => 21,
	);

	register_post_type(
		'team',
		array_merge(
			$private,
			array(
				'labels'    => simple_labels( 'Сотрудник', 'Команда', 'Добавить сотрудника' ),
				'menu_icon' => 'dashicons-groups',
				'supports'  => array( 'title', 'thumbnail', 'page-attributes' ),
			)
		)
	);

	register_post_type(
		'award',
		array_merge(
			$private,
			array(
				'labels'    => simple_labels( 'Награда', 'Награды', 'Добавить награду' ),
				'menu_icon' => 'dashicons-awards',
				'supports'  => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
			)
		)
	);

	register_post_type(
		'client',
		array_merge(
			$private,
			array(
				'labels'    => simple_labels( 'Клиент', 'Клиенты (логотипы)', 'Добавить клиента' ),
				'menu_icon' => 'dashicons-building',
				'supports'  => array( 'title', 'thumbnail', 'page-attributes' ),
			)
		)
	);

	register_post_type(
		'lead',
		array(
			'labels'       => simple_labels( 'Заявка', 'Заявки', 'Добавить заявку' ),
			'public'       => false,
			'show_ui'      => true,
			'show_in_rest' => false,
			'menu_icon'    => 'dashicons-email-alt',
			'menu_position' => 22,
			'supports'     => array( 'title' ),
			'capability_type' => 'post',
			'capabilities' => array( 'create_posts' => 'do_not_allow' ),
			'map_meta_cap' => true,
		)
	);
}

function simple_labels( $one, $many, $add ) {
	return array(
		'name'               => $many,
		'singular_name'      => $one,
		'menu_name'          => $many,
		'add_new'            => 'Добавить',
		'add_new_item'       => $add,
		'edit_item'          => 'Редактировать',
		'new_item'           => 'Новая запись',
		'view_item'          => 'Посмотреть',
		'search_items'       => 'Найти',
		'not_found'          => 'Ничего не найдено',
		'not_found_in_trash' => 'В корзине пусто',
		'all_items'          => 'Все записи',
	);
}

add_filter( 'manage_lead_posts_columns', function () {
	return array(
		'cb'    => '<input type="checkbox" />',
		'title' => 'Имя',
		'phone' => 'Телефон',
		'page'  => 'Страница',
		'notification' => 'Уведомление на почту',
		'date'  => 'Дата',
	);
} );
add_action( 'manage_lead_posts_custom_column', function ( $col, $id ) {
	if ( 'notification' === $col ) {
		$status = get_post_meta( $id, '_lead_mail_status', true );
		echo esc_html( 'failed' === $status ? 'Не отправлено — заявка сохранена' : ( 'accepted' === $status ? 'Передано почтовой системе' : 'Нет данных' ) );
	}
	if ( 'phone' === $col ) {
		echo esc_html( get_post_meta( $id, '_lead_phone', true ) );
	}
	if ( 'page' === $col ) {
		echo esc_html( get_post_meta( $id, '_lead_page', true ) );
	}
}, 10, 2 );

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'lead_data', 'Данные заявки', function ( $post ) {
		printf(
			'<p><strong>Имя:</strong> %s</p><p><strong>Контакт:</strong> %s</p><p><strong>Сообщение:</strong> %s</p><p><strong>Страница:</strong> %s</p>',
			esc_html( $post->post_title ),
			esc_html( get_post_meta( $post->ID, '_lead_phone', true ) ),
			esc_html( get_post_meta( $post->ID, '_lead_message', true ) ),
			esc_html( get_post_meta( $post->ID, '_lead_page', true ) )
		);
	}, 'lead', 'normal', 'high' );
} );

add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() || ! $q->is_main_query() ) {
		return;
	}
	if ( $q->is_home() ) {
		$q->set( 'posts_per_page', 9 );
	}
} );

add_action( 'after_switch_theme', function () {
	simple_register_types();
	flush_rewrite_rules();
} );
