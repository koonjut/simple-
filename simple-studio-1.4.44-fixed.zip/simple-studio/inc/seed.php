<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Demo data is available for an explicit import only. Theme updates never run it.

function simple_seed_set( $pid, $name, $val ) {
	if ( function_exists( 'update_field' ) ) {
		update_field( $name, $val, $pid );
	} else {
		update_post_meta( $pid, $name, $val );
	}
}

function simple_seed_page( $title, $slug, $template = '' ) {
	$exists = get_page_by_path( $slug );
	if ( $exists ) {
		return $exists->ID;
	}
	$id = wp_insert_post(
		array(
			'post_type'   => 'page',
			'post_status' => 'publish',
			'post_title'  => $title,
			'post_name'   => $slug,
		)
	);
	if ( $id && ! is_wp_error( $id ) && $template ) {
		update_post_meta( $id, '_wp_page_template', $template );
	}
	return $id;
}

function simple_seed_was_new( $set = null ) {
	static $v = false;
	if ( null !== $set ) {
		$v = $set;
	}
	return $v;
}
function simple_seed_insert( $args ) {
	$found = get_posts(
		array(
			'post_type'      => $args['post_type'],
			'title'          => $args['post_title'],
			'post_status'    => 'any',
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
		)
	);
	if ( $found ) {
		simple_seed_was_new( false );
		return (int) $found[0];
	}
	simple_seed_was_new( true );
	return wp_insert_post( $args );
}

function simple_seed_thumb( $post_id, $file ) {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$src = SIMPLE_DIR . '/assets/img/' . $file;
	if ( ! file_exists( $src ) ) {
		return;
	}
	$tmp = wp_tempnam( $file );
	if ( ! $tmp || ! copy( $src, $tmp ) ) {
		return;
	}
	$att = media_handle_sideload( array( 'name' => $file, 'tmp_name' => $tmp ), $post_id );
	if ( is_wp_error( $att ) ) {
		@unlink( $tmp );
		return;
	}
	set_post_thumbnail( $post_id, $att );
}

function simple_seed_home_slots( $home ) {
	if ( ! $home || get_post_meta( $home, 'home_rep_awards', true ) || get_post_meta( $home, 'home_rep_services', true ) ) {
		return;
	}
	$aw = array();
	foreach ( get_posts( array( 'post_type' => 'award', 'posts_per_page' => -1, 'orderby' => 'menu_order date', 'order' => 'ASC', 'no_found_rows' => true ) ) as $a ) {
		$aw[] = array( 'img' => (int) get_post_thumbnail_id( $a->ID ), 'title' => get_the_title( $a ), 'project' => (string) get_post_meta( $a->ID, 'award_project', true ), 'text' => wp_strip_all_tags( $a->post_content ) );
	}
	$sv = array();
	foreach ( get_posts( array( 'post_type' => 'service', 'posts_per_page' => -1, 'orderby' => 'menu_order date', 'order' => 'ASC', 'no_found_rows' => true ) ) as $s ) {
		$sv[] = array( 'img' => (int) get_post_thumbnail_id( $s->ID ), 'title' => get_the_title( $s ), 'text' => $s->post_excerpt, 'page' => (int) $s->ID );
	}
	update_post_meta( $home, 'home_rep_awards', $aw );
	update_post_meta( $home, 'home_rep_services', $sv );
}

function simple_run_seed() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$data = simple_seed_data();

	$home = simple_seed_page( 'Главная', 'home' );
	simple_seed_page( 'О нас', 'about', 'templates/template-about.php' );
	simple_seed_page( 'Команда', 'team', 'templates/template-team.php' );
	simple_seed_page( 'Контакты', 'contacts', 'templates/template-contacts.php' );
	simple_seed_page( 'Услуги', 'services-list', 'templates/template-services.php' );
	simple_seed_page( 'Кейсы', 'projects-list', 'templates/template-projects.php' );
	$blog = simple_seed_page( 'Блог', 'blog' );

	if ( $home && ! get_option( 'page_on_front' ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $home );
	}
	if ( $blog && ! get_option( 'page_for_posts' ) ) {
		update_option( 'page_for_posts', $blog );
	}

	foreach ( $data['services'] as $i => $s ) {
		$ex = get_page_by_path( $s['slug'], OBJECT, 'service' );
		if ( $ex ) {
			if ( 0 === $i && ! has_post_thumbnail( $ex->ID ) ) {
				simple_seed_thumb( $ex->ID, 'sticker-creative.png' );
			}
			continue;
		}
		$id = wp_insert_post(
			array(
				'post_type'    => 'service',
				'post_status'  => 'publish',
				'post_title'   => $s['title'],
				'post_name'    => $s['slug'],
				'post_excerpt' => $s['excerpt'],
				'menu_order'   => $i,
			)
		);
		if ( $id && ! empty( $s['full'] ) ) {
			simple_seed_identity_service( $id );
		}
		if ( $id && 0 === $i && ! has_post_thumbnail( $id ) ) {
			simple_seed_thumb( $id, 'sticker-creative.png' );
		}
	}

	foreach ( $data['awards'] as $i => $a ) {
		$id = simple_seed_insert(
			array(
				'post_type'    => 'award',
				'post_status'  => 'publish',
				'post_title'   => $a['title'],
				'post_content' => $a['text'],
				'menu_order'   => $i,
			)
		);
		if ( $id && simple_seed_was_new() ) {
			simple_seed_set( $id, 'award_project', $a['project'] );
		}
	}

	foreach ( $data['team'] as $i => $m ) {
		$id = simple_seed_insert(
			array(
				'post_type'   => 'team',
				'post_status' => 'publish',
				'post_title'  => $m[0],
				'menu_order'  => $i,
			)
		);
		if ( $id && simple_seed_was_new() ) {
			simple_seed_set( $id, 'team_role', $m[1] );
			simple_seed_set( $id, 'team_bio', $m[2] );
		}
	}

	$logo_files = array( 'client-invictus.png', 'client-terensai.png', 'client-vkusmart.png', 'client-lulu.png', 'client-indigo.png', 'client-astana.png' );
	foreach ( $data['clients'] as $i => $c ) {
		$id = simple_seed_insert(
			array(
				'post_type'   => 'client',
				'post_status' => 'publish',
				'post_title'  => $c,
				'menu_order'  => $i,
			)
		);
		if ( $id && ! is_wp_error( $id ) && isset( $logo_files[ $i ] ) && ! has_post_thumbnail( $id ) ) {
			simple_seed_thumb( $id, $logo_files[ $i ] );
		}
	}

	foreach ( $data['projects'] as $i => $p ) {
		$id = simple_seed_insert(
			array(
				'post_type'    => 'project',
				'post_status'  => 'publish',
				'post_title'   => $p[0],
				'post_excerpt' => $p[1],
				'menu_order'   => $i,
			)
		);
		if ( $id && ! is_wp_error( $id ) && simple_seed_was_new() ) {
			$terms = array_map( 'trim', explode( ',', $p[2] ) );
			wp_set_object_terms( $id, $terms, 'project_cat' );
			if ( $i < 3 ) {
				simple_seed_set( $id, 'project_slide', 1 );
			}
			if ( 'Saya Park' === $p[0] ) {
				simple_seed_saya( $id );
			}
		}
	}

	simple_seed_posts();

	simple_seed_home_slots( $home );

	flush_rewrite_rules();
}

function simple_seed_identity_service( $id ) {
	$set = array(
		'svc_lead'        => 'Создаём фирменный стиль, который делает бренд узнаваемым — от логотипа до сайта и упаковки.',
		'svc_case_title'  => 'ISAD Career Center',
		'svc_case_tags'   => 'ЛОГОТИП / АЙДЕНТИКА / НОСИТЕЛИ',
		'svc_stage_1_title' => 'Знакомимся с бизнесом',
		'svc_stage_1_text'  => 'Вы рассказываете о бизнесе, аудитории и задаче. Мы изучаем ваши материалы и конкурентов, определяем направление и согласуем, что нужно создать.',
		'svc_stage_2_title' => 'Предлагаем визуальную идею',
		'svc_stage_2_text'  => 'Показываем направление, логику и первые наброски. Вместе выбираем, что развивать дальше. (Текст-заглушка — замените на свой.)',
		'svc_stage_3_title' => 'Проверяем на ваших материалах',
		'svc_stage_3_text'  => 'Примеряем стиль на сайт, соцсети, упаковку и другие нужные носители. (Текст-заглушка — замените на свой.)',
		'svc_stage_4_title' => 'Передаём стиль вашей команде',
		'svc_stage_4_text'  => 'Собираем правила и файлы, объясняем, как с ними работать. (Текст-заглушка — замените на свой.)',
		'svc_why_label'   => 'ЗАЧЕМ ЭТО БРЕНДУ',
		'svc_why_title'   => "Чтобы вас узнавали.\nНа любом носителе.",
		'svc_why_text'    => 'Запускаете новый бренд, меняете направление или обновляете устаревший стиль? Поможем собрать единый образ — от сайта и соцсетей до упаковки и рекламы.',
		'svc_get_sub'     => 'Не только логотип. Систему, с которой удобно работать каждый день.',
		'svc_get_1_title' => 'Логотип',
		'svc_get_1_text'  => 'Основная и дополнительные версии — для сайта, соцсетей, печати и других задач.',
		'svc_get_2_title' => 'Цвета и шрифты',
		'svc_get_2_text'  => 'Подбираем сочетания, которые поддерживают характер бренда. Объясняем, как ими пользоваться.',
		'svc_get_3_title' => 'Фирменная графика',
		'svc_get_3_text'  => 'Создаём элементы оформления для рекламы, презентаций, публикаций и упаковки.',
		'svc_get_4_title' => 'Примеры оформления',
		'svc_get_4_text'  => 'Показываем, как стиль работает на нужных вам материалах. Состав примеров согласуем вместе.',
		'svc_get_5_title' => 'Руководство по стилю',
		'svc_get_5_text'  => 'Собираем понятные правила для сотрудников и подрядчиков — в брендбук или гайдлайн.',
		'svc_get_6_title' => 'Готовые файлы',
		'svc_get_6_text'  => 'Передаём материалы для дизайнеров, печати и цифровых площадок в подходящих форматах.',
		'svc_faq_1_q'     => 'Сколько стоит и сколько времени займёт?',
		'svc_faq_1_a'     => 'После знакомства с задачей подготовим предложение с составом работ, стоимостью и сроками. Объём зависит от того, какие элементы и носители нужны вашему бренду.',
		'svc_faq_2_q'     => 'Можно обновить только часть стиля?',
		'svc_faq_2_a'     => 'Да. Сначала выясняем, какие элементы уже работают, а какие стоит изменить. Затем согласуем объём обновления.',
		'svc_faq_3_q'     => 'Что нужно для начала?',
		'svc_faq_3_a'     => 'Расскажите о бизнесе, аудитории и задаче. Если есть действующий логотип, сайт, упаковка или другие материалы, покажите их на первой встрече.',
	);
	foreach ( $set as $k => $v ) {
		simple_seed_set( $id, $k, $v );
	}
}

function simple_seed_posts() {
	$posts = array(
		array(
			'title'   => 'Когда бренду нужны перемены',
			'excerpt' => 'Не каждый новый этап требует нового логотипа. Но когда бренд перестаёт объяснять, кто вы и зачем нужны людям, стоит посмотреть на него заново.',
			'content' => '<p>Не каждый новый этап требует нового логотипа. Но когда бренд перестаёт объяснять, кто вы и зачем нужны людям, стоит посмотреть на него заново.</p>
<p>Ниже — четыре вопроса, которые помогут отделить желание «освежить картинку» от задачи, для которой действительно нужны изменения.</p>
<h2>Начните с задачи бизнеса</h2>
<p>Бренд может выглядеть аккуратно и всё равно мешать компании двигаться дальше. Например, если его воспринимают как доступный продукт, а бизнес уже выходит в более высокий ценовой сегмент. Или если компания расширилась, а визуальный язык продолжает рассказывать только о её первой услуге.</p>
<p>Сформулируйте, что должно измениться после ребрендинга: кого вы хотите привлечь, какое представление о компании пересмотреть и что людям станет проще понять. Такая задача даёт команде критерии для выбора решений. «Нравится или не нравится» превращается в «помогает или не помогает».</p>
<h2>Найдите то, что уже работает</h2>
<p>Перед тем как рисовать новое, разберитесь со старым. Посмотрите, какие элементы люди узнают без подсказки: название, цвет, знак, упаковку или интонацию сообщений. Спросите команду и клиентов, с чем они связывают вашу компанию.</p>
<p>Знакомые элементы не обязательно выбрасывать. Иногда достаточно очистить знак, уточнить цветовую палитру и выстроить типографику. Сильная преемственность помогает бренду измениться и остаться собой.</p>
<blockquote><p>Менять форму легко. Важнее — сохранить смысл.</p></blockquote>
<h2>Меняйте систему, а не только знак</h2>
<p>Логотип — одна часть айдентики. Бренд встречают в разных ситуациях: на сайте, в презентации, на упаковке, в письме или на вывеске. Если каждый носитель выглядит как отдельный проект, даже выразительный знак не собирает цельный образ.</p>
<p>Продумайте общий принцип: как работают шрифты, какие цвета главные, какой характер у фотографий и графики. Важно, чтобы система помогала создавать новые материалы, а не требовала заново изобретать дизайн для каждой задачи.</p>
<h2>Проверьте результат в реальной жизни</h2>
<p>Красивая презентация ещё не показывает, как айдентика будет жить. Соберите несколько привычных для бизнеса носителей: главный экран сайта, коммерческое предложение, пост и упаковку. Проверьте, читается ли текст, узнаётся ли бренд и легко ли команде пользоваться правилами.</p>
<p>После запуска наблюдайте за тем, что изменилось в коммуникации. Стало ли людям понятнее ваше предложение? Появилась ли согласованность между каналами? Ребрендинг полезен тогда, когда новое оформление поддерживает смысл и помогает бизнесу говорить яснее.</p>
<p>Хороший ребрендинг не начинается с вопроса «какой цвет выбрать». Он начинается с понимания того, что компания хочет сказать — и кому.</p>
<p><em>Это демонстрационный материал для блога. Перед публикацией замените текст редакционной статьёй Simple Studio.</em></p>',
		),
		array(
			'title'   => 'Как выбрать название для бренда',
			'excerpt' => 'Короткая памятка о том, из чего складывается сильное имя и как проверить его до запуска. (Демо-статья — замените на свою.)',
			'content' => '<p>Это демонстрационная статья. Замените её своим текстом в разделе «Записи».</p><h2>Что должно делать название</h2><p>Быть понятным, произносимым и свободным для регистрации. Остальное — вопрос характера бренда.</p>',
		),
		array(
			'title'   => 'Упаковка, которую запоминают',
			'excerpt' => 'О том, как упаковка работает на полке и что остаётся в памяти покупателя. (Демо-статья — замените на свою.)',
			'content' => '<p>Это демонстрационная статья. Замените её своим текстом в разделе «Записи».</p><h2>Первые три секунды</h2><p>Именно столько у упаковки есть, чтобы объяснить, что внутри и почему это стоит взять.</p>',
		),
	);
	foreach ( $posts as $p ) {
		simple_seed_insert(
			array(
				'post_type'    => 'post',
				'post_status'  => 'publish',
				'post_title'   => $p['title'],
				'post_excerpt' => $p['excerpt'],
				'post_content' => $p['content'],
			)
		);
	}
}

function simple_seed_saya( $id ) {
	simple_seed_set( $id, 'case_subtitle', 'Новое место' );
	simple_seed_set( $id, 'case_client', 'Saya Park' );
	simple_seed_set( $id, 'case_services', 'Нейминг, визуальная айдентика' );
	simple_seed_set( $id, 'case_place', 'Актау, Казахстан' );
	simple_seed_set( $id, 'case_team', "Art Director | Nikita Chuvaldin\nCreative copywriter | Alexander Shonin\nDesigners | Danaya Khamitova" );
	wp_update_post(
		array(
			'ID'           => $id,
			'post_content' => '<h3>Задача</h3><h2>Новый центр</h2><p>Saya Park — новый торгово-развлекательный центр в Актау. (Демо-текст: замените на описание задачи.)</p><h2>Решение</h2><p>Демо-текст: опишите идею, логику айдентики и результат. Картинки добавляйте блоком «Изображение» — они растянутся на всю ширину; блок «Галерея» из двух картинок покажет их рядом.</p>',
		)
	);
}
