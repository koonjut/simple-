<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function simple_settings_schema() {
	return array(
		'Шапка и меню' => array(
			array( 'opt_cta_label', 'Кнопка в шапке — текст', 'text' ),
			array( 'opt_cta_url', 'Кнопка в шапке — ссылка', 'text', 'Например #contact — якорь на форму в подвале' ),
			array( 'opt_menu_open', 'Мобильное меню — «Меню»', 'text' ),
			array( 'opt_menu_close', 'Мобильное меню — «Закрыть»', 'text' ),
			array( 'opt_menu_caption', 'Мобильное меню — подпись сверху', 'text' ),
		),
		'Подвал' => array(
			array( 'opt_footer_more', 'Блок «Другие проекты» — заголовок', 'text' ),
			array( 'opt_footer_more_all', 'Блок «Другие проекты» — кнопка', 'text' ),
			array( 'opt_footer_invite', 'Приглашение над формой', 'text' ),
			array( 'opt_footer_tag', 'Розовая плашка', 'text' ),
			array( 'opt_footer_text', 'Текст рядом с контактами', 'textarea' ),
			array( 'opt_copy_left', 'Копирайт слева', 'text' ),
			array( 'opt_copy_right', 'Копирайт справа', 'text' ),
		),
		'Контакты' => array(
			array( 'opt_label_email', 'Подпись «Почта»', 'text' ),
			array( 'opt_email', 'Email', 'text' ),
			array( 'opt_label_phone', 'Подпись «Номер»', 'text' ),
			array( 'opt_phone', 'Телефон', 'text' ),
			array( 'opt_instagram', 'Instagram — ссылка', 'text' ),
			array( 'opt_behance', 'Behance — ссылка', 'text' ),
			array( 'opt_linkedin', 'LinkedIn — ссылка', 'text' ),
		),
		'SEO' => array(
			array( 'opt_seo_desc', 'Описание сайта по умолчанию (для поисковиков и соцсетей)', 'textarea', '120–160 символов. Используется на главной и там, где у страницы нет своего описания' ),
		),
		'Форма заявки' => array(
			array( 'opt_lead_email', 'Куда отправлять заявки (email)', 'text', 'Если пусто — на почту администратора сайта (Настройки → Общие)' ),
			array( 'opt_form_name_label', 'Поле «Имя» — подпись', 'text' ),
			array( 'opt_form_name_ph', 'Поле «Имя» — подсказка', 'text' ),
			array( 'opt_form_phone_label', 'Поле «Телефон» — подпись', 'text' ),
			array( 'opt_form_phone_ph', 'Поле «Телефон» — подсказка', 'text' ),
			array( 'opt_form_submit', 'Кнопка отправки', 'text' ),
			array( 'opt_form_consent', 'Текст согласия под кнопкой', 'textarea' ),
			array( 'opt_form_hint', 'Подпись под полем «Обязательное поле»', 'text' ),
		),
		'Состояния формы (ошибка, отправка, успех, сбой)' => array(
			array( 'opt_form_err_name', 'Ошибка: не введено имя', 'text' ),
			array( 'opt_form_err_phone', 'Ошибка: неполный телефон', 'text' ),
			array( 'opt_form_err_contact', 'Ошибка: неверная почта или телефон', 'text' ),
			array( 'opt_form_sending', 'Кнопка во время отправки', 'text' ),
			array( 'opt_form_ok_title', 'Успех: заголовок', 'text' ),
			array( 'opt_form_ok', 'Успех: текст', 'textarea' ),
			array( 'opt_form_again', 'Успех: кнопка «Отправить ещё»', 'text' ),
			array( 'opt_form_fail_title', 'Сбой: заголовок', 'text' ),
			array( 'opt_form_err', 'Сбой: текст', 'textarea' ),
			array( 'opt_form_retry', 'Сбой: кнопка «Попробовать ещё раз»', 'text' ),
		),
		'Окно «Расскажите о проекте»' => array(
			array( 'opt_modal_title', 'Заголовок', 'text' ),
			array( 'opt_modal_close', 'Кнопка «Закрыть»', 'text' ),
			array( 'opt_modal_contact', 'Поле «Почта или телефон» — подпись', 'text' ),
			array( 'opt_modal_contact_ph', 'Поле «Почта или телефон» — подсказка', 'text' ),
			array( 'opt_modal_msg', 'Поле «О проекте» — подпись', 'text' ),
			array( 'opt_modal_msg_ph', 'Поле «О проекте» — подсказка', 'text' ),
			array( 'opt_modal_msg_hint', 'Поле «О проекте» — пояснение', 'text' ),
			array( 'opt_modal_btn', 'Кнопка отправки', 'text' ),
		),
		'Фильтры, пустые состояния, страница 404' => array(
			array( 'opt_filters_btn', 'Кнопка «Фильтры» (телефон)', 'text' ),
			array( 'opt_filters_title', 'Окно фильтров — заголовок', 'text' ),
			array( 'opt_filters_show', 'Окно фильтров — «Показать проекты»', 'text' ),
			array( 'opt_filters_reset', '«Сбросить фильтры»', 'text' ),
			array( 'opt_empty_title', 'Пусто: заголовок', 'text' ),
			array( 'opt_empty_text', 'Пусто: текст', 'textarea' ),
			array( 'opt_e404_title', '404: заголовок', 'text' ),
			array( 'opt_e404_text', '404: текст', 'textarea' ),
			array( 'opt_e404_btn', '404: кнопка', 'text' ),
			array( 'opt_img_broken', 'Подпись, если картинка не загрузилась', 'text' ),
		),
		'Стикеры подвала (стикеры страниц меняются в самих страницах; если не выбрано — стандартные из макета)' => array(
			array( 'img_bike_footer', 'Велосипед рядом с «Обсудим ваш проект?» в подвале (белый, для чёрного фона)', 'image' ),
			array( 'img_star', 'Звезда рядом с «Другие проекты» в подвале', 'image' ),
			array( 'img_footer_project', 'Фото для блока «Другие проекты» в подвале (если не выбрано — берётся обложка кейса)', 'image' ),
		),
	);
}

add_action( 'admin_menu', function () {
	add_menu_page( 'Simple Studio', 'Simple Studio', 'manage_options', 'simple-options', 'simple_settings_page', 'dashicons-art', 3 );
} );

add_action( 'admin_init', function () {
	register_setting(
		'simple_options_group',
		'simple_options',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'simple_sanitize_options',
		)
	);
} );

function simple_sanitize_options( $in ) {
	$out = array();
	if ( ! is_array( $in ) ) {
		return $out;
	}
	foreach ( simple_settings_schema() as $fields ) {
		foreach ( $fields as $f ) {
			$k = $f[0];
			if ( ! isset( $in[ $k ] ) ) {
				continue;
			}
			if ( 'image' === $f[2] ) {
				$out[ $k ] = absint( $in[ $k ] );
			} elseif ( 'textarea' === $f[2] ) {
				$out[ $k ] = sanitize_textarea_field( $in[ $k ] );
			} else {
				$out[ $k ] = sanitize_text_field( $in[ $k ] );
			}
		}
	}
	return $out;
}

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( 'toplevel_page_simple-options' !== $hook ) {
		return;
	}
	wp_enqueue_media();
} );

function simple_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$saved    = get_option( 'simple_options', array() );
	$defaults = simple_defaults();
	?>
	<div class="wrap">
		<h1>Simple Studio — общие настройки</h1>
		<p>Эти тексты показываются на всех страницах (шапка, подвал, форма). Если поле пустое — используется текст из макета (серая подсказка в поле). Тексты самих страниц редактируются в разделе «Страницы», кнопка «Изменить» у нужной страницы.</p>
		<form method="post" action="options.php">
			<?php settings_fields( 'simple_options_group' ); ?>
			<?php foreach ( simple_settings_schema() as $title => $fields ) : ?>
				<h2 style="margin-top:2em"><?php echo esc_html( $title ); ?></h2>
				<table class="form-table" role="presentation">
					<?php
					foreach ( $fields as $f ) :
						$key  = $f[0];
						$val  = isset( $saved[ $key ] ) ? $saved[ $key ] : '';
						$name = 'simple_options[' . $key . ']';
						?>
						<tr>
							<th scope="row"><label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $f[1] ); ?></label></th>
							<td>
								<?php if ( 'image' === $f[2] ) : ?>
									<div class="simple-media" data-name="<?php echo esc_attr( $name ); ?>">
										<div class="simple-media__prev"><?php echo $val ? wp_get_attachment_image( $val, array( 120, 120 ) ) : ''; ?></div>
										<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $val ); ?>">
										<button type="button" class="button simple-media__pick">Выбрать картинку</button>
										<button type="button" class="button-link simple-media__clear">Убрать</button>
									</div>
								<?php elseif ( 'textarea' === $f[2] ) : ?>
									<textarea id="<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $name ); ?>" rows="3" class="large-text" placeholder="<?php echo esc_attr( isset( $defaults[ $key ] ) ? $defaults[ $key ] : '' ); ?>"><?php echo esc_textarea( $val ); ?></textarea>
								<?php else : ?>
									<input type="text" id="<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $val ); ?>" class="regular-text" placeholder="<?php echo esc_attr( isset( $defaults[ $key ] ) ? $defaults[ $key ] : '' ); ?>">
								<?php endif; ?>
								<?php if ( ! empty( $f[3] ) ) : ?>
									<p class="description"><?php echo esc_html( $f[3] ); ?></p>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</table>
			<?php endforeach; ?>
			<?php submit_button( 'Сохранить' ); ?>
		</form>
	</div>
	<script>
	(function(){
		document.querySelectorAll('.simple-media').forEach(function(box){
			var input = box.querySelector('input[type=hidden]');
			var prev  = box.querySelector('.simple-media__prev');
			var frame;
			box.querySelector('.simple-media__pick').addEventListener('click', function(){
				if(!frame){ frame = wp.media({ title:'Выберите картинку', multiple:false, library:{type:'image'} });
					frame.on('select', function(){
						var a = frame.state().get('selection').first().toJSON();
						input.value = a.id;
						var u = (a.sizes && a.sizes.thumbnail) ? a.sizes.thumbnail.url : a.url;
						prev.innerHTML = '<img src="'+u+'" style="max-width:120px;height:auto">';
					});
				}
				frame.open();
			});
			box.querySelector('.simple-media__clear').addEventListener('click', function(){ input.value=''; prev.innerHTML=''; });
		});
	})();
	</script>
	<?php
}
