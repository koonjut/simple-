<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function simple_form_field( $id, $name, $label, $ph, $type = 'text', $required = true, $hint = null, $extra = '' ) {
	$hint = null === $hint ? simple_opt( 'form_hint' ) : $hint;
	?>
	<div class="lead-form__field">
		<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?><?php echo $required ? ' <span class="req">*</span>' : ''; ?></label>
		<?php if ( 'textarea' === $type ) : ?>
			<textarea id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" rows="5" placeholder="<?php echo esc_attr( $ph ); ?>" maxlength="2000"<?php echo $required ? ' required' : ''; ?>></textarea>
		<?php else : ?>
			<input type="<?php echo esc_attr( $type ); ?>" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" placeholder="<?php echo esc_attr( $ph ); ?>"<?php echo $required ? ' required' : ''; ?> maxlength="120"<?php echo $extra; ?>>
		<?php endif; ?>
		<p class="lead-form__hint" data-hint="<?php echo esc_attr( $hint ); ?>"><?php echo esc_html( $hint ); ?></p>
	</div>
	<?php
}

function simple_form_button( $label, $variant = 'pink' ) {
	?>
	<button type="submit" class="btn btn--<?php echo esc_attr( $variant ); ?> btn--form" data-label="<?php echo esc_attr( $label ); ?>">
		<span class="btn__label"><?php echo esc_html( $label ); ?></span>
		<?php echo simple_arrow( 20, 'btn__arrow' ); ?>
		<i class="btn__spin" aria-hidden="true"></i>
	</button>
	<?php
}

function simple_form_states() {
	?>
	<div class="lead-form__fail" role="alert" hidden>
		<strong><?php echo esc_html( simple_opt( 'form_fail_title' ) ); ?></strong>
		<span><?php echo esc_html( simple_opt( 'form_err' ) ); ?></span>
	</div>
	<?php
}

function simple_form_done() {
	?>
	<div class="lead-form__done" role="status" hidden>
		<span class="lead-form__check" aria-hidden="true">✓</span>
		<h3><?php echo esc_html( simple_opt( 'form_ok_title' ) ); ?></h3>
		<p><?php echo esc_html( simple_opt( 'form_ok' ) ); ?></p>
		<button type="button" class="btn btn--pink btn--form" data-form-again><span class="btn__label"><?php echo esc_html( simple_opt( 'form_again' ) ); ?></span><?php echo simple_arrow( 20, 'btn__arrow' ); ?></button>
	</div>
	<?php
}

function simple_lead_form( $id = 'lead' ) {
	?>
	<form class="lead-form" method="post" action="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>" novalidate>
		<div class="lead-form__body">
			<div class="lead-form__row">
				<?php
				simple_form_field( $id . '-name', 'lead_name', simple_opt( 'form_name_label' ), simple_opt( 'form_name_ph' ), 'text', true, null, ' autocomplete="name" data-name="1" data-err="' . esc_attr( simple_opt( 'form_err_name' ) ) . '"' );
				simple_form_field( $id . '-phone', 'lead_phone', simple_opt( 'form_phone_label' ), simple_opt( 'form_phone_ph' ), 'tel', true, null, ' autocomplete="tel" inputmode="tel" data-mask="phone" data-err="' . esc_attr( simple_opt( 'form_err_phone' ) ) . '"' );
				?>
			</div>
			<?php simple_form_states(); ?>
			<input type="text" name="lead_website" class="lead-form__hp" tabindex="-1" autocomplete="off" aria-hidden="true">
			<input type="hidden" name="action" value="simple_lead">
			<div class="lead-form__actions"><?php simple_form_button( simple_opt( 'form_submit' ) ); ?></div>
			<p class="lead-form__consent"><?php echo esc_html( simple_opt( 'form_consent' ) ); ?></p>
		</div>
		<?php simple_form_done(); ?>
	</form>
	<?php
}

function simple_modal_form() {
	?>
	<form class="lead-form lead-form--modal" method="post" action="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>" novalidate>
		<div class="lead-form__body">
			<div class="lead-form__row">
				<?php
				simple_form_field( 'm-name', 'lead_name', simple_opt( 'form_name_label' ), simple_opt( 'form_name_ph' ), 'text', true, null, ' autocomplete="name" data-name="1" data-err="' . esc_attr( simple_opt( 'form_err_name' ) ) . '"' );
				simple_form_field( 'm-contact', 'lead_contact', simple_opt( 'modal_contact' ), simple_opt( 'modal_contact_ph' ), 'text', true, null, ' autocomplete="email" data-mask="auto" data-err="' . esc_attr( simple_opt( 'form_err_contact' ) ) . '"' );
				?>
			</div>
			<?php simple_form_field( 'm-msg', 'lead_message', simple_opt( 'modal_msg' ), simple_opt( 'modal_msg_ph' ), 'textarea', false, simple_opt( 'modal_msg_hint' ) ); ?>
			<?php simple_form_states(); ?>
			<input type="text" name="lead_website" class="lead-form__hp" tabindex="-1" autocomplete="off" aria-hidden="true">
			<input type="hidden" name="action" value="simple_lead">
			<div class="lead-form__actions"><?php simple_form_button( simple_opt( 'modal_btn' ) ); ?></div>
			<p class="lead-form__consent"><?php echo esc_html( simple_opt( 'form_consent' ) ); ?></p>
		</div>
		<?php simple_form_done(); ?>
	</form>
	<?php
}

function simple_contact_form( $pid ) {
	?>
	<form class="lead-form lead-form--contact" method="post" action="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>" novalidate>
		<div class="lead-form__body">
			<div class="lead-form__row">
				<?php
				simple_form_field( 'c-name', 'lead_name', sf( 'cont_f_name', $pid ), sf( 'cont_f_name_ph', $pid ), 'text', true, null, ' autocomplete="name" data-name="1" data-err="' . esc_attr( simple_opt( 'form_err_name' ) ) . '"' );
				simple_form_field( 'c-contact', 'lead_contact', sf( 'cont_f_contact', $pid ), sf( 'cont_f_contact_ph', $pid ), 'text', true, null, ' autocomplete="email" data-mask="auto" data-err="' . esc_attr( simple_opt( 'form_err_contact' ) ) . '"' );
				?>
			</div>
			<?php simple_form_field( 'c-msg', 'lead_message', sf( 'cont_f_msg', $pid ), sf( 'cont_f_msg_ph', $pid ), 'textarea', false, simple_opt( 'modal_msg_hint' ) ); ?>
			<?php simple_form_states(); ?>
			<input type="text" name="lead_website" class="lead-form__hp" tabindex="-1" autocomplete="off" aria-hidden="true">
			<input type="hidden" name="action" value="simple_lead">
			<div class="lead-form__actions"><?php simple_form_button( sf( 'cont_btn', $pid ) ); ?></div>
			<p class="lead-form__consent"><?php echo esc_html( sf( 'cont_consent', $pid ) ); ?></p>
		</div>
		<?php simple_form_done(); ?>
	</form>
	<?php
}

add_action( 'wp_ajax_simple_lead_nonce', 'simple_lead_nonce' );
add_action( 'wp_ajax_nopriv_simple_lead_nonce', 'simple_lead_nonce' );
function simple_lead_nonce() {
	nocache_headers();
	wp_send_json_success( array( 'nonce' => wp_create_nonce( 'simple_lead' ) ) );
}

function simple_normalize_phone( $value ) {
	$value = trim( $value );
	if ( ! preg_match( '/^\+?[0-9\s().-]+$/', $value ) ) {
		return '';
	}
	$digits = preg_replace( '/\D+/', '', $value );
	if ( '+' === substr( $value, 0, 1 ) ) {
		if ( ! preg_match( '/^[1-9][0-9]{6,14}$/', $digits ) || ( '7' === substr( $digits, 0, 1 ) && 11 !== strlen( $digits ) ) ) {
			return '';
		}
		return '+' . $digits;
	}
	if ( 10 === strlen( $digits ) ) {
		return '+7' . $digits;
	}
	if ( 11 === strlen( $digits ) && in_array( substr( $digits, 0, 1 ), array( '7', '8' ), true ) ) {
		return '+7' . substr( $digits, 1 );
	}
	return '';
}

add_action( 'wp_ajax_simple_lead', 'simple_lead_handle' );
add_action( 'wp_ajax_nopriv_simple_lead', 'simple_lead_handle' );
function simple_lead_handle() {
	if ( ! isset( $_SERVER['REQUEST_METHOD'] ) || 'POST' !== $_SERVER['REQUEST_METHOD'] ) {
		wp_send_json_error( array( 'message' => simple_opt( 'form_err' ) ), 405 );
	}
	$limits = array( '_nonce' => 32, 'lead_website' => 200, 'lead_name' => 120, 'lead_phone' => 120, 'lead_contact' => 120, 'lead_message' => 2000, 'page' => 2048 );
	foreach ( $limits as $field => $limit ) {
		if ( isset( $_POST[ $field ] ) && ( ! is_string( $_POST[ $field ] ) || strlen( wp_unslash( $_POST[ $field ] ) ) > $limit * 4 ) ) {
			wp_send_json_error( array( 'message' => simple_opt( 'form_err' ) ), 422 );
		}
	}
	if ( ! isset( $_POST['_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_nonce'] ) ), 'simple_lead' ) ) {
		wp_send_json_error( array( 'message' => simple_opt( 'form_err' ) ), 403 );
	}

	if ( ! empty( $_POST['lead_website'] ) ) {
		wp_send_json_success( array( 'message' => simple_opt( 'form_ok' ) ) );
	}

	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$key = 'simple_lead_' . md5( $ip );
	$cnt = (int) get_transient( $key );
	if ( $cnt >= 5 ) {
		wp_send_json_error( array( 'message' => simple_opt( 'form_err' ) ), 429 );
	}

	$name    = isset( $_POST['lead_name'] ) ? sanitize_text_field( wp_unslash( $_POST['lead_name'] ) ) : '';
	$name    = trim( preg_replace( '/[^\p{L}\s\'.\-]+/u', '', $name ) );
	$phone   = isset( $_POST['lead_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['lead_phone'] ) ) : '';
	$contact = isset( $_POST['lead_contact'] ) ? sanitize_text_field( wp_unslash( $_POST['lead_contact'] ) ) : '';
	$message = isset( $_POST['lead_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['lead_message'] ) ) : '';
	$page    = isset( $_POST['page'] ) ? esc_url_raw( wp_unslash( $_POST['page'] ) ) : '';

	if ( '' === $phone && '' !== $contact ) {
		$phone = $contact;
	}
	$is_email = is_email( $phone );
	$phone    = $is_email ? $phone : simple_normalize_phone( $phone );
	$name_len = preg_match_all( '/./us', $name );
	if ( $name_len < 2 || $name_len > 120 || preg_match_all( '/./us', $message ) > 2000 || '' === $phone || ( ! empty( $_POST['lead_phone'] ) && $is_email ) ) {
		wp_send_json_error( array( 'message' => simple_opt( 'form_err' ) ), 422 );
	}

	set_transient( $key, $cnt + 1, HOUR_IN_SECONDS );

	$id = wp_insert_post(
		array(
			'post_type'   => 'lead',
			'post_status' => 'publish',
			'post_title'  => wp_slash( $name ),
		),
		true
	);
	if ( ! $id || is_wp_error( $id ) ) {
		error_log( 'Simple Studio: could not save a lead.' );
		wp_send_json_error( array( 'message' => simple_opt( 'form_err' ) ), 500 );
	}
	foreach ( array( '_lead_phone' => $phone, '_lead_page' => $page, '_lead_message' => $message ) as $meta_key => $value ) {
		update_post_meta( $id, $meta_key, wp_slash( $value ) );
		if ( (string) get_post_meta( $id, $meta_key, true ) !== $value ) {
			error_log( 'Simple Studio: incomplete lead data, post ID ' . (int) $id );
			wp_send_json_error( array( 'message' => simple_opt( 'form_err' ) ), 500 );
		}
	}

	$to = simple_opt( 'lead_email' );
	if ( ! is_email( $to ) ) {
		$to = get_option( 'admin_email' );
	}
	$body = "Новая заявка с сайта\n\nИмя: {$name}\nКонтакт: {$phone}\nСообщение: {$message}\nСтраница: {$page}\n";
	try {
		$mailed = wp_mail( $to, 'Новая заявка — ' . get_bloginfo( 'name' ), $body );
	} catch ( Throwable $e ) {
		$mailed = false;
	}
	update_post_meta( $id, '_lead_mail_status', $mailed ? 'accepted' : 'failed' );
	if ( ! $mailed ) {
		error_log( 'Simple Studio: lead saved but mail notification failed, post ID ' . (int) $id );
	}

	wp_send_json_success( array( 'message' => simple_opt( 'form_ok' ) ) );
}
