<?php
get_header();
?>
<section class="page-head"><h1 class="h1"><?php wp_title( '' ); ?></h1></section>
<section class="section blog-grid">
	<?php
	$i = 0;
	while ( have_posts() ) {
		the_post();
		get_template_part( 'template-parts/post-card', null, array( 'post' => get_post(), 'index' => $i++ ) );
	}
	?>
</section>
<?php get_footer();
